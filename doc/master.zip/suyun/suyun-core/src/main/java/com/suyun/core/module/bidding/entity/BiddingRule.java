package com.suyun.core.module.bidding.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName(value = "sy_bidding_rule",resultMap = "BaseResultMap")
public class BiddingRule extends BaseEntity<BiddingRule> {

    private static final long serialVersionUID = 1L;
	/**
	 * 保证金额
	 */
	private BigDecimal deposit;
	/**
	 * 开始时间
	 */
	@TableField("start_date")
	private Date startDate;
	/**
	 * 结束时间
	 */
	@TableField("end_date")
	private Date endDate;
	/**
	 * 最小跳价
	 */
	@TableField("min_jump_price")
	private BigDecimal minJumpPrice;
	/**
	 * 秒数
	 */
	@TableField("countdown_time")
	private Long countdownTime;
	/**
	 * 创建时间
	 */
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
	/**
	 * 修改时间
	 */
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;

	/**
	 * 竞价产品List
	 */
	@NotNull(message = "要绑定的产品不能为空")
	@TableField(exist = false)
	private List<BiddingRuleProduct> biddingProductList;

}
