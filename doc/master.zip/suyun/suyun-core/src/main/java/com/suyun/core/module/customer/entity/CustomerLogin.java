package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Email;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * <p>
 * 客户登陆信息
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_customer_login")
public class CustomerLogin extends BaseEntity<CustomerLogin> {

    private static final long serialVersionUID = 1L;

    /**
     * 登陆账号
     */
	private String login;
	private String password;
	/**
	 * 姓名
	 */
	@TableField("user_name")
	@Size(max=45,message = "员工姓名长度最多不超过45")
	private String userName;
    /**
     * 手机号
     */
	@TableField("mobile_no")
	@Pattern(regexp = "^[1][3,4,5,7,8][0-9]{9}$",message = "手机号码格式不正确")
	private String mobileNo;
	@Email
	@Size(max=45,message = "邮箱长度最多不超过45")
	private String email;
    /**
     * 是否启用 1：启用；2：禁用
     */
	@TableField("is_active")
	private Boolean active;
	@TableField("logo_url")
	private String logoUrl;
    /**
     * 是否是企业管理员 1：是 0：否
     */
	@TableField("is_admin")
	private Boolean admin;
	@TableField("customer_id")
	private Long customerId;

	/**
	 * 职位
	 */
	@TableField("position")
	@Size(max=30,message = "职位长度最多不超过30")
	private String position;

}
