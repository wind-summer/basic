package com.suyun.core.module.financing.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_financing_contact_log")
public class FinancingContactLog extends BaseEntity<FinancingContactLog> {

    private static final long serialVersionUID = 1L;

    /**
     * 业务员
     */

    @NotBlank(message = "业务员不能为空")
    private String salesman;

    /**
     * 沟通内容
     */
    @NotBlank(message = "沟通内容不能为空")
	private String content;

    /**
     * 创建时间
     */
    @TableField(value = "create_date",fill= FieldFill.INSERT)
    private Date createDate;

    /**
     * 融资申请表id
     */
	@TableField("financing_apply_id")
	private Long financingApplyId;


}
