package com.suyun.core.module.order.service.dto;

import com.suyun.core.module.customer.service.dto.BankAttributeDTO;
import lombok.Data;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单用户信息
 * @date 2018/1/3 下午3:35
 */
@Data
public class UserDTO {

    private Long id;

    /**
     * 名称
     */
    private String name;

    /**
     * 昵称
     */
    private String nick;

    /**
     * 描述
     */
    private String description;

    private String logoUrl;
    /**
     * 手机号
     */
    private String primaryPhone;
    /**
     * 备用联系电话
     */
    private String secondPhone;

    /**
     * 银行开户信息
     */
    private BankAttributeDTO bank;
}
