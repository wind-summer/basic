package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.module.order.enums.OrderItemType;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_item")
public class OrderItem extends BaseEntity<OrderItem> {

    private static final long serialVersionUID = 1L;

    /**
     * 商品名称
     */
	private String name;
    /**
     * 关联商品skuId
     */
	@TableField("sku_id")
	@NotNull
	private Long skuId;

	/**
	 * 商品牌号，冗余字段
	 */
	@TableField("grade_code")
	private String gradeCode;

    /**
     * 类型 0:销售商品  1：赠品
     */
	@TableField("item_type")
	private OrderItemType itemType = OrderItemType.SALE;
    /**
     * 市场价格
     */
	private BigDecimal price;
    /**
     * 销售价
     */
	@TableField("sale_price")
	private BigDecimal salePrice;

	/**
	 * 实际销售价
	 */
	@TableField("retail_price")
	private BigDecimal retailPrice;
    /**
     * 销售数量
     */
    @TableField("quantity")
	private BigDecimal quantity;
    /**
     * 税率
     */
	private BigDecimal tax;
	@TableField("order_id")
	private Long orderId;
    /**
     * 关联商品id
     */
	@TableField("product_id")
	private Long productId;

	private transient BigDecimal subTotal;

    public BigDecimal getSubTotal(){

    	subTotal = retailPrice==null?null: retailPrice.multiply(quantity).setScale(2);
    	return subTotal;
	}
	@TableField(exist = false)
	public Sku sku;

}
