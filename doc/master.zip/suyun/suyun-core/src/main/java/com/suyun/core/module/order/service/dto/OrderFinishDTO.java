package com.suyun.core.module.order.service.dto;

import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Min;
import java.math.BigDecimal;

/**
 * @author caosg
 * @version V1.0
 * @Description: 发货强制完成数据对象
 * @date 2018/3/5 下午6:21
 */
@Data
@Accessors(chain = true)
public class OrderFinishDTO {
    //订单发货强制完成
    public final static String FINISH ="1";
    //订单取消
    public final static String CANCEL = "0";
    @NotEmpty(message = "订单编号不允许为空")
    private String orderCode;
    @Min(value =0, message = "发货数量不允许为空")
    private BigDecimal shippedQuantity;
    @Min(value = 0,message = "未发货数量不允许为空")
    private BigDecimal noQuantity;
    @NotEmpty(message = "标志不允许为空")
    private String flag;//1是强制完成，0是取消强制完成

}
