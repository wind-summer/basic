package com.suyun.core.module.account.service;

/**
 * @author zhangjq
 * @version V1.0
 * @Description: 账户模块常量类
 * @date 2017/12/28 上午12:28
 */
public interface AccountConstant {

    /**
     * 充值申请
     */
    String APPLY_CODE_PREFIX = "XS";

    /**
     * 账户创建
     */
    String ACCOUNT_CODE_PREFIX = "ZH";


    /**
     * 账户冻结
     */
    String ACCOUNT_DJ = "DJ";

    /**
     * 账户id
     */
    String CUSTOMER_ID = "customerId";

    /**
     * 账户付款识别码
     */
    String AWAITING_CONFIRM_RECHARGE_KEY = "recharge";

}
