package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.enums.IdentificationTypeEnum;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.LuhnCheck;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * 客戶信息
 *
 * @date 2018年1月13日 09:47:46
 * @author luy
 */
@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerDetailDTO extends Customer {

    /**
     * 公司行业
     */
    @NotBlank(message = "主营产品不能为空")
    private String industry;
    /**
     * 公司规模
     */
    @NotBlank(message = "公司规模不能为空")
    private String scale;
    /**
     * 公司地址
     */
    @NotBlank(message = "详细地址不能为空")
    private String address;
    /**
     * 注册资本
     */
    @NotBlank(message = "注册资金不能为空")
    private String registeredCapital;

    /**
     * 银行账户类型
     */
    private String accountType;
    /**
     * 开户名
     */
    @NotBlank(message = "开户名不能为空")
    private String accountName;
    /**
     * 开户行
     */
    @NotBlank(message = "开户行不能为空")
    private String bank;
    /**
     * 银行账号
     */
    @NotBlank(message = "银行账号不能为空")
    @LuhnCheck(message="银行卡格式不正确")
    private String accountNo;

    /**
     * 企业法人
     */
    @NotBlank(message = "法人姓名不能为空")
    private String legalName;

    /**
     * 法人身份证号
     */
    @NotBlank(message = "法人身份证号不能为空")
    @Pattern(regexp = "^(\\d{6})(19|20)(\\d{2})(1[0-2]|0[1-9])(0[1-9]|[1-2][0-9]|3[0-1])(\\d{3})(\\d|X|x)?$",message = "身份证格式错误")
    private String legalIdentityCard;

    /**
     * 法人手机号
     */
    private String legalMobile;

    /**
     * 登录帐号
     */
    private String login;

    /**
     * 单位类型
     */
    @NotNull(message = "单位类型不能为空")
    private String bizType;
    /**
     * 认证方式
     */
    @NotNull(message = "认证方式不能为空")
    private IdentificationTypeEnum identificationType;
    /**
     * 营业执照号
     */
    private String organizationRegNo;
    /**
     * 营业执照扫描件
     */
    @NotBlank(message = "营业执照扫描件不能为空")
    private String bizLogoUrl;
    /**
     * 组织机构代码
     */
    private String organizationCode;
    /**
     * 组织机构代码扫描件
     */
    private String organizationCodeImg;
    /**
     * 社会信用代码
     */
    private String bizCreditCode;
    /**
     * 税务登记扫描件
     */
    private String taxCertificateImg;

    private String token;
}
