package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @author luy
 * @Description: 客户注册
 * @date 2017年12月20日 14:11:04
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegisterDTO {
    /**
     * 登录帐号
     */
    @NotBlank(message = "登录帐号不能为空")
    @Size(max=40,message = "登录帐号长度最多不超过40")
    @Pattern(message = "登录帐号格式不正确" ,regexp = "^[A-Za-z0-9]+$")
    private String login;

    /**
     * 登录密码
     */
    @NotBlank(message = "密码不能为空")
    private String password;

    /**
     * 确认密码
     */
    @NotBlank(message = "确认密码不能为空")
    private String confirmPassword;

    /**
     * 手机号
     */
    @NotBlank(message = "手机号码不能为空")
    @Pattern(message = "手机号码格式不正确" ,regexp = "^[1][3,4,5,7,8][0-9]{9}$")
    private String mobileNo;

    /**
     * 验证码
     */
    @NotBlank(message = "验证码不能为空")
    private String verificationCode;

}
