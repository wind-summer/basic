package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.order.service.dto.OrderAdjustDTO;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_adjustment")
public class OrderAdjustment extends BaseEntity<OrderAdjustment> {

    private static final long serialVersionUID = 1L;

	private String reason;
	@TableField("adjust_detail")
	private OrderAdjustDTO adjustDetail;
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
	@TableField("create_by")
	private String createBy;
	@TableField("order_id")
	private Long orderId;


}
