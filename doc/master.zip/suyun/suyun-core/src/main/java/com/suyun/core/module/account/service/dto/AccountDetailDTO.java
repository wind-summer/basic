package com.suyun.core.module.account.service.dto;

import com.suyun.core.module.account.enums.AccountStatus;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * @author zhangjq
 * @Description:
 * @date 2017年12月29日 18:22
 */
@Data
@Accessors(chain = true)
public class AccountDetailDTO {
    /**
     * 账户id
     */
    private Long id;

    /**
     * 账户总额
     */
    private BigDecimal amount;

    /**
     * 冻结金额
     */
    private BigDecimal freezeAmount;

    /**
     * 可用余额
     */
    private BigDecimal avaliableAmount;

    /**
     * 账户是否被冻结 0已激活 1冻结 2作废
     */
    private AccountStatus status;

    /**
     * 用户名称
     */
    private  String name;

    /**
     * 用户编码
     */
    private  String code;

    /**
     *用户类型
     */
    private String customerType;

    /**
     * 用户id
     */
    private  Long customerId;

    /**
     * 企业logo
     */
    private  String logoUrl;
}
