package com.suyun.core.module.order.service.impl;

import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.service.OrderPriceStrategyTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单价格计算管理器
 * @date 2017/12/7 下午3:49
 */
@Component
public class OrderPriceManager {
    @Autowired
    private List<OrderPriceStrategyTemplate> orderPriceStrategies;

    /**
     * 计算订单价格
     * @param order
     */
    public void calculateOrderPrice(Order order){
        orderPriceStrategies.forEach(orderPriceStrategy -> orderPriceStrategy.price(order));
    }
}
