package com.suyun.core.module.financing.service;

import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.financing.entity.FinancingContactLog;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
public interface FinancingContactLogService extends IService<FinancingContactLog> {

}
