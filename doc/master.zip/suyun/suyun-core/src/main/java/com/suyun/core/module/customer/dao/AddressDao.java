package com.suyun.core.module.customer.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.customer.entity.Address;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 地址 Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface AddressDao extends BaseMapper<Address> {

    /**
     * 根据customerId获取收获地址
     * @param customerId
     * @return
     */
    List<Address> getAddressList(@Param("customerId") Long customerId);
}
