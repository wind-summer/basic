package com.suyun.core.module.demo.service.dto;

import lombok.Data;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/11/29 下午5:49
 */
@Data
public class AddressDTO {
    private String province;
    private String city;
}
