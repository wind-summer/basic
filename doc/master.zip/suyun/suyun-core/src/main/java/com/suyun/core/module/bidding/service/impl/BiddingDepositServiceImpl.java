package com.suyun.core.module.bidding.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.suyun.common.exception.BizException;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.bidding.entity.BiddingDeposit;
import com.suyun.core.module.bidding.dao.BiddingDepositDao;
import com.suyun.core.module.bidding.entity.BiddingRule;
import com.suyun.core.module.bidding.entity.BiddingRuleProduct;
import com.suyun.core.module.bidding.enums.BiddingStatus;
import com.suyun.core.module.bidding.service.BiddingDepositService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wlf
 * @since 2017-12-28
 */
@Service
@AllArgsConstructor
@Slf4j
public class BiddingDepositServiceImpl extends ServiceImpl<BiddingDepositDao, BiddingDeposit> implements BiddingDepositService {

    private final AccountApplyService accountApplyService;
    private final AccountService accountService;
    private final ApplicationProperties applicationProperties;
    /**
     * 添加保证金记录表数据
     * @param biddingDeposit
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addBiddingDeposit(BiddingDeposit biddingDeposit) {
        //验证竞价产品是否结束，如果结束就不能对这个产品进行缴纳保证金
        Long biddingProductId = biddingDeposit.getBiddingProductId();
        BiddingRuleProduct biddingRuleProduct = new BiddingRuleProduct();
        biddingRuleProduct.setId(biddingProductId);
        biddingRuleProduct = biddingRuleProduct.selectById();
        if(!biddingRuleProduct.getBiddingStatus().equals(BiddingStatus.BIDDING)){
            throw new BizException("只有竞价中的产品才能交保证金");
        }
        //当前客户ID
        Long customerId = CurrentUserUtils.getLogin().getCustomerId();
        //验证当前保证金是否已经缴纳
        Integer count = this.selectCount(new EntityWrapper<BiddingDeposit>()
                .eq("bidding_product_id", biddingDeposit.getBiddingProductId())
                .eq("customer_id",customerId));
        if(count != 0){
            throw new BizException("您当前已经交过保证金");
        }
        //应该交的保证金
        BiddingRule biddingRule = new BiddingRule();
        biddingRule.setId(biddingRuleProduct.getBiddingRuleId());
        biddingRule = biddingRule.selectById();
        //应该交的保证金 = 保证金比例*起拍单价*总数量/100
        BigDecimal shouldDeposit = biddingRule.getDeposit()
                .multiply(biddingRuleProduct.getStartUnitPrice())
                .multiply(new BigDecimal(biddingRuleProduct.getQuantity()))
                .divide(new BigDecimal(100));
        //如果应该缴纳的保证金金额大于最大保证金，那么当前需要交的保证金就是最大金额
        if(shouldDeposit.compareTo(applicationProperties.getBidding().getMaxDeposit())==1){
            shouldDeposit = applicationProperties.getBidding().getMaxDeposit();
        }
        //保证金额
        BigDecimal deposit = biddingDeposit.getDeposit();
        if(deposit.compareTo(shouldDeposit) != 0){
            throw new BizException("保证金额错误，应该缴纳保证金额为：" + shouldDeposit);
        }
        //获取可用余额
        Account account = accountService.findAccountByCustomerId(customerId);
        BigDecimal avaliableAmount = account.getAvaliableAmount();
        if(avaliableAmount.compareTo(deposit) == -1){
            throw new BizException("可用金额不足，保证金提交失败");
        }
        //调用账户接口，冻结保证金
        accountApplyService.freezeByCustomerId(CurrentUserUtils.getLogin().getCustomerId(), biddingDeposit.getDeposit(), 4);
        biddingDeposit.setCustomerId(CurrentUserUtils.getLogin().getCustomerId());
        this.insert(biddingDeposit);
        //throw new BizException("可用金额不足，保证金提交失败");
    }
}
