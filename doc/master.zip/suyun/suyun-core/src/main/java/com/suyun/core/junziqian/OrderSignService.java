package com.suyun.core.junziqian;

import com.google.common.collect.Sets;
import com.junziqian.api.JunziqianClient;
import com.junziqian.api.bean.Signatory;
import com.junziqian.api.common.DealType;
import com.junziqian.api.common.IdentityType;
import com.junziqian.api.request.ApplySignTmplRequest;
import com.junziqian.api.request.DetailAnonyLinkRequest;
import com.junziqian.api.request.FileLinkRequest;
import com.junziqian.api.request.SignLinkRequest;
import com.junziqian.api.response.ApplySignResponse;
import com.junziqian.api.response.SignLinkResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.ebaoquan.rop.thirdparty.com.alibaba.fastjson.JSONArray;
import org.ebaoquan.rop.thirdparty.com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Map;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单电子合同服务
 * @date 2018/2/7 下午3:52
 */
@Component
@AllArgsConstructor
@Slf4j
public class OrderSignService {

    private final JunziqianClient junziqianClient;

    private final JunziQianProperties junziQianProperties;

    /**
     * 上传合同信息进入签约室
     * @param customer 企业客户信息
     * @param contractParams
     * @return
     */
    public ApplySignResponse applySign(Map<String,Object> customer,Map<String,Object> contractParams){
        ApplySignTmplRequest.Builder builder = new ApplySignTmplRequest.Builder();
        builder.withContractName(junziQianProperties.getOrderSignName());
        builder.withTemplateNo(junziQianProperties.getOrderSignTmlNo());
        builder.withContractParams(contractParams);
        //混合签（手动，自动）
        builder.withDealType(DealType.AUTH_SIGN_PART);
        //使用云证书，0 不使用，1 使用
        builder.withServerCa(1);
        //目前仅支持无认证、身份证认证、银行卡认证、USBKEY认证
//        TreeSet<Integer> set=new TreeSet<Integer>();
//        builder.withFaceThreshold(64); //人脸识别相似度
//        set.add(AuthLevel.FACE.getCode()); //人脸识别
//        set.add(AuthLevel.BANKTHREE.getCode());//银行卡三要素
//        set.add(AuthLevel.BANKCARD.getCode()); //四要素
//        builder.withAuthLevel(set,"1");//authLevel,认证要素数组set；authLevelRange1-4，认证个数（针对所有手动签约对象）


        /**
         * 0 只需第一次认证过，后面不用认证
         * 1 每次签约都要认证
         */
        builder.withForceAuthentication(0);

        HashSet<Signatory> signatories = Sets.newHashSet();
        /**
         * 企业客户信息
         */
        Signatory signatory = new Signatory();
        signatory.setFullName((String) customer.get("fullName"));
        signatory.setIdentityCard((String) customer.get("idCard"));
        signatory.setMobile((String) customer.get("mobile"));
        signatory.setSignatoryIdentityType((IdentityType) customer.get("idType"));
        signatory.setEmail((String) customer.get("email"));
        JSONArray chapteJsonArray=new JSONArray();
        JSONObject pageJson=new JSONObject();
        pageJson.put("page", 0);
        JSONArray chaptes=new JSONArray();
        pageJson.put("chaptes", chaptes);
        chapteJsonArray.add(pageJson);

        JSONObject chapte=new JSONObject();
        chapte.put("offsetX", junziQianProperties.getOffsetX());
        chapte.put("offsetY", junziQianProperties.getOffsetY());
        //显示签章高度
        //chapte.put("cheight", junziQianProperties.getHeight());
        chaptes.add(chapte);

        signatory.withChapteJson(chapteJsonArray);
        //0：标准图形章   1：公章或手写
        signatory.setSignLevel(1);
        //1，自动签约；0，手动签
        signatory.setServerCaAuto(0);
        signatories.add(signatory);

        /**
         * 道恩企业信息
         */
        signatory = new Signatory();
        signatory.setFullName(junziQianProperties.getCompany().getName());
        signatory.setSignatoryIdentityType(IdentityType.BIZLIC);
        signatory.setIdentityCard(junziQianProperties.getCompany().getIdCard());
        signatory.setMobile(junziQianProperties.getCompany().getMobile());
        signatory.setEmail(junziQianProperties.getCompany().getEmail());
        /**
         * 公章定位
         */
        JSONArray chapteJsonArray1=new JSONArray();
        JSONObject pageJson1=new JSONObject();
        pageJson1.put("page", 0);
        JSONArray chaptes1=new JSONArray();
        pageJson1.put("chaptes", chaptes1);
        chapteJsonArray1.add(pageJson1);
        JSONObject chapte1=new JSONObject();
        chapte1.put("offsetX", junziQianProperties.getCompany().getOffsetX());
        chapte1.put("offsetY", junziQianProperties.getCompany().getOffsetY());
        //显示签章高度
        //chapte1.put("cheight", junziQianProperties.getCompany().getHeight());
        chaptes1.add(chapte1);


        signatory.withChapteJson(chapteJsonArray1);
        //0：标准图形章   1：公章或手写
        signatory.setSignLevel(1);
        //1：自动签约
        signatory.setServerCaAuto(1);
        signatories.add(signatory);

        builder.withSignatories(signatories);

        ApplySignResponse response = junziqianClient.applySignTmpl(builder.build());
        log.info("applySign response:{}",response);
        return  response;
    }

    /**
     * 生成签约链接地址
     * @param applyNo 签约编号
     * @param customer 企业客户信息
     * @return
     */
    public SignLinkResponse signLink(String applyNo, Map<String,Object> customer){
        SignLinkRequest request = new SignLinkRequest();
        request.setApplyNo(applyNo);

        Signatory signatory = new Signatory();
        signatory.setFullName((String) customer.get("fullName"));
        signatory.setIdentityCard((String) customer.get("idCard"));
        signatory.setSignatoryIdentityType((IdentityType) customer.get("idType"));
        request.setSignatory(signatory);
        SignLinkResponse response = junziqianClient.signLink(request);
        log.info("signLink response:{}",response);
        return response;
    }

    /**
     * 签约详情查看链接
     * @param applyNo 签约编号
     * @return
     */
    public SignLinkResponse signDetail(String applyNo){
        DetailAnonyLinkRequest request = new DetailAnonyLinkRequest();
        request.setApplyNo(applyNo);
        SignLinkResponse response = junziqianClient.detailAnonyLink(request);
        log.info("signDetail response:{}",response);
        return  response;
    }

    /**
     * 签约完成合同下载URL
     * @param applyNo
     * @return
     */
    public SignLinkResponse fileLink(String applyNo){
        FileLinkRequest request = new FileLinkRequest();
        request.setApplyNo(applyNo);
        SignLinkResponse response = junziqianClient.fileLink(request);
        log.info("signDetail response:{}",response);
        return  response;
    }
}
