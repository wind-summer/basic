package com.suyun.core.module.bidding.service.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * @author wlf
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/27 下午2:32
 */
@Data
@Accessors(chain = true)
public class CustomerDepositDTO {

    /**
     * 是否通过
     */
    private Boolean pass;
    /**
     * 该产品至少要交付的定金
     */
    private BigDecimal needDeposit;
    /**
     * 当前已经交付的定金
     */
    private BigDecimal currentDeposit;
}
