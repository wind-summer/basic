package com.suyun.core.module.order.dao.typehandler;

import com.suyun.core.config.mybatis.typehandler.JsonTypeHandler;
import com.suyun.core.module.order.service.dto.OrderAdjustDTO;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author caosg
 * @version V1.0
 * @Description: Jsontype转换器
 * @date 2017/12/14 下午3:42
 */
@MappedTypes(value = OrderAdjustDTO.class)
public class OrderAdjusntJsonTypeHandler extends JsonTypeHandler<OrderAdjustDTO> {
    public OrderAdjusntJsonTypeHandler(Class<OrderAdjustDTO> clazz) {
        super(clazz);
    }
}
