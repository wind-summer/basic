package com.suyun.core.module.bidding.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author wlf
 * @since 2017-12-28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName(value = "sy_bidding_deposit",resultMap = "BaseResultMap")
public class BiddingDeposit extends BaseEntity<BiddingDeposit> {

    private static final long serialVersionUID = 1L;

    /**
     * 关联竞价产品ID
     */
	@TableField("bidding_product_id")
	@NotNull(message = "要绑定的产品ID不能为空")
	private Long biddingProductId;
    /**
     * 关联客户ID
     */
	@TableField("customer_id")
	private Long customerId;
    /**
     * 保证金
     */
	private BigDecimal deposit;
    /**
     * 是否已退款1：是，0：否
     */
	@TableField("is_refunded")
	private Boolean refunded;
    /**
     * 创建日期
     */
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
    /**
     * 修改日期
     */
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;

	/**
	 * 验证码
	 */
	@TableField(exist = false)
	private String verifyCode;

	/**
	 * 手机号
	 */
	@TableField(exist = false)
	private String mobileNumber;
}
