package com.suyun.core.module.order.service;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单模块常量类
 * @date 2017/12/11 上午10:44
 */
public interface OrderConstant {

    String STATE_MACHINE_ID ="orderStateMachine";

    String EVENT_MESSAGE_HEADER_KEY = "order";

    String MANUAL_CANCEL_ORDER_FLAG = "manual:cancel:order:flag" ;

    String ORDER_CODE_PREFIX  = "SO";

    String AWAITING_CONFIRM_ORDER_KEY = "no-cofirm:order";

    String AWAITING_PAY_ORDER_KEY = "no-pay:order";
}
