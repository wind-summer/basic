package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.order.dao.OrderAdjustmentDao;
import com.suyun.core.module.order.entity.OrderAdjustment;
import com.suyun.core.module.order.service.OrderAdjustmentService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Service
public class OrderAdjustmentServiceImpl extends ServiceImpl<OrderAdjustmentDao, OrderAdjustment> implements OrderAdjustmentService {

}
