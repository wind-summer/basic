package com.suyun.core.module.bidding.service.dto;

import com.suyun.core.module.bidding.enums.BiddingRecordStatus;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author wlf
 * @version V1.0
 * @Description: TODO
 * @date 2018/1/3 上午10:45
 */

@Data
@Accessors(chain = true)
public class BiddingRecordDTO {
    /**
     * 竞价记录Id(前台：订单编号)
     */
    private Long id;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 产品名称
     */
    private String productName;
    /**
     * 类别名称
     */
    private String categoryName;
    /**
     *规格/牌号
     */
    private String gradeCode;
    /**
     * 产地编码
     */
    private String manufacturerCode;
    /**
     * 库别编码
     */
    private String warehouseCode;
    /**
     * 单位编码
     */
    private String unitCode;
    /**
     * 总金额
     */
    private BigDecimal allAmount;
    /**
     * 竞价数量
     */
    private Long biddingQuantity;
    /**
     * 竞价单价
     */
    private BigDecimal biddingPrice;

    /**
     * 起拍单价
     */
    private BigDecimal startUnitPrice;

    /**
     * 保证金额
     */
    private BigDecimal deposit;
    /**
     * 创建时间
     */
    private Date createDate;
    /**
     * 竞价数量
     */
    private BiddingRecordStatus biddingStatus;
    /**
     * 竞价产品ID
     */
    private Long biddingProductId;
}
