package com.suyun.core.module.account.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.common.exception.BizException;
import com.suyun.core.module.account.dao.AccountTransDao;
import com.suyun.core.module.account.entity.AccountTrans;
import com.suyun.core.module.account.service.AccountConstant;
import com.suyun.core.module.account.service.AccountTransService;
import com.suyun.core.utils.CurrentUserUtils;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

/**
 * <p>
 * 账户交易明细
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@Service
public class AccountTransServiceImpl extends ServiceImpl<AccountTransDao, AccountTrans> implements AccountTransService {

    /**
     * 创建账户交易
     *
     * @param accountTrans
     * @return
     */
    @Override
    public boolean createAccountTrans(AccountTrans accountTrans) {
        return this.insert(accountTrans);
    }

    /**
     * 查询当前用户收支列表
     *
     * @param map
     * @return
     */
    @Override
    public Page<AccountTrans> findAccountTrans(Map<String, Object> map, Page<AccountTrans> page) {
        map.put(AccountConstant.CUSTOMER_ID, CurrentUserUtils.getLogin().getCustomerId().toString());
        if(map.containsKey("parameter")){
            map.put("parameter",map.get("parameter").toString().replace(" ", ""));
        }
        return Optional.ofNullable(baseMapper.findAccountTransByCondition(map, page))
                .map(trans -> {
                    return page.setRecords(trans);
                }).orElseThrow((() -> new BizException("支付明细列表不存在")));
    }

}
