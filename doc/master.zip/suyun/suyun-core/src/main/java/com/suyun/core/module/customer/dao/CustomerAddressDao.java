package com.suyun.core.module.customer.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.entity.CustomerAddress;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerAddressDao extends BaseMapper<CustomerAddress> {

    /**
     * 根据id修改为默认地址
     * @param customerId
     * @param id
     */
    void updateIsDefault(@Param("customerId") Long customerId, @Param("id") Long id);

    /**
     * 清除默认地址
     * @param customerId
     */
    void resetDefaultAddress(@Param("customerId") Long customerId);

    /**
     * 获取当前登录人默认收货地址
     * @param customerId
     * @return
     */
    Address getdefaultaddress(@Param("customerId") Long customerId);
}
