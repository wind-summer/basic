package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.order.dao.OrderItemDao;
import com.suyun.core.module.order.entity.OrderItem;
import com.suyun.core.module.order.service.OrderItemService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Service
public class OrderItemServiceImpl extends ServiceImpl<OrderItemDao, OrderItem> implements OrderItemService {

}
