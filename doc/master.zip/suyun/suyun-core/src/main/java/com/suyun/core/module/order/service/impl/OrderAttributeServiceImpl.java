package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.order.dao.OrderAttributeDao;
import com.suyun.core.module.order.entity.OrderAttribute;
import com.suyun.core.module.order.service.OrderAttributeService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Service
public class OrderAttributeServiceImpl extends ServiceImpl<OrderAttributeDao, OrderAttribute> implements OrderAttributeService {

}
