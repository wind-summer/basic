package com.suyun.core.module.bidding.dao;

import com.suyun.core.module.bidding.entity.BiddingDeposit;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wlf
 * @since 2017-12-28
 */
public interface BiddingDepositDao extends BaseMapper<BiddingDeposit> {

}
