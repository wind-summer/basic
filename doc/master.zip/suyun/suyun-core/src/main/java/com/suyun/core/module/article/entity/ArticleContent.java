package com.suyun.core.module.article.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.sys.entity.BaseEntity;

import com.baomidou.mybatisplus.annotations.Version;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 文章详细内容
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_article_content")
public class ArticleContent extends BaseEntity<ArticleContent> {

    private static final long serialVersionUID = 1L;

    /**
     * 文章内容
     */
	private String content;
	@TableField("article_id")
	private Long articleId;



}
