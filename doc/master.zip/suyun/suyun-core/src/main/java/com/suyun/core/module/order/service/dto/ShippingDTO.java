package com.suyun.core.module.order.service.dto;

import com.suyun.core.module.order.entity.OrderShipping;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2018/3/6 上午10:25
 */
@Data
public class ShippingDTO {
    //已发货数量
    private BigDecimal shippedQuantity;
    //未发货数量
    private BigDecimal noQuantity;
    //发货记录
    List<OrderShipping> records;
}
