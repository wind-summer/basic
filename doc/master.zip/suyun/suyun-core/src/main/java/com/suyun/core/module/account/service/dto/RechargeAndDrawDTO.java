package com.suyun.core.module.account.service.dto;

import com.baomidou.mybatisplus.annotations.TableField;
import com.suyun.core.module.account.enums.ApplyStatus;
import com.suyun.core.module.customer.service.dto.BankAttributeDTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zhangjq
 * @Description:
 * @date 2017年12月29日 18：:2
 */
@Data
@Accessors(chain = true)
public class RechargeAndDrawDTO {
    /**
     * 充值或者提现申请id
     */
    private Long id;

    /**
     * 充值金额
     */
    private BigDecimal amount;

    /**
     * 客户手机号
     */
    private String phone;

    /**
     * 付款识别码
     */
    private String paymentCode;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 账户编码
     */
    private String acccountCode;


    /**
     * 商户银行账户信息
     */
    private BankAttributeDTO bankAttributeDTO;

    /**
     * 充值提现标识  1充值 2提现
     */
    private Integer identification;

    /**
     * 创建时间
     */
    private Date createAt;

    /**
     * true 未过期 false已过期
     */
    private boolean canCancel;

    /**
     * 支付凭证上传路径
     */
    private String picture;

    /**
     * 0：待审核
     * 1：审核通过
     * 2：审核不通过
     */
    private ApplyStatus status;
}
