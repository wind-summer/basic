package com.suyun.core.module.account.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.annotations.Version;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.account.enums.ApplyStatus;
import com.suyun.core.module.account.enums.TransReason;
import com.suyun.core.module.customer.service.dto.BankAttributeDTO;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 账户充值提现申请
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_account_apply")
public class AccountApply extends BaseEntity<AccountApply> {

    private static final long serialVersionUID = 1L;

    /**
     * 申请单流水号
     */
    @TableField("apply_code")
    private String applyCode;
    /**
     * 金额
     */
    @Version
    private BigDecimal amount;
    ;
    @TableField(value = "create_at", fill = FieldFill.INSERT)
    private Date createAt;
    @TableField(value = "update_at", fill = FieldFill.UPDATE)
    private Date updateAt;
    /**
     * 扩展信息
     */
    private String attibutes;
    /**
     * 操作人员
     */
    @TableField("update_by")
    private String updateBy;
    /**
     * 用户ID
     */
    @TableField("customer_id")
    private Long customerId;
    @TableField("account_id")
    private Long accountId;
    /**
     * 0：待审核
     * 1：审核通过
     * 2：审核不通过
     */
    @TableField("status")
    private ApplyStatus status;

    /**
     * 付款凭证图片
     */
    @TableField("picture")
    private String picture;

    /**
     * 付款识别码
     */
    @TableField(exist = false)
    private String paymentCode;

    /**
     * 用户类型
     */
    @TableField(exist = false)
    private String roleName;

    /**
     * 申请人手机号
     */
    @TableField(exist = false)
    private String phone;

    /**
     * 客户名称
     */
    @TableField(exist = false)
    private String customerName;

    /**
     * 账户可用余额
     */
    @TableField(exist = false)
    private BigDecimal avaliableAmount;

    /**
     * 客户银行信息
     */
    @TableField(exist = false)
    private BankAttributeDTO dto;

    /**
     * 支出原因
     * 0：申请充值
     * 1：申请提现
     */
    @TableField(exist = false)
    private TransReason reasonType;
}
