package com.suyun.core.module.account.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.account.entity.AccountTrans;

import java.util.Map;

/**
 * <p>
 * 账户收支明细 服务类
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
public interface AccountTransService extends IService<AccountTrans> {

    /**
     * 创建收支明细
     *
     * @param accountTrans
     * @return
     */
    boolean createAccountTrans(AccountTrans accountTrans);

    /**
     * 查询登录用户的收支列表
     *
     * @param map
     * @param page
     * @return
     */
    Page<AccountTrans> findAccountTrans(Map<String, Object> map, Page<AccountTrans> page);


}
