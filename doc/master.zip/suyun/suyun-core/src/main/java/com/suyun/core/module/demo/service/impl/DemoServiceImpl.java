package com.suyun.core.module.demo.service.impl;

import com.suyun.common.annotation.DataSource;
import com.suyun.core.module.demo.entity.Demo;
import com.suyun.core.module.demo.dao.DemoDao;
import com.suyun.core.module.demo.service.DemoService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 示例Demo 服务实现类,支持JSON数据类型
 * </p>
 *
 * @author caosg
 * @since 2017-11-23
 */
@Service
@AllArgsConstructor
@Slf4j
public class DemoServiceImpl extends ServiceImpl<DemoDao, Demo> implements DemoService {

    private final DemoDao demoDao;

    @Override
    public void saveDemoWithJson(Demo demo) {
        baseMapper.saveJson(demo);
    }

    @Override
    @DataSource(name="second")
    public void testOracle(){
        List<String> ls = demoDao.getId();
        for (int i = 0; i < ls.size(); i++) {
            System.out.println(ls.get(i));
        }
    }
}
