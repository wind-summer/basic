package com.suyun.core.module.article.dao;

import com.suyun.core.module.article.entity.ArticleContent;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 文章详细内容 Mapper 接口
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
public interface ArticleContentDao extends BaseMapper<ArticleContent> {

}
