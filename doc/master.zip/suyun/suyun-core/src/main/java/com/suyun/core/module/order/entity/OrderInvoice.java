package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 订单发票
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_invoice")
public class OrderInvoice extends BaseEntity<OrderInvoice> {

    private static final long serialVersionUID = 1L;

    /**
     * 发票抬头
     */
	private String title;
    /**
     * 发票编号
     */
	@TableField("invoice_number")
	private String invoiceNumber;
    /**
     * 发票金额
     */
	private BigDecimal amount;
    /**
     * 是否已开票 1：已开票 0：未开票
     */
	@TableField("is_open")
	private Boolean open;
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;
	@TableField("order_id")
	private Long orderId;


}
