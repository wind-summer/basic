package com.suyun.core.module.customer.service;

/**
 * 客户常量类
 * @author luy
 * @date 2018年1月16日 11:39:30
 */
public interface CustomerConstant {
    /**
     * 客户编码前缀
     */
    String CUSTOMER_CODE_PREFIX = "TY";
}
