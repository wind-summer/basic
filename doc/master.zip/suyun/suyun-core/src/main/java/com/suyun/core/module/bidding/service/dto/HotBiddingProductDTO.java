package com.suyun.core.module.bidding.service.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class HotBiddingProductDTO {
    /**
     * 竞价产品ID
     */
    private Long biddingProductId;
    /**
     * 竞价规则ID
     */
    private Long biddingRuleId;
    /**
     * sku ID
     */
    private Long skuId;
    /**
     * 产品名称
     */
    private String productName;
    /**
     * 结束时间
     */
    private Date endDate;
    /**
     * 系统当前时间
     */
    private Date nowDate;
}
