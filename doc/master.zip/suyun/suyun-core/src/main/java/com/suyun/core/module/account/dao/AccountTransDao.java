package com.suyun.core.module.account.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.account.entity.AccountTrans;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 账户收支明细 Mapper 接口
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
public interface AccountTransDao extends BaseMapper<AccountTrans> {

    /**
     * 收支记录条件查询
     *
     * @param map
     * @param page
     * @return
     */
    List<AccountTrans> findAccountTransByCondition(Map<String, Object> map, Page<AccountTrans> page);

}
