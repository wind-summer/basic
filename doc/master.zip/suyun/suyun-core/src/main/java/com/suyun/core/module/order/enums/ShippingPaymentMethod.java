package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 运费结算方式
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum ShippingPaymentMethod implements IEnum {

    ONE("0","一票制"),
    TWO("1","二票制");

    private String value;
    private String desc;

    ShippingPaymentMethod(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}