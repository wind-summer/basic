package com.suyun.core.module.order.service.dto;

import com.suyun.core.module.order.enums.PaymentMethod;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/14 下午2:47
 */
@Data
public class AdjustParamDTO {

    private Long orderId;
    @NotNull
    private PaymentMethod paymentMethod;
    @NotNull
    private String extCustomerCode;
    private List<ItemAdjustVM> items;
    public static class ItemAdjustVM{
        private Long itemId;
        private BigDecimal quantity;
        private BigDecimal price;

        public Long getItemId() {
            return itemId;
        }

        public void setItemId(Long itemId) {
            this.itemId = itemId;
        }

        public BigDecimal getQuantity() {
            return quantity;
        }

        public void setQuantity(BigDecimal quantity) {
            this.quantity = quantity;
        }

        public BigDecimal getPrice() {
            return price;
        }

        public void setPrice(BigDecimal price) {
            this.price = price;
        }
    }
}
