package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_push")
public class OrderPush extends BaseEntity<OrderPush> {

    private static final long serialVersionUID = 1L;

	@TableField("order_id")
	private Long orderId;
    /**
     * 状态 0：失败 1：成功
     */
	private Integer status;
	private String remark;
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;


}
