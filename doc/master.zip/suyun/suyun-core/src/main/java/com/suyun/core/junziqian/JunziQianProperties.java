package com.suyun.core.junziqian;

import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author caosg
 * @version V1.0
 * @Description: 君子签配置信息
 * @date 2018/2/7 下午2:30
 */
@Getter
@Configuration
@ConfigurationProperties(prefix = "junziqian")
public class JunziQianProperties {
    private String serviceUrl;
    private String appKey;
    private String appSecret;
    private String orderSignName;
    private String orderSignTmlNo;
    private float  offsetX;
    private float  offsetY;
    private float  height;
    private int expireTime;
    private String backUrl;

    private final Company company = new Company();

    public String getServiceUrl() {
        return serviceUrl;
    }

    public void setServiceUrl(String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public void setOrderSignName(String orderSignName) {
        this.orderSignName = orderSignName;
    }

    public void setOrderSignTmlNo(String orderSignTmlNo) {
        this.orderSignTmlNo = orderSignTmlNo;
    }

    public void setOffsetX(float offsetX) {
        this.offsetX = offsetX;
    }

    public void setOffsetY(float offsetY) {
        this.offsetY = offsetY;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public int getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(int expireTime) {
        this.expireTime = expireTime;
    }

    public String getBackUrl() {
        return backUrl;
    }

    public void setBackUrl(String backUrl) {
        this.backUrl = backUrl;
    }

    public static class Company{
        private String name;
        private String idCard;
        private String mobile;
        private String email;
        private float  offsetX;
        private float  offsetY;
        private float  height;
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIdCard() {
            return idCard;
        }

        public void setIdCard(String idCard) {
            this.idCard = idCard;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public float getOffsetX() {
            return offsetX;
        }

        public void setOffsetX(float offsetX) {
            this.offsetX = offsetX;
        }

        public float getOffsetY() {
            return offsetY;
        }

        public void setOffsetY(float offsetY) {
            this.offsetY = offsetY;
        }

        public float getHeight() {
            return height;
        }

        public void setHeight(float height) {
            this.height = height;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

    }
}
