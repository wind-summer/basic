package com.suyun.core.module.account.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author zhangjq
 * @Description:
 * @date 2017年12月29日 18：:22
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WithDrawApplyDTO {

    /**
     * 手机验证码
     */
    @NotBlank(message = "手机验证码不能为空")
    private String code;

    /**
     * 提现金额
     */
    @NotNull(message = "金额不能为空")
    @DecimalMin(value = "0.01", message = "金额最小0.01元")
    private BigDecimal amount;

    /**
     * 客户id
     */
    private Long customerId;
}
