package com.suyun.core.module.bidding.service.dto;

import com.suyun.core.module.order.entity.OrderItem;
import com.suyun.core.module.order.enums.PaymentMethod;
import com.suyun.core.module.order.enums.ShippingMethod;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@Accessors(chain = true)
public class BiddingOrderDTO {
    /**
     * 竞价记录Id
     */
    private Long recordId;
    /**
     * 竞价产品Id
     */
    private Long biddingProductId;
    /**
     * 地址ID
     */
    private Long addressId;
    /**
     * 备注
     */
    private String remark;
    /**
     * 总计费用
     */
    private BigDecimal total;
    /**
     * 付款方式
     */
    private PaymentMethod paymentMethod;
    /**
     * 发货方式
     */
    private ShippingMethod shippingMethod;
    /**
     * 商品明细列表
     */
    private List<OrderItem> itemList;
}
