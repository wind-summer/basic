package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.enums.CustomerTypeEnum;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Date;



/**
 * <p>
 *
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_customer")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Customer extends BaseEntity<Customer> {
	private static final long serialVersionUID = 1L;

	/**
	 * 姓名
	 */
	@NotBlank(message = "企业名称不能为空")
	@Size(max=40,message = "企业名称长度最多不超过40")
	private String name;

	/**
	 * 企业联系人
	 */
	@NotBlank(message = "企业联系人不能为空")
	@Size(max=20,message = "企业联系人长度最多不超过20")
	private String linker;

	/**
	 * 描述
	 */
	@Size(max=200,message = "企业简介长度最多不超过200")
	private String description;

	@TableField("logo_url")
	@Pattern(regexp = "^((https|http)?:\\/\\/)[^\\s]+")
	private String logoUrl;
	/**
	 * 手机号
	 */
	@TableField("primary_phone")
	@NotBlank(message = "手机号码不能为空")
	@Pattern(regexp = "^[1][3,4,5,7,8][0-9]{9}$")
	@Size(min = 11,max = 20,message = "手机号码长度不符")
	private String primaryPhone;
	/**
	 * 备用联系电话
	 */
	@TableField("second_phone")
	private String secondPhone;

	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;
	@TableField("create_by")
	private String createBy;
	@TableField("update_by")
	private String updateBy;

	@TableField("customer_type_id")
	private CustomerTypeEnum customerType;

	/**
	 * 经度
	 */
	@NotBlank(message = "公司坐标不能为空")
	@TableField("longitude")
	private String longitude;
	/**
	 * 纬度
	 */
	@NotBlank(message = "公司坐标不能为空")
	@TableField("latitude")
	private String latitude;

	/**
	 * 传真
	 */
	@TableField("fax")
	@Size(max=18,message = "传真长度最多不超过18")
	private String fax;

	/**
	 * 邮箱
	 */
	@Email
	@TableField("email")
	@NotBlank(message = "邮箱不能为空")
	@Size(max=30,message = "邮箱长度最多不超过30")
	private String email;

	/**
	 * 审核状态
	 */
	@TableField("audit_status")
	private CustomerStatusEnum status;

	/**
	 * 审核失败原因
	 */
	@TableField("fail_reasonl")
	@Size(max=100,message = "审核失败原因长度最多不超过100")
	private String failReasonl;

	/**
	 * 省代码
	 */
	@TableField("province")
	@NotNull(message = "省不能为空")
	private Long province;
	@TableField("province_name")
	private String provinceName;

	/**
	 * 城市代码
	 */
	@TableField("city")
	@NotNull(message = "市不能为空")
	private Long city;
	@TableField("city_name")
	private String cityName;
	/**
	 * 区县代码
	 */
	@NotNull(message = "区县不能为空")
	@TableField("area")
	private Long area;
	@TableField("area_name")
	private String areaName;

	/**
	 * 浪潮唯一标识
	 */
	@TableField("erp_code")
	private String erpCode;

	/**
	 * 客户编码
	 */
	@TableField("code")
	private String code;

	/**
	 * 电子签章源文件
	 */
	@NotBlank(message = "电子签章源文件不能为空")
	@TableField("sign_application")
	private String signApplication;


	/**
	 * 电子签章
	 */
	@TableField("sign_img")
	private String signImg;

	/**
	 * 冗余-社会信用代码/营业执照
	 */
	@TableField("organization_teg_no")
	private String organizationTegNo;

}

