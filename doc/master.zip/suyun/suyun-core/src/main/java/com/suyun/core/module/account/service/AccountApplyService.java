package com.suyun.core.module.account.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.account.entity.AccountApply;
import com.suyun.core.module.account.service.dto.ApplyDTO;
import com.suyun.core.module.account.service.dto.RechargeAndDrawDTO;
import com.suyun.core.module.account.service.dto.RechargeDTO;
import com.suyun.core.module.account.service.dto.WithDrawApplyDTO;

import java.math.BigDecimal;
import java.util.Map;

/**
 * <p>
 * 账户充值提现申请 服务类
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
public interface AccountApplyService extends IService<AccountApply> {

    /**
     * 创建交易申请
     *
     * @param accountApply
     * @return
     */
    void createApply(ApplyDTO accountApply);

    /**
     * 用ID查询申请信息
     *
     * @param applyId
     * @return
     */
    RechargeAndDrawDTO findAccountApplyById(Long applyId);


    /**
     * 充值成功
     *
     * @param applyId
     * @return
     */
    boolean success(Long applyId);

    /**
     * 充值失败
     *
     * @param applyId
     * @return
     */
    boolean failure(Long applyId);

    /**
     * 提现后台审核
     *
     * @param applyId
     * @return
     */
    boolean withDrawApply(Long applyId);

    /**
     * 申请提现
     *
     * @param withDrawApplyDTO
     * @return
     */
    void withDraw(WithDrawApplyDTO withDrawApplyDTO);

    /**
     * 冻结部分账户金额
     *
     * @param accountId
     * @param freeze
     * @param reason
     * @return
     * @throws Exception
     */
    boolean freeze(Long accountId, BigDecimal freeze, Integer reason);

    /**
     * 解冻部分账户金额
     *
     * @param accountId
     * @param freeze
     * @param reason
     * @return
     * @throws Exception
     */
    boolean unfreeze(Long accountId, BigDecimal freeze, Integer reason);

    /**
     * 冻结账户金额
     * @param accountId
     */
    void frost(Long accountId);

    /**
     * 解冻账户金额
     * @param accountId
     */
    void unfrost(Long accountId);

    /**
     * 调整额度
     *
     * @param accountId
     * @param freeze
     * @return
     * @throws Exception
     */
    boolean adjust(Long accountId, BigDecimal freeze);

    /**
     * 条件获取申请分页列表
     *
     * @param map
     * @param page
     * @return
     */
    Page<AccountApply> findAccountPageByCondition(Map<String, Object> map, Page<AccountApply> page);

    /**
     * 根据用户ID冻结 对竞拍等业务
     *
     * @param customerId
     * @param freeze
     * @param reason
     * @return
     */
    boolean freezeByCustomerId(Long customerId, BigDecimal freeze, Integer reason);

    /**
     * 根据用户ID解冻 对竞拍等业务
     *
     * @param customerId
     * @param freeze
     * @param reason
     * @return
     */
    boolean unFreezeByCustomerId(Long customerId, BigDecimal freeze, Integer reason);

    /**
     * 充值申请统计数量
     *
     * @return
     */
    Integer rechargeCount();

    /**
     * 提现申请统计数量
     *
     * @return
     */
    Integer withDrawCount();

    /**
     * 账户充值前查询信息
     *
     * @return
     */
    RechargeDTO findRecharge();
}
