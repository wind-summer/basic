package com.suyun.core.module.account.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 支出原因
 *
 * @author zhangjq
 * @Date 2017-12-29
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum TransReason implements IEnum {

    //表示这条记录产生于收入
    OFFLINE_TOPUP(0, "收入"),
    //表示这条记录产生于支出
    WITH_DRAW(1, "支出"),
    //表示这条记录产生于消费
    EXPENSE_TRANS(2, "消费"),
    //表示这条记录产生于退款
    REFUND_TRANS(3, "退款"),
    //表示这条记录产生于竞价
    BIDD_TRANS(4, "竞价");

    private Integer value;
    private String desc;

    TransReason(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return this.desc;
    }


    @Override
    public String toString() {
        return "ApplyStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
