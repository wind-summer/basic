package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.order.enums.*;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order")
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class Order extends BaseEntity<Order> {

    private static final long serialVersionUID = 1L;

	@TableField("order_code")
	private String orderCode;
    /**
     * 订单状态
     */
	@TableField("order_status")
	private OrderStatus orderStatus = OrderStatus.INIT;
    /**
     * 订单费用小计
     */
	@TableField("sub_total")
	private BigDecimal subTotal = new BigDecimal(0);
    /**
     * 订单费用总计
     */
	private BigDecimal total;
    /**
     * 运费
     */
	@TableField("total_shipping")
	private BigDecimal totalShipping = new BigDecimal(0);
    /**
     * 税费
     */
	@TableField("total_tax")
	private BigDecimal totalTax;
	@TableField("customer_id")
	private Long customerId;
    /**
     * 配送方式
     */
	@TableField("shipping_method")
	@NotNull
	private ShippingMethod shippingMethod;
    /**
     * 付款方式
     */
	@TableField("payment_method")
	@NotNull
	private PaymentMethod paymentMethod;
    /**
     * 运费结算方式
     */
	@TableField("shipping_payment_method")
	@NotNull
	private ShippingPaymentMethod shippingPaymentMethod;

	/**
	 * 订单类型，默认销售订单
	 */
	@TableField("order_type")
	private OrderType orderType = OrderType.SALE;

	@TableField(value = "create_date" ,fill = FieldFill.INSERT)
	private Date createDate;
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;
	@TableField(value = "create_by",fill = FieldFill.INSERT)
	private String createBy;
	@TableField(value = "update_by",fill = FieldFill.UPDATE)
	private String updateBy;
    /**
     * 备注信息
     */
	private String remark;
    /**
     * 发货状态
     */
	@TableField("shipping_status")
	private YesOrNo shippingStatus = YesOrNo.NO;
    /**
     * 支付状态
     */
	@TableField("payment_status")
	private YesOrNo paymentStatus = YesOrNo.NO;
    /**
     * 电子合同签约状态
     */
	@TableField("sign_status")
	private ContractStatus signStatus = ContractStatus.INIT;

    /**
     * 收货地址
     */
	@TableField("address_id")
	@NotNull
	private Long addressId;

    @TableField(exist=false)
	private  List<OrderItem> items;

	@TableField(exist=false)
    private Customer customer;

	@TableField("reserve_attribute1")
	private String reserveAttribute1;
	@TableField("reserve_attribute2")
    private String reserveAttribute2;

	//订单同步erp状态，不存数据库
	@TableField(exist = false)
	private OrderPush orderPush;
}
