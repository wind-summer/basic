package com.suyun.core.module.financing.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Size;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 融资申请表
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_financing_apply")
public class FinancingApply extends BaseEntity<FinancingApply> {

    private static final long serialVersionUID = 1L;

    /**
     * 融资额度code
     */

    @NotBlank(message = "融资额度不能为空")
    @TableField("financing_code")
    private String financingCode;

    /**
     * 手机号
     */
    @NotBlank(message = "手机号不能问为空")
	private String mobile;
    /**
     * 公司名称
     */
    @NotBlank(message = "公司名称不能为空")
    @Size(max = 100,message = "公司名称最大长度为100个字符")
    @TableField("company_name")
    private String companyName;

    /**
     * 用户姓名
     */
    @NotBlank(message = "姓名不能为空")
	@TableField("user_name")
	private String userName;
    /**
     * 添加时间
     */
	@TableField(value = "create_date",fill= FieldFill.INSERT)
	private Date createDate;


	/**
	 * 融资申请沟通日志
	 */
	@TableField(exist = false)
	private List<FinancingContactLog> financingContactLogs;

}
