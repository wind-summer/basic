package com.suyun.core.module.bidding.service;

/**
 * @author wlf
 * @version V1.0
 * @Description: 竞价模块常量类
 * @date 2018/1/6 上午10:44
 */
public interface BiddingConstant {

    String AWAITING_START_BIDDING_PRODUCT_KEY = "no-start:bidding:product";

    String AWAITING_END_BIDDING_PRODUCT_KEY = "no-end:bidding:product";

    String ONLOOKERS_BIDDING_PRODUCT_KEY = "onlookers:bidding:product";
}
