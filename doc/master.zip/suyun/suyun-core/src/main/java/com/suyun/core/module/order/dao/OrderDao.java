package com.suyun.core.module.order.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.order.entity.Order;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
public interface OrderDao extends BaseMapper<Order> {

    /**
     * 多条件查询
     * @param params
     * @param page
     * @return
     */
    List<Order>  queryAllOrder(Map<String,Object> params, Page<Order> page);

}
