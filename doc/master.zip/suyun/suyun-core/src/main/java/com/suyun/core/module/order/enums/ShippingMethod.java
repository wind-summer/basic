package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 配送方式
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum ShippingMethod implements IEnum {

    SHIPPING("0","配送"),
    SELF("1","自提");

    private String value;
    private String desc;

    ShippingMethod(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
