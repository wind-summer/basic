package com.suyun.core.module.customer.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author caosg
 * @version V1.0
 * @Description: 定义CustomerAttribute 属性名称
 * @date 2017/12/1 下午4:00
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum  CustomerAttributeEnum implements IEnum{

    BASE ("CUSTOMER_BASE","客户基本信息"),
    BUSINESS("CUSTOMER_BUSINESS","客户工商信息"),
    BANK("CUSTOMER_BANK","客户银行信息");

    private String value;
    private String desc;

    CustomerAttributeEnum(final String value, final String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }

}
