package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_login_token")
public class LoginToken extends Model<LoginToken> {

    private static final long serialVersionUID = 1L;

	private Long id;
	private String token;
    /**
     * 失效时间
     */
	@TableField("expire_time")
	private Date expireTime;
    /**
     * 修改时间
     */
	@TableField("update_time")
	private Date updateTime;
	@TableField("customer_login_id")
	private Long customerLoginId;


	@Override
	protected Serializable pkVal() {
		return this.id;
	}

}
