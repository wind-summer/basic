package com.suyun.core.module.physicallibrary.dao;

import com.suyun.core.module.physicallibrary.entity.BasePropDetail;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.physicallibrary.service.dto.BaseProductTestDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 物性明细表 Mapper 接口
 * </p>
 *
 * @author zjq
 * @since 2018-01-12
 */
public interface BasePropDetailDao extends BaseMapper<BasePropDetail> {

    /**
     * 根据产品ID查询产品详细信息
     * @param param
     * @return
     */
    List<BaseProductTestDTO> findBaseProductDetailByProductId(@Param("productId") String param);

}
