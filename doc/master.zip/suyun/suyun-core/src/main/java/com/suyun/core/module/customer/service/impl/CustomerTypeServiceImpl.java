package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.customer.dao.CustomerTypeDao;
import com.suyun.core.module.customer.entity.CustomerType;
import com.suyun.core.module.customer.service.CustomerTypeService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
public class CustomerTypeServiceImpl extends ServiceImpl<CustomerTypeDao, CustomerType> implements CustomerTypeService {

}
