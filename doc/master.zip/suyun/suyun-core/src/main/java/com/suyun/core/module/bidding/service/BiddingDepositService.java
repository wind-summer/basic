package com.suyun.core.module.bidding.service;

import com.suyun.core.module.bidding.entity.BiddingDeposit;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wlf
 * @since 2017-12-28
 */
public interface BiddingDepositService extends IService<BiddingDeposit> {

    /**
     * 添加保证金记录表数据
     * @param biddingDeposit
     */
    void addBiddingDeposit(BiddingDeposit biddingDeposit);
}
