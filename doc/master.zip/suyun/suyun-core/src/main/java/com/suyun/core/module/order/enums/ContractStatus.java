package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 签约状态,1 已签、2 拒签、3 保全
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum ContractStatus implements IEnum {
    UPLOADED(0,"已上传"),
    SUCCESS(1,"已签"),
    REJECT(2,"拒签"),
    PERSIST(3,"保全"),
    INIT(4,"未上传");

    private Integer value;
    private String desc;

    ContractStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }


    @Override
    public String toString() {
        return "ContractStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }

    public static ContractStatus getContractStatusByValue(Integer value){
        switch (value) {
            case 0:
                return UPLOADED;
            case 1:
                return SUCCESS;
            case 2:
                return REJECT;
            case 3:
                return PERSIST;
            default:
                return INIT;


        }
    }


}
