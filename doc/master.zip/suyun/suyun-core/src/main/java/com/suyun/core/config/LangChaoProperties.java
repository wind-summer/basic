package com.suyun.core.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 浪潮ERP配置文件
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "langchao")
public class LangChaoProperties {

    /**
     * 公司
     */
    private String companyCode;

    /**
     * 连接地址
     */
    private String serviceUrl;
}
