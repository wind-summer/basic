package com.suyun.core.module.bidding.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.annotations.Version;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.bidding.enums.BiddingStatus;
import com.suyun.core.module.product.entity.Product;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName(value = "sy_bidding_rule_product",resultMap = "BaseResultMap")
public class BiddingRuleProduct extends BaseEntity<BiddingRuleProduct> {

    private static final long serialVersionUID = 1L;

	/**
	 * 关联产品id
	 */
	@TableField("product_id")
	private Long productId;
	/**
	 * 关联竞价规则id
	 */
	@TableField("bidding_rule_id")
	private Long biddingRuleId;
	/**
	 * 关联SKU产品id
	 */
	@TableField("sku_id")
	private Long skuId;
	/**
	 * 最大价格
	 */
	@TableField("max_price")
	private BigDecimal maxPrice;
	/**
	 * 最后一次竞价时间
	 */
	@TableField("last_bidding_time")
	private Date lastBiddingTime;
	/**
	 * 竞价产品状态0：已结束 1：待竞价 2：竞价中
	 */
	@TableField("bidding_status")
	private BiddingStatus biddingStatus;
	/**
	 * 起拍单价
	 */
	@TableField("start_unit_price")
	private BigDecimal startUnitPrice;
	/**
	 * 起拍数量
	 */
	@TableField("start_quantity")
	private Long startQuantity;
	/**
	 * 拍卖数量
	 */
	@TableField("quantity")
	private Long quantity;
	/**
	 * 最小跳量
	 */
	@TableField("min_jump_quantity")
	private Long minJumpQuantity;
	/**
	 * 数据单位
	 */
	@TableField("unit_code")
	private String unitCode;
	/**
	 * 乐观锁
	 */
	private Integer version;
	/**
	 * 创建时间
	 */
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
	/**
	 * 修改时间
	 */
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;

	/**
	 * 竞价结束时间
	 */
	@TableField("end_date")
	private Date endDate;

	/**
	 * 开始时间
	 */
	@TableField("start_date")
	private Date startDate;

	/**
	 * sku编码
	 */
	@TableField("sku_code")
	private String skuCode;

	/**
	 * 产品名称
	 */
	@TableField("product_name")
	private String productName;

	/**
	 * 类别ID
	 */
	@TableField("category_id")
	private Long categoryId;

	/**
	 * 分类名称
	 */
	@TableField("category_name")
	private String categoryName;

	/**
	 * 仓库编码
	 */
	@TableField("warehouse_code")
	private String warehouseCode;

	/**
	 * 产地编码
	 */
	@TableField("manufacturer_code")
	private String manufacturerCode;

	/**
	 * 规格/牌号 编码
	 */
	@TableField("grade_code")
	private String gradeCode;
	//****************************************下面是数据库中没有的字段**********************************
	/**
	 *	竞价规则
	 */
	@TableField(exist = false)
	private BiddingRule biddingRule;

	/**
	 *	产品信息
	 */
	@TableField(exist = false)
	private Product product;

	/**
	 *	sku信息
	 */
	@TableField(exist = false)
	private Sku sku;

	/**
	 *	竞价记录
	 */
	@TableField(exist = false)
	private List<BiddingRecord> biddingRecords;

}
