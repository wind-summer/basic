package com.suyun.core.module.order.statemachine;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.messaging.MessageHeaders;
import org.springframework.statemachine.StateMachineContext;
import org.springframework.statemachine.StateMachinePersist;
import org.springframework.statemachine.kryo.MessageHeadersSerializer;
import org.springframework.statemachine.kryo.StateMachineContextSerializer;
import org.springframework.statemachine.kryo.UUIDSerializer;
import org.springframework.statemachine.support.DefaultStateMachineContext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.UUID;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/9 下午7:52
 */
@Slf4j
public class InMemoryStateMachinePersist implements StateMachinePersist<OrderStatus, OrderEvent, String> {

    private static final ThreadLocal<Kryo> kryoThreadLocal = ThreadLocal.withInitial(() -> {
        Kryo kryo = new Kryo();
        kryo.addDefaultSerializer(StateMachineContext.class, new StateMachineContextSerializer());
        kryo.addDefaultSerializer(MessageHeaders.class, new MessageHeadersSerializer());
        kryo.addDefaultSerializer(UUID.class, new UUIDSerializer());
        return kryo;
    });

    private final RedisOperations<String, byte[]> redisOperations;

    public InMemoryStateMachinePersist(RedisConnectionFactory redisConnectionFactory) {
        redisOperations = createDefaultTemplate(redisConnectionFactory);
    }

    private static RedisTemplate<String, byte[]> createDefaultTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, byte[]> template = new RedisTemplate<>();
        template.setKeySerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setConnectionFactory(connectionFactory);
        template.afterPropertiesSet();
        return template;
    }


    @Override
    public void write(StateMachineContext<OrderStatus, OrderEvent> context, String contextObj) throws Exception {
        log.debug("Write orderId:{} StateMachineContext: \n  {}",contextObj,context );
        redisOperations.opsForValue().set("status:" + contextObj, serializeOrderStatus(context.getState()));
        redisOperations.opsForValue().set(contextObj, serialize(context));
    }


    @Override
    public StateMachineContext<OrderStatus, OrderEvent> read(String contextObj) throws Exception {
        StateMachineContext<OrderStatus, OrderEvent> context = deserialize(redisOperations.opsForValue().get(contextObj));
        log.debug("Read orderId:{} StateMachineContext:\n{}",contextObj,context);
        OrderStatus orderStatus = deserializeOrderStatus(redisOperations.opsForValue().get("status:" + contextObj));
        if (orderStatus != null) {
            context =
                    new DefaultStateMachineContext<>(orderStatus, context.getEvent(), null, context.getExtendedState(), null);
        }
        return context;
    }


    private byte[] serialize(StateMachineContext<OrderStatus, OrderEvent> context) {
        Kryo kryo = kryoThreadLocal.get();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Output output = new Output(out);
        kryo.writeObject(output, context);
        output.close();
        return out.toByteArray();
    }

    @SuppressWarnings("unchecked")
    private StateMachineContext<OrderStatus, OrderEvent> deserialize(byte[] data) {
        if (data == null || data.length == 0) {
            return null;
        }
        Kryo kryo = kryoThreadLocal.get();
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        Input input = new Input(in);
        return kryo.readObject(input, StateMachineContext.class);
    }

    private byte[] serializeOrderStatus(OrderStatus orderStatus) {
        Kryo kryo = kryoThreadLocal.get();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Output output = new Output(out);
        kryo.writeObject(output, orderStatus);
        output.close();
        return out.toByteArray();
    }

    private OrderStatus deserializeOrderStatus(byte[] data) {
        if (data == null || data.length == 0) {
            return null;
        }
        Kryo kryo = kryoThreadLocal.get();
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        Input input = new Input(in);
        return kryo.readObject(input, OrderStatus.class);
    }
}
