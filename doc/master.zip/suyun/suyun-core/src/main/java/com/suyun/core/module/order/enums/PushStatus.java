package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;

/**
 * @author caosg
 * @description 是否
 */
public enum PushStatus implements IEnum{

    STATUS_FAIL(0,"失败"),
    STATUS_SUCCESS(1,"成功");

    private Integer value;
    private String desc;

    PushStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
