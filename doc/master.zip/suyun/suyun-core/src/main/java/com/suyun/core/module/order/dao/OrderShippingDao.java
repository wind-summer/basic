package com.suyun.core.module.order.dao;

import com.suyun.core.module.order.entity.OrderShipping;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 发货记录 Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2018-03-05
 */
public interface OrderShippingDao extends BaseMapper<OrderShipping> {

}
