package com.suyun.core.module.customer.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.customer.entity.CustomerLogin;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 客户登陆信息 Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerLoginDao extends BaseMapper<CustomerLogin> {

    /**
     * 获取当前客户下所有员工信息
     * @param customerId
     * @param customerLogin
     * @return
     */
    List<CustomerLogin> getUserAll(@Param("customerId") Long customerId,@Param("customerLogin") CustomerLogin customerLogin,Page<CustomerLogin> page);

    /**
     * 找回密码
     * @param phone
     * @param password
     */
    void backPassword(@Param("phone")String phone,@Param("password") String password);

    /**
     * 修改密码
     * @param id
     * @param password
     */
    void updatePassword(@Param("id")Long id,@Param("password") String password);

    /**
     * 校验当前手机号是否存在
     * @param phone
     * @return
     */
    List<CustomerLogin> queryCustomerLoginByPhone(@Param("phone")String phone);

    /**
     * 修改登录号
     */
    void updataePhone(@Param("id")Long id,@Param("phone") String phone);

    /**
     * 判断登录帐号是否重复
     * @param login
     * @return
     */
    List<CustomerLogin> queryCustomerLoginByLogin(@Param("login") String login);

    /**
     * 判断员工姓名是否重复
     * @param userName
     * @return
     */
    List<CustomerLogin> getUserNameIsNull(@Param("userName") String userName);

}
