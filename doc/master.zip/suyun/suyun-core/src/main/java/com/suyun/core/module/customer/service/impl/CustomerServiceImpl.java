package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.suyun.common.exception.BizException;
import com.suyun.common.sms.BizType;
import com.suyun.common.sms.MsgService;
import com.suyun.common.sms.VerificationDTO;
import com.suyun.common.utils.RedisKeys;
import com.suyun.common.utils.SnowFlakeIdGenerator;
import com.suyun.common.validator.Assert;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.junziqian.customer.service.JzqCustomerService;
import com.suyun.core.module.customer.dao.AddressDao;
import com.suyun.core.module.customer.dao.CustomerDao;
import com.suyun.core.module.customer.dao.CustomerLoginDao;
import com.suyun.core.module.customer.entity.*;
import com.suyun.core.module.customer.enums.AddressTypeEnum;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.enums.CustomerTypeEnum;
import com.suyun.core.module.customer.exception.LoginFailException;
import com.suyun.core.module.customer.service.CustomerAddressService;
import com.suyun.core.module.customer.service.CustomerAttributeService;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.*;
import com.suyun.core.sys.service.SysAreaService;
import com.suyun.core.utils.CurrentUserUtils;
import com.suyun.core.utils.ShiroUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.suyun.core.module.customer.service.CustomerConstant.CUSTOMER_CODE_PREFIX;

/**
 * <p>
 *  客户服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
@AllArgsConstructor
@Slf4j
public class CustomerServiceImpl extends ServiceImpl<CustomerDao, Customer> implements CustomerService {

    private final ApplicationProperties applicationConfig;

    private final CustomerLoginDao loginDao;

    private final CustomerDao customerDao;

    private final AddressDao addressDao;

    private final CustomerAttributeService attributeService;

    private final CustomerAddressService customerAddressService;

    private final ObjectMapper objectMapper;

    private final RedisTemplate redisTemplate;

    private final MsgService msgService;

    private final SnowFlakeIdGenerator snowFlakeIdGenerator;

    private final SysAreaService sysAreaService;

    private final JzqCustomerService jzqCustomerService;

    /**
     * 添加客户详细信息
     *
     * @param customerDTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long addCustomer(CustomerDTO customerDTO) {
        log.info(" Add customer info:{}",customerDTO);
        Customer customer = customerDTO.getCustomer();
        //字段验证
        ValidatorUtils.validateEntity(customer);
        //校验手机号是否重复
        if(!this.getPhoneIsNull(customer.getPrimaryPhone())){
            throw new BizException("手机号码已存在，请重新录入");
        }
        //校验公司名称是否重复
        if(!this.getNameIsNull(customer.getName())){
            throw new BizException("公司名称已存在，请重新录入");
        }
        //初始化Customer
        customer.setCreateBy(ShiroUtils.getUserEntity().getUsername()).setCustomerType(CustomerTypeEnum.CUSTOMER).setCode(CUSTOMER_CODE_PREFIX+snowFlakeIdGenerator.nextId());
        this.buildCustomer(customer);
        this.insert(customer);
        CustomerLogin login = customerDTO.getLogin();
        //初始化客户登陆信息
        if(login==null){
            login = new CustomerLogin()
                    .setLogin(customer.getPrimaryPhone())
                    .setPassword(DigestUtils.md5Hex(applicationConfig.getSecurity().getDefaultPassword()))
                    .setActive(true).setAdmin(true).setLogoUrl(customer.getLogoUrl()).setMobileNo(customer.getPrimaryPhone());
        }
        login.setCustomerId(customer.getId());
        loginDao.insert(login);
        this.addCustomerAttributes(customer.getId(),customerDTO);
        this.updateAuditStatus(customer.getId(),CustomerStatusEnum.SUCCESS,"");
        return customer.getId();
    }

    /**
     * 后台修改客户信息
     * @param customerDTO
     */
    @Override
    public Long updateCustomerByBackstage(CustomerDTO customerDTO){
        log.info("Update customer info{}",customerDTO);
        Assert.isNull(customerDTO.getCustomer(),"客户信息不能为空");
        //基本信息
        Customer customer = customerDTO.getCustomer();
        ValidatorUtils.validateEntity(customer);
        //添加创建人、时间、类型
        customer.setUpdateBy(ShiroUtils.getUserEntity().getUsername()).setCustomerType(CustomerTypeEnum.CUSTOMER)
                .setStatus(CustomerStatusEnum.SUCCESS);
        this.buildCustomer(customer);
        this.updateById(customer);

        //详细信息
        this.addCustomerAttributes(customer.getId(),customerDTO);

        this.updateAuditStatus(customer.getId(),CustomerStatusEnum.SUCCESS,"");
        return customer.getId();
    }

    /**
     * 查询客户详情
     *
     * @param customerId 客户ID
     * @return
     */
    @Override
    public CustomerDTO getCustomer(Long customerId) {
        Customer customer = this.selectById(customerId);
        if(null == customer){  throw new BizException("根据 ID ["+customerId+"] 未获取到客户数据"); }
        CustomerAttribute customerAttribute = attributeService.selectOne(new EntityWrapper<CustomerAttribute>().eq("customer_id",customerId));
        List<CustomerAttributeDTO> attributeDTOS = null;
        if(customerAttribute!=null){
            attributeDTOS = this.getCustomerAttributeList(customerAttribute);
        }
        return new CustomerDTO(customer,null,attributeDTOS,customerAddressService.getDefaultAddressByCustomerId(customerId),"");
    }

    /**
     * 添加客户详细信息
     * @param customerId
     * @param customerDTO
     */
    private void  addCustomerAttributes(Long customerId,CustomerDTO customerDTO){
        CustomerAttribute checkCustomerAttribute = attributeService.selectOne(new EntityWrapper<CustomerAttribute>().eq("customer_id",customerId));

        if(!CollectionUtils.isEmpty(customerDTO.getAttributes())) {
            CustomerAttribute customerAttribute = new CustomerAttribute();
            try {
                customerAttribute.setCustomerId(customerId).setAttrName(customerDTO.getCustomer().getCustomerType())
                        .setAttrDescription(customerDTO.getCustomer().getCustomerType().getDesc()+"详情")
                        .setAttrValue(objectMapper.writeValueAsString(customerDTO.getAttributes()));
            } catch (JsonProcessingException e) {
                log.error("Json数据格式错误:{}",e.getMessage());
                throw new BizException("Json数据格式错误");
            }
            if(checkCustomerAttribute==null){
                attributeService.insert(customerAttribute);
            }else{
                customerAttribute.setId(checkCustomerAttribute.getId());
                attributeService.updateById(customerAttribute);
            }


        }
    }

    /**
     * 类型转换
     * @param collectionClass
     * @param elementClasses
     * @return
     */
    private  JavaType getCollectionType(Class<?> collectionClass, Class<?>... elementClasses) {
        return objectMapper.getTypeFactory().constructParametricType(collectionClass, elementClasses);
    }

    /**
     * JSON类型转换为list
     * @param customerAttribute
     * @return
     */
    @Override
    public  List<CustomerAttributeDTO> getCustomerAttributeList(CustomerAttribute customerAttribute){
        List<CustomerAttributeDTO> attributeDTOS = null;
        try {
            JavaType javaType = getCollectionType(ArrayList.class, CustomerAttributeDTO.class);
            log.debug("Attributs json:{}",customerAttribute.getAttrValue());
            attributeDTOS = objectMapper.readValue(customerAttribute.getAttrValue(),javaType);
        } catch (IOException e) {
            log.error("Json数据格式错误:{}",e.getMessage());
            throw new BizException("Json数据格式错误");
        }
        return attributeDTOS;
    }

    /**
     * 注册客户
     * @param registerDTO
     */
    @Override
    public void register(RegisterDTO registerDTO){
        log.info(" Register customer info:{}",registerDTO);
        //校验登录帐号是否重复
        if(!this.getLoginIsNull(registerDTO.getLogin())){
            throw new LoginFailException("登录帐号已使用，请重新输入！");
        }
        //校验密码是否一致
        if(!registerDTO.getPassword().equals(registerDTO.getConfirmPassword())){
            throw new LoginFailException("密码输入不一致，请重新输入！");
        }
        //校验手机号是否重复
        if(!this.getPhoneIsNull(registerDTO.getMobileNo())){
            throw new LoginFailException("手机号码已注册，请重新输入！");
        }
        //校验手机验证码是否正确
        VerificationDTO verificationDTO =
                new VerificationDTO().setBizType(BizType.REGISTER)
                        .setPhone(registerDTO.getMobileNo())
                        .setVerificationCode(registerDTO.getVerificationCode());
        if(!msgService.verifyRandomCode(verificationDTO)){
            throw new LoginFailException("验证码不匹配，请重新输入！");
        }

        Customer customer = new Customer();
        //字段验证
        ValidatorUtils.validateEntity(registerDTO);

        //初始化客户信息
        customer.setCustomerType(CustomerTypeEnum.CUSTOMER)
                .setPrimaryPhone(registerDTO.getMobileNo()).setStatus(CustomerStatusEnum.NOT_AUTHENTICATION)
                .setCode(CUSTOMER_CODE_PREFIX+snowFlakeIdGenerator.nextId());
        //保存客户信息
        this.insert(customer);
        //初始化客户登陆信息
        CustomerLogin login = new CustomerLogin()
                .setLogin(registerDTO.getLogin()).setUserName(registerDTO.getLogin())
                .setPassword(DigestUtils.md5Hex(registerDTO.getPassword()))
                .setActive(true).setAdmin(true).setMobileNo(customer.getPrimaryPhone());
        login.setCustomerId(customer.getId());
        loginDao.insert(login);
    }

    /**
     * 校验当前手机号码是否存在
     * @param phone
     * @return
     */
    @Override
    public boolean getPhoneIsNull(String phone){
        log.debug("getPhoneIsNull phone {}",phone);
        List<CustomerLogin> customers = loginDao.queryCustomerLoginByPhone(phone);
        //校验根据当前手机号码是否查询到数据,如果查询到则该手机号不可用，为null则可以使用
        return customers.size()==0;
    }

    /**
     * 校验公司名称是否重复
     * @param name
     * @return
     */
    @Override
    public boolean getNameIsNull(String name){
        log.debug("getNameIsNull name {}",name);
        List<Customer> customers = customerDao.queryCustomerByName(name);
        //校验根据当前公司名称是否查询到数据,如果查询到则该名称不可用，为null则可以使用
        return customers.size()==0;
    }


    /**
    * 校验邮箱是否重复
     * @param email
     * @return
     */
    @Override
    public boolean getEmailIsNull(String email,Long customerId){
        Customer customer = this.selectOne(new EntityWrapper<Customer>().eq("id", customerId));
        if(null == customer ){
            List<Customer> customers = customerDao.queryCustomerByEmail(email);
            return customers.size() == 0;
        }else if(null == customer.getEmail() || customer.getEmail().equals(email)){
            return true;
        }else{
            List<Customer> customers = customerDao.queryCustomerByEmail(email);
            return customers.size() == 0;
        }

    }

    /**
     * 编辑校验公司名称是否重复
     * @param name
     * @param customerId
     * @return
     */
    @Override
    public boolean getNameIsNullByBackstage(String name,Long customerId) {
        Customer customer = this.selectOne(new EntityWrapper<Customer>().eq("id", customerId));
        if(null == customer.getName()){
            return getNameIsNull(name);
        }else if(customer.getName().equals(name)){
            return true;
        }else{
            return getNameIsNull(name);
        }

    }

    /**
     * 完善企业信息
     * @param customerDTO
     */
    @Override
    public void updateCustomer(CustomerDTO customerDTO){
        log.info("Update customer info{}",customerDTO);
        Assert.isNull(customerDTO.getCustomer(),"客户信息不能为空");
        //基本信息
        Customer customer = customerDTO.getCustomer();

        ValidatorUtils.validateEntity(customer);
        //添加创建人、时间、类型
        customer.setUpdateBy(CurrentUserUtils.getLogin().getUserName())
                .setStatus(CustomerStatusEnum.AWAIT).setCustomerType(CustomerTypeEnum.CUSTOMER);
        customer.setId(CurrentUserUtils.getLogin().getCustomerId());
        this.buildCustomer(customer);
        this.updateById(customer);

        //登陆信息
        CustomerLogin login = CurrentUserUtils.getLogin();
        ValidatorUtils.validateEntity(login);
        //向登陆信息中添加logurl
        if(login!=null){
            login.setLogoUrl(customer.getLogoUrl());
            loginDao.updateById(login);
        }

        //详细信息
        this.addCustomerAttributes(customer.getId(),customerDTO);
    }

    /**
     * 保存详细地址信息
     * @param customerId
     * @param address
     */
    private void addDefaultAddress(Long customerId,Address address){
        log.info("Add defaultAddress info{}",address);

        //保存地址信息
        ValidatorUtils.validateEntity(address);
        CustomerAddress checkCustomerAddress = customerAddressService.selectOne(new EntityWrapper<CustomerAddress>().eq("customer_id",customerId));
        if(checkCustomerAddress==null){
            addressDao.insert(address);
            //保存客户地址关系表
            CustomerAddress customerAddress = new CustomerAddress()
                    .setAddressId(address.getId()).setAddressName(address.getAddress())
                    .setAddressType(AddressTypeEnum.SHIPPING).setCustomerId(customerId)
                    .setDefaultAddress(true);

            customerAddressService.insert(customerAddress);
        }else{
            address.setId(checkCustomerAddress.getId());
            addressDao.updateById(address);
        }
    }

    /**
     * 修改个人信息
     * @param customerLogin
     */
    @Override
    public void updateLoginUser(CustomerLogin customerLogin){
        log.info("Update LoginUser info:{}",customerLogin);
        //校验数据
        ValidatorUtils.validateEntity(customerLogin);
        loginDao.updateById(customerLogin);
    }

    /**
     * 获取最新企业
     * @param num
     * @return
     */
    @Override
    public List<Customer> getNewCustomer(Long num){
        return customerDao.getNewCustomer(num);
    }

    /**
     * 条件查询客户信息
     * @param name
     * @param page
     * @return
     */
    @Override
    public Page<Customer> getCustomerByName(String name, Page<Customer> page){
        page.setRecords(customerDao.getCustomerByName(name,page));
        return page;
    }

    /**
     * 后台客户管理 - 查询接口
     * @param param
     * @param page
     * @return
     */
    @Override
    public Page<CustomerDetailDTO> getCustomerList(Map<String, Object> param, Page<CustomerDetailDTO> page){
        page.setRecords(customerDao.getCustomerList(param,page));
        return page;
    }

    /**
     * 修改审批状态
     * @param customerId
     * @param status
     * @param failReasonl
     */
    @Override
    public void updateAuditStatus(Long customerId,CustomerStatusEnum status,String failReasonl){
        CustomerDTO customerDTO = getCustomer(customerId);
        if(null==customerDTO){ throw new BizException("未查询到当前客户信息"); }
        //校验客户信息
        if(CustomerStatusEnum.SUCCESS==status) {
            Assert.isNull(customerDTO.getCustomer().getSignImg(),"电子公章不能为空");
            CustomerDetailDTO customerDetailDTO = new CustomerDetailDTO();
            BeanUtils.copyProperties(customerDTO.getCustomer(),customerDetailDTO);
            if(null != customerDTO.getAttributes() && customerDTO.getAttributes().size()>0){
                this.getCustomerDetailDTO(customerDetailDTO,customerDTO.getAttributes());
            }
            ValidatorUtils.validateEntity(customerDetailDTO);
            customerDao.updateAuditStatus(customerId,CustomerStatusEnum.AWAIT_AUTHENTICATION,failReasonl);
            jzqCustomerService.sendJunZiQian(customerDetailDTO);
        }else{
            customerDao.updateAuditStatus(customerId,status,failReasonl);
        }
    }

    /**
     * 解冻
     * @param customerId
     */
    @Override
    public void updateAudisStatusByThaw(Long customerId){
        CustomerDTO customerDTO = getCustomer(customerId);
        if(null==customerDTO){ throw new BizException("未查询到当前客户信息"); }
        CustomerStatusEnum statusEnum = null;
        if(null != customerDTO.getCustomer().getSignImg() && null == customerDTO.getCustomer().getFailReasonl()){
            statusEnum = CustomerStatusEnum.SUCCESS;
        }else if(null == customerDTO.getCustomer().getEmail()){
            statusEnum = CustomerStatusEnum.NOT_AUTHENTICATION;
        }else if(null != customerDTO.getCustomer().getSignImg() && null != customerDTO.getCustomer().getFailReasonl()){
            statusEnum = CustomerStatusEnum.AWAIT;
        }else{
            statusEnum = CustomerStatusEnum.FAIL;
        }
        customerDao.updateAuditStatus(customerId,statusEnum,customerDTO.getCustomer().getFailReasonl());
    }

    /**
     * 查询银行信息
     * @param customerId
     * @return
     */
    @Override
    public BankAttributeDTO getBank(Long customerId) {
        CustomerAttribute customerAttribute = attributeService.selectOne(new EntityWrapper<CustomerAttribute>().eq("customer_id",customerId));
        List<CustomerAttributeDTO> attributeDTOS = null;
        if(customerAttribute!=null){
            attributeDTOS = this.getCustomerAttributeList(customerAttribute);
        }else{
            throw new BizException("当前用户下没有银行信息");
        }
        return (BankAttributeDTO)attributeDTOS.stream().filter(attributes -> attributes instanceof BankAttributeDTO ).collect(Collectors.toList()).get(0);
    }

    /**
     * 修改当前登录人手机号码
     * @param phone
     * @param verificationCode
     */
    @Override
    public void updatePhoneById(String phone,String verificationCode){
        Assert.isNull(phone,"手机号码不能为空");
        Assert.isNull(verificationCode,"验证码不能为空");

        //校验手机号是否重复
        if(loginDao.queryCustomerLoginByPhone(phone).size()!=0){
            throw new LoginFailException("手机号码已绑定，请重新输入！");
        }
        //校验手机验证码是否正确
        VerificationDTO verificationDTO = new VerificationDTO()
                .setBizType(BizType.BIND)
                .setPhone(phone)
                .setVerificationCode(verificationCode);
        if(!msgService.verifyRandomCode(verificationDTO)){
            throw new LoginFailException("验证码不匹配，请重新输入！");
        }
        //修改客户手机号
        customerDao.updatePhoneById(CurrentUserUtils.getLogin().getCustomerId(),phone);
        //修改登录手机号
        loginDao.updataePhone(CurrentUserUtils.getLogin().getId(),phone);
    }

    /**
     * 根据客户id获取客户详细信息
     * @param customerId
     * @return
     */
    @Override
    public List<CustomerAttributeDTO> getCustomerAttributes(Long customerId){
        CustomerAttribute customerAttribute = attributeService.selectOne(new EntityWrapper<CustomerAttribute>().eq("customer_id",customerId));
        List<CustomerAttributeDTO> attributeDTOS = null;
        if(customerAttribute!=null){
            attributeDTOS = this.getCustomerAttributeList(customerAttribute);
        }else{
            return new ArrayList<CustomerAttributeDTO>();
        }
        return attributeDTOS;
    }

    /**
     * 增加企业浏览量
     * @param customerId
     */
    @Override
    public void addBrowse(@PathVariable Long customerId){
        double score = 0;
        try {
            score = redisTemplate.opsForZSet().score(RedisKeys.getCustomerRedisKey(),customerId);
        }catch (NullPointerException e){
            score = 0;
        }
        redisTemplate.opsForZSet().add(RedisKeys.getCustomerRedisKey(),customerId, score+1);
    }

    /**
     * 获取最热企业
     * @param num
     * @return
     */
    @Override
    public List<CustomerBrowseDTO> getHotCustomer(int num){
        Set<Long> set = redisTemplate.opsForZSet().reverseRange(RedisKeys.getCustomerRedisKey(),0,-1);
        Iterator<Long> customerIds = set.iterator();
        int i = 1;
        if(set.size()<num){
            num = set.size();
        }

        List<CustomerBrowseDTO> list = new ArrayList<CustomerBrowseDTO>();
        while(customerIds.hasNext()) {
            if(i>num){
                break;
            }
            CustomerDTO customerDTO =  this.getCustomer(Long.parseLong(String.valueOf(customerIds.next())));
            int browse = redisTemplate.opsForZSet().score(RedisKeys.getCustomerRedisKey(),customerDTO.getCustomer().getId()).intValue();
            CustomerBrowseDTO customerBrowseVM = new CustomerBrowseDTO(browse,i++,customerDTO.getCustomer());
            list.add(customerBrowseVM);
        }
        return list;
    }

    /**
     * 判断登录帐号是否存在
     * @param login
     * @return
     */
    private boolean getLoginIsNull(String login){
        List<CustomerLogin> ls = loginDao.queryCustomerLoginByLogin(login);
        return ls.size() == 0;
    }

    /**
     * 校验营业执照是否重复
     * @param customerId
     * @param organizationRegNo
     * @return
     */
    @Override
    public boolean getOrganizationRegNoIsNull(Long customerId,String organizationRegNo){
        Customer customer = this.selectOne(new EntityWrapper<Customer>().eq("id", customerId));
        if(null == customer ){
            List<Customer> customers = customerDao.queryCustomerByOrganizationRegNo(organizationRegNo);
            return customers.size() == 0;
        }else if(null == customer.getOrganizationTegNo() || customer.getOrganizationTegNo().equals(organizationRegNo)){
            return true;
        }else{
            List<Customer> customers = customerDao.queryCustomerByOrganizationRegNo(organizationRegNo);
            return customers.size() == 0;
        }
    }

    /**
     * 统计待审客户的客户信息
     * @return
     */
    @Override
    public Integer getCustomerByStatus(){
       return customerDao.getCustomerByStatus(CustomerStatusEnum.AWAIT);
    }

    /**
     * 获取客户详细信息
     * @param customerDetailDTO
     * @return
     */
    @Override
    public List<CustomerAttributeDTO> getAttribute(CustomerDetailDTO customerDetailDTO){
        List<CustomerAttributeDTO> attributeList = new ArrayList<CustomerAttributeDTO>();

        //客户基本信息
        BaseAttributeDTO baseAttributeDTO = new BaseAttributeDTO();
        BeanUtils.copyProperties(customerDetailDTO,baseAttributeDTO);
        baseAttributeDTO.setLegalMobile(customerDetailDTO.getPrimaryPhone());
        baseAttributeDTO.setGroup("CUSTOMER_BASE");
        attributeList.add(baseAttributeDTO);

        //银行账户信息
        BankAttributeDTO bankAttributeDTO = new BankAttributeDTO();
        BeanUtils.copyProperties(customerDetailDTO,bankAttributeDTO);
        bankAttributeDTO.setGroup("CUSTOMER_BANK");
        attributeList.add(bankAttributeDTO);

        //客户工商信息
        BizAttributeDTO bizAttributeDTO = new BizAttributeDTO();
        BeanUtils.copyProperties(customerDetailDTO,bizAttributeDTO);
        bizAttributeDTO.setGroup("CUSTOMER_BUSINESS");
        attributeList.add(bizAttributeDTO);

        return attributeList;
    }

    /**
     * 获取Customer对象
     * @param customerDetailDTO
     * @return
     */
    private Customer getCustomer(CustomerDetailDTO customerDetailDTO){
        Customer customer = new Customer();
        BeanUtils.copyProperties(customerDetailDTO,customer);
        if(null == customer.getOrganizationTegNo()){
            customer.setOrganizationTegNo(customerDetailDTO.getBizCreditCode());
        }
        return customer;
    }

    /**
     * attributeDTOS 转换到CustomerDetailDTO
     * @param customerDetailDTO
     * @param attributeDTOS
     */
    @Override
    public void getCustomerDetailDTO(CustomerDetailDTO customerDetailDTO,List<CustomerAttributeDTO> attributeDTOS) {

        //银行账户信息
        BankAttributeDTO bankAttributeDTO =  (BankAttributeDTO)attributeDTOS.stream().filter(
                attributes ->attributes instanceof BankAttributeDTO
        ).collect(Collectors.toList()).get(0);
        BeanUtils.copyProperties(bankAttributeDTO,customerDetailDTO);

        //客户基本信息
        BaseAttributeDTO baseAttributeDTO =  (BaseAttributeDTO)attributeDTOS.stream().filter(
                attributes ->attributes instanceof BaseAttributeDTO
        ).collect(Collectors.toList()).get(0);
        BeanUtils.copyProperties(baseAttributeDTO,customerDetailDTO);

        //客户工商信息
        BizAttributeDTO bizAttributeDTO =  (BizAttributeDTO)attributeDTOS.stream().filter(
                attributes ->attributes instanceof BizAttributeDTO
        ).collect(Collectors.toList()).get(0);
        BeanUtils.copyProperties(bizAttributeDTO,customerDetailDTO);
    }

    private Customer buildCustomer(Customer customer) {
        if(customer==null) {
            return customer;
        }
        if(customer.getProvince()!=null) {
            customer.setProvinceName(sysAreaService.findById(customer.getProvince()).getName());
        }
        if(customer.getCity()!=null) {
            customer.setCityName(sysAreaService.findById(customer.getCity()).getName());
        }
        if(customer.getArea()!=null) {
            customer.setAreaName(sysAreaService.findById(customer.getArea()).getName());
        }
        return customer;
    }
}