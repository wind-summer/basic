package com.suyun.core.module.bidding.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.exception.BizException;
import com.suyun.common.sms.BizType;
import com.suyun.common.sms.MsgDTO;
import com.suyun.common.sms.MsgService;
import com.suyun.common.sms.SmsProperties;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.bidding.entity.BiddingDeposit;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.suyun.core.module.bidding.dao.BiddingRecordDao;
import com.suyun.core.module.bidding.entity.BiddingRuleProduct;
import com.suyun.core.module.bidding.enums.BiddingRecordStatus;
import com.suyun.core.module.bidding.enums.BiddingStatus;
import com.suyun.core.module.bidding.service.BiddingDepositService;
import com.suyun.core.module.bidding.service.BiddingRecordService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.bidding.service.dto.BiddingRecordDTO;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.module.product.service.ProductService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * <p>
 * 竞价记录表 服务实现类
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@Service
@AllArgsConstructor
@Slf4j
public class BiddingRecordServiceImpl extends ServiceImpl<BiddingRecordDao, BiddingRecord> implements BiddingRecordService {

    private final BiddingDepositService biddingDepositService;

    private final ProductService productService;

    private final AccountApplyService accountApplyService;

    private final AccountService accountService;

    private final MsgService msgService;

    private final SmsProperties smsProperties;

    private final CustomerService customerService;

    /**
     * 根据竞价产品ID分页查询竞价记录
     * @param biddingProductId
     * @param page
     * @return
     */
    @Override
    public Page<BiddingRecord> queryBiddingRecordByProductId(Long biddingProductId, Page<BiddingRecord> page) {
        return this.selectPage(page,new EntityWrapper<BiddingRecord>().eq("bidding_product_id",biddingProductId).orderBy("id",false));
        //return page.setRecords(this.selectList(new EntityWrapper<BiddingRecord>().eq("bidding_product_id",biddingProductId)));
    }

    /**
     * 根据客户ID和竞价产品ID修改数据
     * @param customerId
     * @param biddingProductId
     * @return
     */
    @Override
    public void updateBiddingRecordStatus(Long customerId,Long biddingProductId) {
        baseMapper.updateBiddingRecordStatus(customerId, biddingProductId);
    }

    /**
     * 根据id取消竞价记录
     * @param id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelBiddingRecord(Long id) {
        BiddingRecord biddingRecord = this.selectById(id);
        if (biddingRecord == null) {
            throw new BizException("没有该条记录");
        }
        //验证竞价产品状态
        BiddingRuleProduct biddingRuleProduct = new BiddingRuleProduct();
        biddingRuleProduct.setId(biddingRecord.getBiddingProductId());
        biddingRuleProduct = biddingRuleProduct.selectById();
        if( biddingRuleProduct!= null && !biddingRuleProduct.getBiddingStatus().equals(BiddingStatus.FINISHED)){
            throw new BizException("竞价结束后才能进行取消操作");
        }
        //竞价失败
        BiddingRecordStatus biddingStatus= biddingRecord.getBiddingStatus();
        if(!biddingStatus.equals(BiddingRecordStatus.STATISTICS)){
            throw new BizException("统计中的记录才可以取消竞价");
        }
        biddingRecord.setBiddingStatus(BiddingRecordStatus.FAIL);

        Long customerId = biddingRecord.getCustomerId();
        Long biddingProductId = biddingRecord.getBiddingProductId();

        List<BiddingDeposit> depositList = biddingDepositService.selectList(new EntityWrapper<BiddingDeposit>()
                .eq("customer_id", customerId)
                .eq("bidding_product_id",biddingProductId));
        BigDecimal allDeposit = depositList.stream().map(BiddingDeposit::getDeposit).reduce(BigDecimal.ZERO, BigDecimal::add);
        depositList.forEach(deposit -> {
            deposit.setRefunded(true);
        });

        //修改竞价记录状态竞价失败
        biddingRecord.updateById();
        //更新相对应得保证为已退款
        biddingDepositService.updateAllColumnBatchById(depositList);

        //解冻账户 customerId，allDeposit
        //获取可用余额
        Account account = accountService.findAccountByCustomerId(customerId);
        BigDecimal freezeAmount = account.getFreezeAmount();
        if(freezeAmount.compareTo(allDeposit) == -1){
            throw new BizException("冻结金额不足，解冻失败");
        }
        //调用账户接口，解冻保证金
        accountApplyService.unFreezeByCustomerId(customerId, allDeposit, 4);
        //##发送短信提示 竞价失败
        //手机号
        String customerPhone = customerService.selectById(customerId).getPrimaryPhone();
        Set<String> phoneSet = new HashSet<String>();
        phoneSet.add(customerPhone);
        //商品名称
        Map<String,String> paramMap = new HashMap<String,String>();
        paramMap.put("name",biddingRuleProduct.getProductName());
        MsgDTO msgDTO = new MsgDTO();
        msgDTO.setTemplateCode(smsProperties.getBidFailTemplateCode())
                .setBizType(BizType.OTHER)
                .setPhones(phoneSet)
                .setParams(paramMap);
        msgService.sendSms(msgDTO);

    }

    /**
     *  根据订单编号进行
     * @param orderCode
     */
    @Override
    public void returnBiddingRecord(String orderCode) {
        BiddingRecord biddingRecord = this.selectOne(new EntityWrapper<BiddingRecord>().eq("order_code",orderCode));
        Long customerId = biddingRecord.getCustomerId();
        Long biddingProductId = biddingRecord.getBiddingProductId();

        List<BiddingDeposit> depositList = biddingDepositService.selectList(new EntityWrapper<BiddingDeposit>()
                .eq("customer_id", customerId)
                .eq("bidding_product_id",biddingProductId));
        BigDecimal allDeposit = depositList.stream().map(BiddingDeposit::getDeposit).reduce(BigDecimal.ZERO, BigDecimal::add);
        depositList.forEach(deposit -> {
            deposit.setRefunded(true);
        });
        //已付款视为已成交 并更新
        biddingRecord.setDealQuantity(biddingRecord.getBiddingQuantity()).updateById();
        //更新相对应得保证金为已退款
        biddingDepositService.updateAllColumnBatchById(depositList);

        //解冻账户 customerId，allDeposit
        //获取可用余额
        Account account = accountService.findAccountByCustomerId(customerId);
        BigDecimal freezeAmount = account.getFreezeAmount();
        if(freezeAmount.compareTo(allDeposit) == -1){
            throw new BizException("冻结金额不足，解冻失败");
        }
        //调用账户接口，解冻保证金
        accountApplyService.unFreezeByCustomerId(customerId, allDeposit, 4);
    }

    /**
     *
     * @param param  条件
     * @param page   页面条件
     * @return
     */
    @Override
    public Page<BiddingRecordDTO> queryMyBiddingRecord(Map<String, Object> param, Page<BiddingRecordDTO> page) {
        Long customerId = CurrentUserUtils.getLogin().getCustomerId();
        param.put("customerId", customerId);
        List<BiddingRecordDTO> biddingRecordDTOS =  baseMapper.selectMyBiddingRecordList(param, page);
        return page.setRecords(biddingRecordDTOS);
    }

    /**
     * 根据id获取我的竞价记录详情
     * @param id
     * @return
     */
    @Override
    public BiddingRecord getMyBiddingRecord(Long id) {
        //当前要查询的竞价记录
        BiddingRecord biddingRecord = this.selectById(id);
        if(biddingRecord == null) {
            throw new BizException("没有该条竞价记录");
        }
        Long customerId = biddingRecord.getCustomerId();
        //验证当前登录用户和要查询的竞价记录是否一致
        Long currentCustomerId = CurrentUserUtils.getLogin().getCustomerId();
        //验证当前登录用户和要查询的竞价记录是否一致
        if(!currentCustomerId.equals(customerId)){
            throw new BizException("当前查询的记录不属于当前用户");
        }
        //获取相关的竞价产品
        BiddingRuleProduct biddingRuleProduct = new BiddingRuleProduct();
        biddingRuleProduct.setId(biddingRecord.getBiddingProductId());
        biddingRuleProduct = biddingRuleProduct.selectById();
        //获取相关的sku产品
        Sku sku = productService.getSku(biddingRuleProduct.getSkuId());
        Long biddingProductId = biddingRuleProduct.getId();
        //获取当前数据相关的保证金
        List<BiddingDeposit> biddingDeposits = biddingDepositService.selectList(new EntityWrapper<BiddingDeposit>().
                eq("customer_id",customerId).eq("bidding_product_id",biddingProductId));
        BigDecimal allDeposit = biddingDeposits.stream().map(BiddingDeposit::getDeposit).reduce(BigDecimal.ZERO, BigDecimal::add);
        //设置sku数据和总押金
        return biddingRecord.setSku(sku).setEarnestMoney(allDeposit);
    }

    /**
     * 根据ID成交此次竞价
     * @param id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void dealBiddingRecord(Long id) {
        BiddingRecord biddingRecord = this.selectById(id);
        if (biddingRecord == null) {
            throw new BizException("没有该条记录");
        }
        //验证竞价产品状态
        BiddingRuleProduct biddingRuleProduct = new BiddingRuleProduct();
        biddingRuleProduct.setId(biddingRecord.getBiddingProductId());
        biddingRuleProduct = biddingRuleProduct.selectById();
        if( biddingRuleProduct!= null && !biddingRuleProduct.getBiddingStatus().equals(BiddingStatus.FINISHED)){
            throw new BizException("竞价结束后才能进行成交");
        }
        if(!biddingRecord.getBiddingStatus().equals(BiddingRecordStatus.STATISTICS)) {
            throw new BizException("状态为统计中才可以成交");
        }
        this.selectById(id).setBiddingStatus(BiddingRecordStatus.SUCCESS).updateById();
        //##发送短信提示 竞价成功
        //手机号
        String customerPhone = customerService.selectById(biddingRecord.getCustomerId()).getPrimaryPhone();
        Set<String> phoneSet = new HashSet<String>();
        phoneSet.add(customerPhone);
        //商品名称
        Map<String,String> paramMap = new HashMap<String,String>();
        paramMap.put("name",biddingRuleProduct.getProductName());
        MsgDTO msgDTO = new MsgDTO();
        msgDTO.setTemplateCode(smsProperties.getBidSuccessTemplateCode())
                .setBizType(BizType.OTHER)
                .setPhones(phoneSet)
                .setParams(paramMap);
        msgService.sendSms(msgDTO);
    }

    /**
     * 统计等待处理的竞价记录
     * @return
     */
    @Override
    public Integer countAwaitBiddingRecord() {
        return baseMapper.selectCountAwaitBiddingRecord();
    }

    /**
     * 是否退押金
     * @param orderCode
     */
    @Override
    public void breakPromiseBidding(String orderCode) {
        //扣除押金###################################
        //获取当前竞价记录
        /*BiddingRecord biddingRecord = this.selectOne(new EntityWrapper<BiddingRecord>().eq("order_code", orderCode));
        if(biddingRecord != null && biddingRecord.getBiddingStatus().equals(BiddingRecordStatus.ORDERED)){
            //调用账户接口，解冻保证金
            List<BiddingDeposit> deposits = biddingDepositService.selectList(
                    new EntityWrapper<BiddingDeposit>()
                            .eq("customer_id",biddingRecord.getCustomerId())
                            .eq("bidding_product_id",biddingRecord.getBiddingProductId()));
            BigDecimal allDeposit = new BigDecimal(0);
            for(BiddingDeposit deposit : deposits) {
                allDeposit = allDeposit.add(deposit.getDeposit());
                deposit.setRefunded(true);
            }
            //修改定金状态为已解冻
            biddingDepositService.updateAllColumnBatchById(deposits);
            //解冻相应的金额
            accountApplyService.unFreezeByCustomerId(biddingRecord.getCustomerId(), allDeposit, 4);
        }*/
    }
}
