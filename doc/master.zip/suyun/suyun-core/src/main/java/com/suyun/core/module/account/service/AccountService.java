package com.suyun.core.module.account.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.service.dto.AccountDetailDTO;
import com.suyun.core.module.account.service.dto.WithDrawDTO;

import java.util.Map;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
public interface AccountService extends IService<Account> {

    /**
     * 创建账户 前端
     *
     * @param account
     * @return
     */
    boolean createAccount(Account account);


    /**
     * 用客户ID查询账户 前端
     *
     * @param customId
     * @return
     */
    Account findAccountByCustomerId(Long customId);



    /**
     * 账户提现前查看信息
     *
     * @return
     */
    WithDrawDTO findWithDraw();

    /**
     * 账户条件分页条件查询 后台
     *
     * @param map
     * @param page
     * @return
     */
    Page<Account> findpage(Map<String, Object> map, Page<Account> page);

    /**
     * 用账户ID查询账户详细信息  后台
     *
     * @param accountId
     * @return
     */
    AccountDetailDTO findAccount(Long accountId);

    /**
     * 用客户ID查询账户
     *
     * @return
     */
    AccountDetailDTO findBalanceByCustomerId();

    /**
     * 创建账户
     *
     * @param customerId
     * @return
     */
    void createAccount(Long customerId);

}
