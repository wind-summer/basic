package com.suyun.core.module.order.service;

import com.suyun.core.module.order.entity.OrderPush;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
public interface OrderPushService extends IService<OrderPush> {

    /**
     * 订单推送给浪潮erp
     * @param orderId
     */
    void pushOrderByOrderId(Long orderId);

    /**
     * 根据id查询订单的最新推送信息
     * 用于推送失败再次推送时校验
     * @author wanggf
     * @param orderId
     * @return
     */
    OrderPush findNewOrderPushById(Long orderId);
}
