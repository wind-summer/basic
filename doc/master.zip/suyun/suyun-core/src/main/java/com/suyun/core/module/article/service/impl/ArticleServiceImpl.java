package com.suyun.core.module.article.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.suyun.common.exception.BizException;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.module.article.dao.ArticleDao;
import com.suyun.core.module.article.entity.Article;
import com.suyun.core.module.article.entity.ArticleContent;
import com.suyun.core.module.article.service.ArticleContentService;
import com.suyun.core.module.article.service.ArticleService;
import com.suyun.core.utils.ShiroUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Optional;


/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
@Service
@AllArgsConstructor
@Slf4j
public class ArticleServiceImpl extends ServiceImpl<ArticleDao, Article> implements ArticleService {
    private final ArticleDao articleDao;
    private final ArticleContentService articleContentService;

    /**
     * 添加文章
     *
     * @param article
     */
    @Override
    public void addArticle(Article article) {
        ValidatorUtils.validateEntity(article);
        if(StringUtils.isEmpty(article.getCreateBy())){
            article.setCreateBy(ShiroUtils.getUserEntity().getUsername());
        }
        //上线设置
        if( article.getStatus() == 1){
            article.setShow(1);
        }
        article.setDelete(false);
        try {
            if (!this.insert(article)) {
                throw new BizException("文章添加失败");
            }
            //删除其他置顶
            if(article.getTop()){
                Optional.ofNullable(this.selectOne(new EntityWrapper<Article>().eq("channel_code",article.getChannelCode()))).map(ar->ar.setTop(false).updateById());
            }

            ArticleContent articleContent = article.getArticleContent();
            articleContent.setArticleId(article.getId()).setContent(article.getArticleContent().getContent());
            articleContent.insert();
        } catch (Exception e){
            log.info("addArticle error:{}",e.getMessage());
        }
    }


    /**
     * 编辑文章
     *
     * @param article
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void editArticle(Article article) {
        try {
            ValidatorUtils.validateEntity(article);
            article.setDelete(false).updateAllColumnById();
            ArticleContent articleContent = article.getArticleContent();
            if(article.getArticleContent().getId() == null){
                //删除之前的文章内容
                articleContentService.delete(new EntityWrapper<ArticleContent>().eq("article_id",article.getId()));
                articleContent.setContent(article.getArticleContent().getContent()).setArticleId(article.getId()).insert();
            }else{
                articleContent.updateAllColumnById();
            }
        }catch (Exception e){
            log.info("editArticle error:{}",e.getMessage());
        }
    }

    /**
     * 文章详情查询
     *
     * @param articleId
     * @return
     */
    @Override
    public Article findArticleByid(Long articleId) {
        Article article = this.selectOne(new EntityWrapper<Article>().eq("id",articleId).eq("is_delete",0));
        Optional.ofNullable(article)
                .map(a->
                    a.setArticleContent(articleContentService.selectOne(new EntityWrapper<ArticleContent>().eq("article_id", articleId))))
                .orElseThrow(()-> new BizException("文章"+ articleId +"不存在"));
        return article;
    }

    /**
     * 分页查询
     * @param param
     * @param page
     * @return
     */
    @Override
    public Page<Article> queryArticle(Map<String, Object> param, Page<Article> page) {

        List<Article> articles =  articleDao.selectArticleList(param,page);

        articles.forEach(article->{
            ArticleContent articleContent = articleContentService.selectOne(new EntityWrapper<ArticleContent>().eq("article_id",article.getId()));
            article.setArticleContent(articleContent);
        });
        page.setRecords(articles);
        return page;
    }

    /**
     * 删除文章
     * @param articleId
     */
    @Override
    public void deleteById(Long articleId) {
        if( articleId == null){
            throw new BizException("参数不能问为空");
        }
        Article article = this.selectById(articleId);
        if(article == null || article.getDelete() == true ) {
            throw new BizException("文章不存在或者已经删除");
        }
        article.setDelete(true);
        article.updateById();
    }

    /**
     * 下线
     * @param articleId
     */
    @Override
    public void downLineById(Long articleId) {
        Article article = this.selectById(articleId);
        if(article == null){
            throw new BizException("文章不存在");
        }
        if(article.getShow() == 0 || article.getStatus() == 0){
            throw new BizException("文章已经下线或者还是草稿");
        }
        article.setShow(0);
        article.updateById();
    }

    /**
     * 上线
     * @param articleId
     */
    @Override
    public void upLineById(Long articleId) {
        Article article = this.selectById(articleId);
        if(article == null){
            throw new BizException("文章不存在");
        }
        if(article.getShow() == 1 || article.getStatus() == 0){
            throw new BizException("文章已经上线 或者 还是草稿");
        }
        article.setShow(1);
        article.updateById();
    }
}
