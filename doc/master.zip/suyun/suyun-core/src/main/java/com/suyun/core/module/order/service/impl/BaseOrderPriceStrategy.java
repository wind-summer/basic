package com.suyun.core.module.order.service.impl;

import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.service.OrderPriceStrategyTemplate;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * @author caosg
 * @version V1.0
 * @Description: 基本价格计算,优先开始
 * @date 2017/12/7 下午3:51
 */
@Component
@org.springframework.core.annotation.Order(Ordered.HIGHEST_PRECEDENCE)
public class BaseOrderPriceStrategy extends OrderPriceStrategyTemplate{

    @Override
    protected boolean isSupport(Order order) {
        return true;
    }

    @Override
    protected void calculate(Order order) {
        BigDecimal subTotal = order.getItems().stream()
                .map(orderItem -> orderItem.getSubTotal())
                .reduce(new BigDecimal(0),(a,b)-> a.add(b).setScale(2) );
        order.setSubTotal(subTotal);
        order.setTotal(order.getSubTotal().add(
                order.getTotalShipping()==null?new BigDecimal(0):order.getTotalShipping()));
    }
}
