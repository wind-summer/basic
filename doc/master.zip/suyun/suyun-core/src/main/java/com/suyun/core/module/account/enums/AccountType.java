package com.suyun.core.module.account.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 账户类型
 *
 * @author zhangjq
 * @Date 2017-12-29
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum AccountType implements IEnum {

    //表示现金账户
    CASH_ACCOUNT(0, "现金账户"),
    //表示优惠券账户
    COUPON_ACCOUNT(1, "优惠券账户");

    private Integer value;
    private String desc;

    AccountType(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return this.desc;
    }


    @Override
    public String toString() {
        return "ApplyStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
