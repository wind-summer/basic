package com.suyun.core.module.order.service.dto;

import com.suyun.core.module.order.enums.OrderStatus;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Map;

/**
 * @author caosg
 * @Description: 客户订单统计汇总
 * @date 2018/1/5 上午10:30
 */
@Data
@Accessors(chain = true)
public class CustomerOrderDashboardDTO {
    private String group;
    private Integer   orderCount;
    private BigDecimal orderSum;
    private Map<OrderStatus,Long> statusCount;
}
