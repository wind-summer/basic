package com.suyun.core.module.account.service.dto;

import com.suyun.core.sys.service.dto.PlatformBankDTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * @author zhangjq
 * @Description:
 * @date 2017年12月29日 18：:2
 */
@Data
@Accessors(chain = true)
public class RechargeDTO {
    /**
     * 账户id
     */
    private Long id;

    /**
     * 账户总额
     */
    private BigDecimal amount;

    /**
     * 客户手机号
     */
    private String phone;

    /**
     * 付款识别码
     */
    private String paymentCode;

    /**
     * 可用余额
     */
    private BigDecimal avaliableAmount;


    /**
     * 平台银行账户信息
     */
    private PlatformBankDTO platformBank;

    /**
     * 账户充值最大金额
     */
    private  BigDecimal maxAmount;

}
