package com.suyun.core.module.customer.service;

import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.customer.entity.LoginToken;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface LoginTokenService extends IService<LoginToken> {

    /**
     * 生成token
     * @param loginId  用户登陆ID
     * @return        返回token信息
     */
    String createToken(long loginId);

    /**
     * 根据token查询用户登陆token信息
     * @param token
     * @return
     */
    LoginToken queryByToken(String token);

    /**
     * token立刻失效
     * @param loginId
     */
    void expireToken(long loginId);

}
