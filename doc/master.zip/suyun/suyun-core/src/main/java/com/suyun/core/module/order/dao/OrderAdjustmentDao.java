package com.suyun.core.module.order.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.order.entity.OrderAdjustment;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
public interface OrderAdjustmentDao extends BaseMapper<OrderAdjustment> {

}
