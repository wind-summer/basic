package com.suyun.core.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: 业务系统配置
 * @date 2017/12/1 上午11:33
 */
@Getter
@Configuration
@ConfigurationProperties(prefix = "application")
public class ApplicationProperties {

    private final Async async = new Async();

    private final CorsConfiguration cors = new CorsConfiguration();

    private final Security security = new Security();

    private final Account account = new Account();

    private final KeyWord keyWord = new KeyWord();

    private final Bidding bidding = new Bidding();

    public static class Security {
        /**
         * token失效秒数
         */
        private Long tokenExpire;
        /**
         * 客户默认初始化密码
         */
        private String defaultPassword;
        /**
         * 角色id
         */
        private Long roleId;

        /**
         * 营销中心部门id
         */
        private Long deptId;

        private List<Long> adminIds;

        /**
         * 密码错误次数
         */
        private int errorNum;

        public Long getTokenExpire() {
            return tokenExpire;
        }

        public void setTokenExpire(Long tokenExpire) {
            this.tokenExpire = tokenExpire;
        }

        public String getDefaultPassword() {
            return defaultPassword;
        }

        public void setDefaultPassword(String defaultPassword) {
            this.defaultPassword = defaultPassword;
        }

        public Long getRoleId() {
            return roleId;
        }

        public void setRoleId(Long roleId) {
            this.roleId = roleId;
        }

        public Long getDeptId() {
            return deptId;
        }

        public void setDeptId(Long deptId) {
            this.deptId = deptId;
        }

        public List<Long> getAdminIds() {
            return adminIds;
        }

        public void setAdminIds(List<Long> adminIds) {
            this.adminIds = adminIds;
        }

        public int getErrorNum() {
            return errorNum;
        }

        public void setErrorNum(int errorNum) {
            this.errorNum = errorNum;
        }
    }


    public static class Async {

        private int corePoolSize = 5;

        private int maxPoolSize = 50;

        private int queueCapacity = 10000;

        private String threadNamePrifix = "";

        public int getCorePoolSize() {
            return corePoolSize;
        }

        public void setCorePoolSize(int corePoolSize) {
            this.corePoolSize = corePoolSize;
        }

        public int getMaxPoolSize() {
            return maxPoolSize;
        }

        public void setMaxPoolSize(int maxPoolSize) {
            this.maxPoolSize = maxPoolSize;
        }

        public int getQueueCapacity() {
            return queueCapacity;
        }

        public void setQueueCapacity(int queueCapacity) {
            this.queueCapacity = queueCapacity;
        }

        public String getThreadNamePrifix() {
            return threadNamePrifix;
        }

        public void setThreadNamePrifix(String threadNamePrifix) {
            this.threadNamePrifix = threadNamePrifix;
        }
    }

    public static class Account {
        private Long withdrawWaitTime;

        private Integer invalidTime;

        public BigDecimal maxAmount;

        public Integer getInvalidTime() {
            return invalidTime;
        }

        public void setInvalidTime(Integer invalidTime) {
            this.invalidTime = invalidTime;
        }

        public BigDecimal getMaxAmount() {
            return maxAmount;
        }

        public void setMaxAmount(BigDecimal maxAmount) {
            this.maxAmount = maxAmount;
        }

        public Long getWithdrawWaitTime() {
            return withdrawWaitTime;
        }

        public void setWithdrawWaitTime(Long withdrawWaitTime) {
            this.withdrawWaitTime = withdrawWaitTime;
        }


    }

    public static class KeyWord {
        private int size;

        public void setSize(int size) {
            this.size = size;
        }

        public int getSize() {
            return size;
        }
    }

    public static class Bidding {
        private BigDecimal maxDeposit;

        private Integer breakPromiseTime;

        public BigDecimal getMaxDeposit() {
            return maxDeposit;
        }

        public void setMaxDeposit(BigDecimal maxDeposit) {
            this.maxDeposit = maxDeposit;
        }

        public Integer getBreakPromiseTime() {
            return breakPromiseTime;
        }

        public void setBreakPromiseTime(Integer breakPromiseTime) {
            this.breakPromiseTime = breakPromiseTime;
        }
    }
}
