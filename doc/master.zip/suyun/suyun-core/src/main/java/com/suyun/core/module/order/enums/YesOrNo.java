package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;

/**
 * @author caosg
 * @description 是否
 */
public enum YesOrNo implements IEnum{

    NO("0","否"),
    YES("1","是");

    private String value;
    private String desc;

    YesOrNo(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
