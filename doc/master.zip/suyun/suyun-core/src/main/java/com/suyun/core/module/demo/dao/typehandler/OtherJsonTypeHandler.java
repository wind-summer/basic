package com.suyun.core.module.demo.dao.typehandler;

import com.suyun.core.config.mybatis.typehandler.JsonTypeHandler;
import com.suyun.core.module.demo.service.dto.OtherDTO;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/11/30 上午9:53
 */
@MappedTypes(value = OtherDTO.class)
public class OtherJsonTypeHandler extends JsonTypeHandler<OtherDTO> {
    public OtherJsonTypeHandler(Class<OtherDTO> clazz) {
        super(clazz);
    }
}
