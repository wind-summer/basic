package com.suyun.core.module.demo.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.annotations.Version;
import com.baomidou.mybatisplus.enums.IdType;
import com.suyun.core.module.demo.service.dto.AddressDTO;
import com.suyun.core.module.demo.service.dto.OtherDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 示例Demo
 * </p>
 *
 * @author caosg
 * @since 2017-11-23
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName(value = "sy_demo",resultMap = "BaseResultMap")
public class Demo extends Model<Demo> {

    private static final long serialVersionUID = 1L;

	@TableId(value="id", type= IdType.AUTO)
	private Integer id;
    @NotNull
    @Size(min=2,max=10)
	private String name;
    /**
     * 乐观锁示例
     */
    @Version
	private Integer version;
	@TableField("is_success")
	private Boolean success;
	@TableField("create_time")
	private Date createTime;

	private AddressDTO address;

	private OtherDTO other;


	@Override
	protected Serializable pkVal() {
		return this.id;
	}

}
