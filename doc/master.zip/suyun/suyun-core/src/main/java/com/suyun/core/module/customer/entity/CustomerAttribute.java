package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.module.customer.enums.CustomerTypeEnum;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_customer_attribute")
public class CustomerAttribute extends BaseEntity<CustomerAttribute> {

    private static final long serialVersionUID = 1L;

	@TableField("attr_name")
	private CustomerTypeEnum attrName;
	@TableField("attr_value")
	private String attrValue;
	@TableField("attr_description")
	private String attrDescription;
	@TableField("customer_id")
	private Long customerId;


}
