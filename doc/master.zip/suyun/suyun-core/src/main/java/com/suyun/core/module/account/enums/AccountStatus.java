package com.suyun.core.module.account.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 账户状态
 *
 * @author zhangjq
 * @Date 2017-12-29
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum AccountStatus implements IEnum {

    //表示账户已激活可用
    ACTIVATE_STATUS(0, "已激活"),
    //表示账户已经冻结
    FREEZE_STATUS(1, "冻结"),
    //表示账户已经作废
    CANCELLATION_STATUS(2, "作废");

    private Integer value;
    private String desc;

    AccountStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return this.desc;
    }


    @Override
    public String toString() {
        return "ApplyStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
