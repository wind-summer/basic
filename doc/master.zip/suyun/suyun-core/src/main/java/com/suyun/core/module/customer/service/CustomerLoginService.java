package com.suyun.core.module.customer.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.common.sms.VerificationDTO;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.service.dto.CustomerDTO;

/**
 * <p>
 * 客户登陆信息 服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerLoginService extends IService<CustomerLogin> {

    /**
     * 登陆
     * @param login
     * @param password
     * @return 详细信息
     */
    CustomerDTO login(String login,String password);

    /**
     * 手机验证码登录
     * @param verificationDTO
     * @return
     */
    CustomerDTO phoneLogin(VerificationDTO verificationDTO);

    /**
     * 找回密码
     * @param login
     * @param phone
     * @param paw
     */
    void backPassword(String login,String phone,String paw);

    /**
     * 校验手机号码与帐号是否匹配
     * @param login
     * @param phone
     * @return
     */
    boolean checkPhone(String login,String phone);

    /**
     * 修改密码
     * @param id
     * @param paw
     * @return
     */
    void updatePassword(Long id,String paw);

    /**
     * 根据登陆账号查询登陆信息
     * @param login
     * @return 登陆信息
     */
    CustomerLogin queryByLogin(String login);

    /**
     * 获取当前客户下所有员工信息
     * @return
     */
    Page<CustomerLogin> getUserAll( CustomerLogin customerLogin,Page<CustomerLogin> page);

    /**
     * 添加客户员工信息
     * @param customerLogin
     */
    void addCustomerUser(CustomerLogin customerLogin);

    /**
     * 修改客户员工信息
     * @param customerLogin
     */
    void updateCustomerUser(CustomerLogin customerLogin);

    /**
     * 删除客户员工
     * @param id
     */
    void deleteCustomerUser(Long id);

    /**
     * 校验当前手机号码是否存在
     * @param phone
     * @return
     */
    boolean getPhoneIsNull(String phone);

    /**
     * 校验当前帐号是否可以使用
     * @param login
     * @return
     */
    boolean getLoginIsNull(String login);

    /**
     * 校验员工姓名是否重复
     * @param userName
     * @return
     */
    boolean getUserNameIsNull(String userName);

}
