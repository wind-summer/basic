package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.customer.dao.CustomerAttributeDao;
import com.suyun.core.module.customer.entity.CustomerAttribute;
import com.suyun.core.module.customer.service.CustomerAttributeService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
public class CustomerAttributeServiceImpl extends ServiceImpl<CustomerAttributeDao, CustomerAttribute> implements CustomerAttributeService {

}
