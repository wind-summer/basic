package com.suyun.core.module.order.service;

import com.suyun.common.sms.BizType;
import com.suyun.common.sms.MsgDTO;
import com.suyun.common.sms.MsgService;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.sys.service.SysDictionaryService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单短息通知
 * @date 2018/1/24 上午9:40
 */
@Component
@AllArgsConstructor
@Slf4j
public class OrderSms {

    private final MsgService msgService;

    private final SysDictionaryService dictionaryService;

    /**
     * 发送短信通知
     * @param order 订单
     * @param smsTemplateCode 短信模板代码
     */
    public void sendSms(Order order,String smsTemplateCode){
        StringBuffer smsParams = new StringBuffer(" ");
        order.getItems().forEach(orderItem -> smsParams.append(orderItem.getName()).append(" ")
                .append(dictionaryService.getNameByCode("KUBE",orderItem.getSku().getWarehouseCode())).append(" ")
                .append(orderItem.getQuantity()).append(dictionaryService.getNameByCode("UNIT",orderItem.getSku().getUnitCode())));
        MsgDTO msgDTO = new MsgDTO();
        msgDTO.setTemplateCode(smsTemplateCode).setBizType(BizType.OTHER).addParam("name",smsParams.toString());
        Set<String> phones = new HashSet<>();
        phones.add(order.getCustomer().getPrimaryPhone());
        msgDTO.setPhones(phones);
        log.info("***** Send Order Sms :{} ***********",msgDTO);
        msgService.sendSms(msgDTO);
    }
}
