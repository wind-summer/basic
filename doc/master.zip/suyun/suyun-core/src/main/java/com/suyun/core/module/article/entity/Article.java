package com.suyun.core.module.article.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_article")
public class Article extends BaseEntity<Article> {

    private static final long serialVersionUID = 1L;

    @NotBlank(message = "文章标题不能问为空")
	private String title;
    /**
     * 栏目频道
     */
    @NotBlank(message = "栏目频道不能为空")
	@TableField("channel_code")
	private String channelCode;
	/**
	 * 是否置顶 1：是 0：否
	 */
	@TableField("is_top")
	private Boolean top;

	/**
	 * 是否热点 1：是 0：否
	 */
	@TableField("is_hot")
	private Boolean hot;
	/**
     * 封面图URL
     */
	@NotBlank(message = "封面图地址不能为空")
	@TableField("cover_image")
	private String coverImage;
	/**
	 * 是否推荐 1：是  0：否
	 */
	@TableField("is_recommend")
	private Boolean recommend;

	/**
     * 内容摘要
     */
    @NotBlank(message = "内容摘要不能问为空")
	private String description;

	/**
	 * 创建时间
	 */
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;

	/**
	 * 创建者
	 */
	@TableField("create_by")
	private String createBy;
    /**
     * 状态  0：草稿  1：发布
     */
	private Integer status;

	/**
	 *文章内容
	 */
	@TableField(exist = false)
	private ArticleContent articleContent;

	/**
	 * 是否删除  1为删除 0为不删除
	 */
	@JsonIgnore
	@TableField("is_delete")
	private Boolean delete;

	/**
	 * 上下架  1为上架 0为下架
	 */
	private Integer show;



}
