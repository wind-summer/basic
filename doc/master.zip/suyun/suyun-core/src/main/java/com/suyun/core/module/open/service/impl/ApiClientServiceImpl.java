package com.suyun.core.module.open.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.suyun.core.module.open.entity.ApiClient;
import com.suyun.core.module.open.dao.ApiClientDao;
import com.suyun.core.module.open.service.ApiClientService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
@Service
@Slf4j
public class ApiClientServiceImpl extends ServiceImpl<ApiClientDao, ApiClient> implements ApiClientService {

    @Override
    @Cacheable(value="api-clients", key="#clientId")
    public ApiClient getClientByClientId(String clientId) {
        log.info("**** get a api client by clientId:{} from db *****",clientId);
        return this.selectOne(new EntityWrapper<ApiClient>().eq("client_id",clientId));
    }

    @Override
    @CacheEvict(value = "api-clients",allEntries = true)
    public void clearCache(){
       log.info("**** clear api-clients cache ******");
    }
}
