package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.suyun.core.module.customer.enums.CustomerAttributeEnum;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.LuhnCheck;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @author caosg
 * @Description: 银行账户信息
 * @date 2017/12/1 下午3:37
 */
@Data
@Accessors(chain = true)
@JsonTypeName(value = "CUSTOMER_BANK")
public class BankAttributeDTO extends CustomerAttributeDTO{
    public BankAttributeDTO() {
        super(CustomerAttributeEnum.BANK.getValue());
    }

    /**
     * 银行账户类型
     */
    private String accountType;
    /**
     * 开户名
     */
    @NotBlank(message = "开户名不能为空")
    private String accountName;
    /**
     * 开户行
     */
    @NotBlank(message = "开户行不能为空")
    private String bank;
    /**
     * 银行账号
     */
    @NotBlank(message = "银行账号不能为空")
    @LuhnCheck(message="银行卡格式不正确")
    private String accountNo;
}
