package com.suyun.core.module.account.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.account.enums.TransType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @author zhangjq
 * @Description:
 * @date 2018年1月1日 22：:22
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransDTO {
    /**
     * 客户id
     */
    @NotBlank(message = "客户id不能为空")
    private String customerId;

    /**
     * 单据类型
     */
    private TransType transType;

    /**
     * 单据编码
     */
    private String transCode;

    /**
     * 开始时间
     */
    private String startTime;

    /**
     * 结束时间
     */
    private String endTime;


}
