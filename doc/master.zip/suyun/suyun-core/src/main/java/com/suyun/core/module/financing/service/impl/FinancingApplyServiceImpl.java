package com.suyun.core.module.financing.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.common.exception.BizException;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.module.financing.dao.FinancingApplyDao;
import com.suyun.core.module.financing.entity.FinancingApply;
import com.suyun.core.module.financing.entity.FinancingContactLog;
import com.suyun.core.module.financing.service.FinancingApplyService;
import com.suyun.core.module.financing.service.FinancingContactLogService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * <p>
 * 融资申请表 服务实现类
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
@Service
@Slf4j
@AllArgsConstructor
public class FinancingApplyServiceImpl extends ServiceImpl<FinancingApplyDao, FinancingApply> implements FinancingApplyService {
    private final FinancingContactLogService financingContactLogService;
    /**
     * 添加融资申请
     * @param financingApply
     */
    @Override
    public void addFinancingApply(FinancingApply financingApply) {
        ValidatorUtils.validateEntity(financingApply);
        financingApply.insert();
    }

    /**
     * 编辑融资申请
     * @param financingApply
     */
    @Override
    public void editFinancingApply(FinancingApply financingApply) {
        ValidatorUtils.validateEntity(financingApply);
        financingApply.updateById();
    }

    /**
     * 添加交谈记录
     * @param financingContactLog
     */
    @Override
    public void addFinancingcontactLog(FinancingContactLog financingContactLog) {
        ValidatorUtils.validateEntity(financingContactLog);
        financingContactLog.insert();
    }

    /**
     * 分页列表查询
     * @param map
     * @param page
     * @return
     */
    @Override
    public Page<FinancingApply> queryFinancingApplyList(Map<String, Object> map, Page<FinancingApply> page) {
        List<FinancingApply> financingApplies = baseMapper.queryList(map,page);

        financingApplies.forEach(financing->{
            financing.setFinancingContactLogs(financingContactLogService.selectList(new EntityWrapper<FinancingContactLog>().eq("financing_apply_id",financing.getId())));
        });
        page.setRecords(financingApplies);
        return page;
    }

    /**
     * 单条数据查询
     * @param financingApplyId
     * @return
     */
    @Override
    public FinancingApply queryById(Long financingApplyId) {
        return Optional.ofNullable(this.selectOne(new EntityWrapper<FinancingApply>().eq("id",financingApplyId)))
                .map(financingApply->{
                    return financingApply.setFinancingContactLogs(financingContactLogService.selectList(new EntityWrapper<FinancingContactLog>().eq("financing_apply_id",financingApplyId)));
                })
                .orElseThrow(()->new BizException("产品不存在"));

    }


}
