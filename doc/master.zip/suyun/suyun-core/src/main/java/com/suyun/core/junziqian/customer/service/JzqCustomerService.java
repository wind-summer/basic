package com.suyun.core.junziqian.customer.service;

import com.junziqian.api.response.OrganizationAuditStatusResponse;
import com.suyun.core.module.customer.service.dto.CustomerDetailDTO;

/**
 * 君子签-企业认证
 *
 * @author luyang
 * @since  2018年2月7日 15:22:51
 */
public interface JzqCustomerService {

    /**
     * 发送君子签数据
     * @param customerDetailDTO
     */
    void sendJunZiQian(CustomerDetailDTO customerDetailDTO);

    /**
     * 根据邮箱查询企业审核状态
     * @param email
     * @return
     */
    OrganizationAuditStatusResponse queryOrganizationStatus(String email);
}
