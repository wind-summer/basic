package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.suyun.core.module.customer.enums.CustomerAttributeEnum;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @author caosg
 * @Description: 客户基本信息
 * @date 2017/12/1 下午4:16
 */
@Data
@Accessors(chain = true)
@JsonTypeName(value = "CUSTOMER_BASE")
public class BaseAttributeDTO extends CustomerAttributeDTO {

    public BaseAttributeDTO() {
        super(CustomerAttributeEnum.BASE.getValue());
    }

    /**
     * 公司行业
     */
    @NotBlank(message = "主营产品不能为空")
    private String industry;
    /**
     * 公司规模
     */
    @NotBlank(message = "公司规模不能为空")
    private String scale;
    /**
     * 公司地址
     */
    @NotBlank(message = "公司地址不能为空")
    private String address;
    /**
     * 注册资本
     */
    @NotBlank(message = "注册资金不能为空")
    private String registeredCapital;

    /**
     * 企业法人
     */
    @NotBlank(message = "法人姓名不能为空")
    private String legalName;

    /**
     * 法人身份证号
     */
    @NotBlank(message = "法人身份证号不能为空")
    private String legalIdentityCard;

    /**
     * 法人手机号
     */
    @NotBlank(message = "法人手机号不能为空")
    private String legalMobile;
}
