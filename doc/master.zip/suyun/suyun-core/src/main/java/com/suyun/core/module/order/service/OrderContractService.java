package com.suyun.core.module.order.service;

import com.suyun.core.module.order.entity.OrderContract;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 订单销售合同 服务类
 * </p>
 *
 * @author caosg
 * @since 2018-02-08
 */
public interface OrderContractService extends IService<OrderContract> {

    /**
     * 签约合同
     * @param orderId
     */
    OrderContract sign(Long orderId);

    /**
     * 生成签约连接地址
     * @param orderId
     * @return
     */
    String signLink(Long orderId);

    /**
     * 获取签约详情地址
     * @param orderId
     * @return
     */
    String signDetailLink(Long orderId);

    /**
     * 获取合同下载地址
     * @param orderId
     * @return
     */
    String signDownloadLink(Long orderId);

    /**
     * 根据订单ID，获取电子合同
     * @param orderId
     * @return
     */
    OrderContract getContractByOrderId(Long orderId);

    /**
     * 签约结果处理
     * @param applyNo
     * @param status
     */
    void callback(String applyNo,int status);
}
