package com.suyun.core.module.customer.service;

import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.customer.entity.CustomerType;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerTypeService extends IService<CustomerType> {

}
