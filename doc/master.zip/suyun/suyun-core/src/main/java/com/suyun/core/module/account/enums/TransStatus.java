package com.suyun.core.module.account.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 交易状态
 *
 * @author zhangjq
 * @Date 2017-12-29
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum TransStatus implements IEnum {

    /**
     * 表示交易失败
     */
    FAILURE_TRANS(0, "失败"),
    /**
     * 表示交易成功
     */
    SUCCESS_TRANS(1, "成功"),
    /**
     * 表示待审核
     */
    APPLY_TRANS(2, "待审"),

    /**
     * 表示冻结
     */
    FREEZE_TRANS(3, "冻结"),

    /**
     * 表示解冻
     */
    UNFREEZE_TRANS(4, "解冻");

    private Integer value;
    private String desc;

    TransStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return this.desc;
    }


    @Override
    public String toString() {
        return "ApplyStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
