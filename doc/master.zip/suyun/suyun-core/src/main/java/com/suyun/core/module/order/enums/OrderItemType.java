package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 商品类型
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum OrderItemType implements IEnum{
    SALE(1,"销售商品"),
    GIFT(2,"赠品");

    private Integer value;
    private String desc;

    OrderItemType(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }
}
