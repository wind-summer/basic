package com.suyun.core.module.bidding.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum BiddingRecordStatus implements IEnum {

    CLOSED(0,"已关闭"),
    BIDDING(1,"竞价中"),
    SUCCESS(2,"竞价成功"),
    FAIL(3,"竞价失败"),
    ORDERED(4,"已下单"),
    BREAK_PROMISE(5,"已违约"),
    CANCELED(6,"已取消"),
    PAID(7,"已付款"),
    STATISTICS(8,"统计中");

    private Integer value;
    private String desc;

    BiddingRecordStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }

    @Override
    public String toString() {
        return "BiddingStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
