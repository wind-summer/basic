package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_event")
public class OrderEvent extends BaseEntity<OrderEvent> {

    private static final long serialVersionUID = 1L;

    /**
     * 源状态
     */
	@TableField("source_status")
	private OrderStatus sourceStatus;
    /**
     * 目标状态
     */
	@TableField("target_status")
	private OrderStatus targetStatus;
    /**
     * 订单事件
     */
	@TableField("order_event")
	private com.suyun.core.module.order.enums.OrderEvent orderEvent;
	@TableField("create_by")
	private String createBy;
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
    /**
     * 备注
     */
	private String remark;
	@TableField("order_id")
	private Long orderId;

}
