package com.suyun.core.module.demo.dao.typehandler;

import com.suyun.core.config.mybatis.typehandler.JsonTypeHandler;
import com.suyun.core.module.demo.service.dto.AddressDTO;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author caosg
 * @version V1.0
 * @Description: address JSON 类型转换
 * @date 2017/11/30 上午9:59
 */
@MappedTypes(value = AddressDTO.class)
public class AddressJsonTypeHandler extends JsonTypeHandler<AddressDTO>{
    public AddressJsonTypeHandler(Class<AddressDTO> clazz) {
        super(clazz);
    }
}
