package com.suyun.core.module.physicallibrary.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.physicallibrary.entity.BasePropRank;

/**
 * <p>
 * 物性表-级别分类 Mapper 接口
 * </p>
 *
 * @author zhangjiaqi
 * @since 2017-12-20
 */
public interface BasePropRankDao extends BaseMapper<BasePropRank> {

}
