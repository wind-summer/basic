package com.suyun.core.module.order.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.entity.OrderShipping;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.service.dto.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
public interface OrderService extends IService<Order> {

    /**
     * 根据订单编号查询订单
     * @param orderNo 订单编号
     * @return
     */
    OrderDTO getOrderByOrderNo(String orderNo);

    /**
     * 查询订单明细
     * @param orderId 订单ID
     * @return
     */
    OrderDTO getOrderById(Long orderId);

    /**
     * 客户下单
     * @param order
     */
    Order createOrder(Order order);

    /**
     * 编辑订单,只允许编辑产品数量、价格、支付方式
     * @param adjustParamDTO
     * @return
     */
    Order editOrder(AdjustParamDTO adjustParamDTO);

    /**
     * 接收订单事件
     * @param orderId
     * @param orderEvent
     * @param isOwner 是否是我的订单
     * @return
     */
    boolean  handleEvent(Long orderId,OrderEvent orderEvent,boolean isOwner, Object... extParams );

    /**
     * 前端用户查询我的订单
     * @param page
     * @param orderCode
     * @return
     */
    Page<Order> queryMyOrder(Page<Order> page,String orderCode);


    /**
     * 多条件查询订单
     * @param params 查询条件
     * @param page
     * @return
     */
    Page<Order> queryOrder(Map<String,Object> params, Page<Order> page);

    /**
     * 上传支付凭证
     * @param orderId
     * @param voucherDTO
     */
    void addPayment(Long orderId,PayVoucherDTO voucherDTO);

    /**
     * 查询订单操作日志
     * @param orderId
     * @return
     */
    List<com.suyun.core.module.order.entity.OrderEvent> queryOrderLog(Long orderId);

    /**
     * 我的订单统计
     * @return
     */
    List<CustomerOrderDashboardDTO>  getMyOrderDashboard();

    /**
     * 统计订单各状态数
     * @return
     */
    Map<String,Integer>  countOrderStatus();

    /**
     * 发货
     * @param orderCode
     * @param shippings
     */
    void deliver(String orderCode,List<OrderShipping> shippings);

    /**
     * 订单发货强制完成
     * @param orderFinishDTO
     */
    void finish(OrderFinishDTO orderFinishDTO);

}
