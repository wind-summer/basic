package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.module.customer.enums.AddressTypeEnum;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;



/**
 * <p>
 *
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_customer_address")
public class CustomerAddress extends BaseEntity<CustomerAddress> {

	@TableField("address_name")
	private String addressName;
	@TableField("customer_id")
	private Long customerId;
	@TableField("address_id")
	private Long addressId;
	/**
	 * 默认地址  1：是 0：否
	 */
	@TableField("is_default")
	private Boolean defaultAddress;

	/**
	 * 地址类型
	 */
	@TableField("address_type")
	private AddressTypeEnum addressType;


}
