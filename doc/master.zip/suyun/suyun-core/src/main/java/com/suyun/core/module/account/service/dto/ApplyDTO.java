package com.suyun.core.module.account.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * @author zhangjq
 * @Description: 充值申请
 * @date 2017年12月28日 18：:2
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplyDTO {


    /**
     * 金额
     */
    @NotNull(message = "金额不能为空")
    @DecimalMin(value = "1", message = "充值金额至少1元")
    private BigDecimal amount;

    /**
     * 支付编码
     */
    @NotNull(message = "付款识别码不能为空")
    @Size(min = 0, max = 6, message = "长度必须为0到6位")
    private String paymentCode;

    /**
     * 上传付款凭证路径
     */
    private String picture;


}
