package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.customer.enums.IdentificationTypeEnum;
import com.suyun.core.module.order.enums.ContractStatus;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 订单销售合同
 * </p>
 *
 * @author caosg
 * @since 2018-02-08
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_contract")
public class OrderContract extends BaseEntity<OrderContract> {

    private static final long serialVersionUID = 1L;

    /**
     * 合同签约编号
     */
	@TableField("apply_no")
	private String applyNo;
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
    /**
     * 签约人名称
     */
	@TableField("full_name")
	private String fullName;
    /**
     * 证件类型
     */
	@TableField("identity_type")
	private IdentificationTypeEnum identityType;
    /**
     * 证件号码
     */
	@TableField("identity_no")
	private String identityNo;
    /**
     * 签约链接地址 
     */
	@TableField("sign_link")
	private String signLink;
    /**
     * 签约详情地址 

     */
	@TableField("contract_link")
	private String contractLink;
    /**
     * 状态。
     */
	private ContractStatus status;
	@TableField("order_id")
	private Long orderId;
    /**
     * 签约连接地址起始时间，，24小时有效
     */
	@TableField("sign_link_start")
	private Date signLinkStart;
    /**
     * 签约详情连接起始时间
     */
	@TableField("contract_link_start")
	private Date contractLinkStart;

    /**
     * 电子合同下载地址，24小时有效
     */
	@TableField("download_link")
	private String downloadLink;

    /**
     * 电子合同下载地址起始时间，24小时有效
     */
	@TableField("download_link_start")
	private Date   downloadLinkStart;


}
