package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_customer_type")
public class CustomerType extends BaseEntity<CustomerType> {

    private static final long serialVersionUID = 1L;

	@TableField("role_name")
	private String roleName;
	@TableField("role_code")
	private String roleCode;
	@TableField("parent_role_code")
	private String parentRoleCode;
	private String description;


}
