package com.suyun.core.module.article.dao;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import com.suyun.common.utils.Query;
import com.suyun.core.module.article.entity.Article;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.product.entity.CustomerProduct;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
public interface ArticleDao extends BaseMapper<Article> {

    /**
     * 分页列表查询
     *
     * @return
     */
    List<Article> selectArticleList(Map<String,Object> params,Page<Article> page);
}
