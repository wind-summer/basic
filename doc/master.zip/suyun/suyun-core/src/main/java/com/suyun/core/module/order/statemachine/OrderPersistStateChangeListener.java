package com.suyun.core.module.order.statemachine;

import com.suyun.common.exception.BizException;
import com.suyun.core.module.order.dao.OrderDao;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.enums.YesOrNo;
import com.suyun.core.module.order.service.OrderConstant;
import com.suyun.core.utils.LoginUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.state.State;
import org.springframework.statemachine.transition.Transition;

/**
 * @author caosg
 * @Description: 订单状态修改监听器，保存订单最新状态
 * @date 2017/12/11 上午10:02
 */
@Slf4j
public class OrderPersistStateChangeListener implements OrderPersistStateMachineHandler.PersistStateChangeListener {

    @Autowired
    private OrderDao orderDao;

    /**
     * 当状态被持久化，调用此方法.
     *
     * @param state        the state
     * @param message      the message
     * @param transition   the transition
     * @param stateMachine the state machine
     */
    @Override
    public void onPersist(State<OrderStatus, OrderEvent> state, Message<OrderEvent> message, Transition<OrderStatus, OrderEvent> transition, StateMachine<OrderStatus, OrderEvent> stateMachine) {
        log.debug("---- Event state:{} ,--- Message:{}", state, message.getHeaders());
        if (message != null && message.getHeaders().containsKey(OrderConstant.EVENT_MESSAGE_HEADER_KEY)) {
            Order order = message.getHeaders().get(OrderConstant.EVENT_MESSAGE_HEADER_KEY, Order.class);
            if (!message.getPayload().equals(OrderEvent.CREATE)) {
                //支付后修改支付状态
                if(message.getPayload().equals(OrderEvent.PAYMENT)){
                    order.setPaymentStatus(YesOrNo.YES);
                }
                //发货后修改发货状态
//                if(message.getPayload().equals(OrderEvent.DELIVER)){
//                    order.setShippingStatus(YesOrNo.YES);
//                }
                orderDao.updateById(order.setOrderStatus(state.getId()).setUpdateBy(LoginUtils.getLoginName()));
            }

        } else {
            throw new BizException("Event message is null");
        }

    }
}
