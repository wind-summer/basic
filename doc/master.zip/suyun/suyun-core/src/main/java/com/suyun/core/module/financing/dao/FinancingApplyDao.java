package com.suyun.core.module.financing.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.financing.entity.FinancingApply;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 融资申请表 Mapper 接口
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
public interface FinancingApplyDao extends BaseMapper<FinancingApply> {

    /**
     * 列表查询
     * @param map
     * @param page
     * @return
     */
     List<FinancingApply> queryList(Map<String,Object> map, Page<FinancingApply> page);


}
