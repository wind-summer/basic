package com.suyun.core.module.financing.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.financing.entity.FinancingApply;
import com.suyun.core.module.financing.entity.FinancingContactLog;

import java.util.Map;

/**
 * <p>
 * 融资申请表 服务类
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
public interface FinancingApplyService extends IService<FinancingApply> {

    /**
     * 添加融资申请
     * @param financingApply
     */
    void addFinancingApply(FinancingApply financingApply);

    /**
     * 编辑融资申请
     * @param financingApply
     */
    void editFinancingApply(FinancingApply financingApply);

    /**
     * 添加日志
     * @param financingContactLog
     */
    void addFinancingcontactLog(FinancingContactLog financingContactLog);

    /**
     * 分页查询
     * @param map
     * @param page
     * @return
     */
    Page<FinancingApply> queryFinancingApplyList(Map<String,Object> map,Page<FinancingApply> page);

    /**
     * 单条数据数据查询
     * @param financingApplyId
     * @return
     */
    FinancingApply queryById(Long financingApplyId);
}
