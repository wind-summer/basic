package com.suyun.core.module.order.service.dto;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2018/2/28 下午2:48
 */
@Data
@Accessors(chain = true)
public class ContractDTO {
    private String detailUrl;
    private String downloadUrl;
}
