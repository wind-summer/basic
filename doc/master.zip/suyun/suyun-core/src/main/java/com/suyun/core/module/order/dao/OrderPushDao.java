package com.suyun.core.module.order.dao;

import com.suyun.core.module.order.entity.OrderPush;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
public interface OrderPushDao extends BaseMapper<OrderPush> {

    /**
     * 获取当前订单是否为重复推送数据
     * @param orderId
     * @param status
     * @return
     */
    List<OrderPush> queryOrderPushByorderId(@Param("orderId") Long orderId,@Param("status") Integer status);

    /**
     * 通过订单id查询订单最新的推送返回信息
     * @author wanggf
     * @param orderId
     * @return
     */
    OrderPush queryNewOrderPushByOrderId(@Param("orderId")Long orderId);
}
