package com.suyun.core.junziqian.customer.service.impl;

import com.junziqian.api.JunziqianClient;
import com.junziqian.api.common.Constants;
import com.junziqian.api.common.org.OrganizationType;
import com.junziqian.api.request.OrganizationAuditStatusRequest;
import com.junziqian.api.request.builder.OrganizationCreateBuilder;
import com.junziqian.api.response.OrganizationAuditStatusResponse;
import com.junziqian.api.response.OrganizationCreateResponse;
import com.junziqian.api.util.LogUtils;
import com.suyun.common.sms.BizType;
import com.suyun.common.sms.MsgDTO;
import com.suyun.common.sms.MsgService;
import com.suyun.common.sms.SmsProperties;
import com.suyun.core.junziqian.customer.service.JzqCustomerService;
import com.suyun.core.module.customer.dao.CustomerDao;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.enums.IdentificationTypeEnum;
import com.suyun.core.module.customer.service.dto.CustomerDetailDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.ebaoquan.rop.request.UploadFile;
import org.ebaoquan.rop.security.MainError;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import java.util.HashSet;
import java.util.Set;

/**
 * 君子签-企业认证
 *
 * @author luyang
 * @since  2018年2月7日 15:22:51
 */
@Service
@AllArgsConstructor
@Slf4j
public class JzqCustomerServiceImpl implements JzqCustomerService {

    private final JunziqianClient junziqianClient;

    private final CustomerDao customerDao;

    private final SmsProperties smsProperties;

    private final MsgService msgService;

    /**
     * 发送君子签数据
     * @param customerDetailDTO
     */
    @Async
    @Override
    public void sendJunZiQian(CustomerDetailDTO customerDetailDTO){
        try {
            OrganizationCreateResponse response = junziqianClient.organizationCreate(getOrganizationCreateBuilder(customerDetailDTO).build());
            LogUtils.logResponse(response);
            if (response.isSuccess()) {
                customerDao.updateAuditStatus(customerDetailDTO.getId(),CustomerStatusEnum.SUCCESS,"");
                this.sendMsg(customerDetailDTO.getPrimaryPhone());
                System.out.println("**发送君子签--操作成功!");
            } else {
                MainError error = response.getError();
                customerDao.updateAuditStatus(customerDetailDTO.getId(), CustomerStatusEnum.FAIL,error.getMessage());
                System.out.println("**发送君子签--操作失败!");
            }
        }catch (Exception e){
            String failReasonl = "";
            if(e.getMessage().length()<100){
                failReasonl = e.getMessage();
            }else{
                failReasonl = "发送君子签异常，请重新审核发送";
            }
            customerDao.updateAuditStatus(customerDetailDTO.getId(), CustomerStatusEnum.AWAIT_AUTHENTICATION,failReasonl);
            System.out.println("**发送君子签--操作异常："+e.getMessage());
        }
    }

    /**
     * 根据邮箱查询企业审核状态
     * @param email
     * @return
     */
    @Override
    public OrganizationAuditStatusResponse queryOrganizationStatus(String email){
        OrganizationAuditStatusRequest request = new OrganizationAuditStatusRequest();
        //企业注册邮箱
        request.setEmailOrMobile(email);
        OrganizationAuditStatusResponse response = junziqianClient.organizationStatus(request);
        LogUtils.logResponse(response);
        return response;
    }

    /**
     * 数据转换
     * @param customerDetailDTO
     * @return
     */
    private OrganizationCreateBuilder getOrganizationCreateBuilder(CustomerDetailDTO customerDetailDTO) throws  Exception{
        OrganizationCreateBuilder builder = new OrganizationCreateBuilder();
        //企业注册邮箱
        builder.withEmailOrMobile(customerDetailDTO.getEmail());
        //企业全称
        builder.withName(customerDetailDTO.getName());
        //法人姓名或者是被授权人姓名
        builder.withLegalName(customerDetailDTO.getLegalName());
        //法人身份证号或者是被授权人身份证号
        builder.withLegalIdentityCard(customerDetailDTO.getLegalIdentityCard());
        //法人手机号或者是被授权人手机号
        builder.withLegalMobile(customerDetailDTO.getPrimaryPhone());
        /**
         * 企业类型选择传统多证（0）时 则需要传 组织机构代码和组织机构代码复印件；选择多证合一（1）则不需要传组织机构代码和组织机构代码复印件
         */
        if(IdentificationTypeEnum.IDENTIFICATION_TYPE_ALLINONE == customerDetailDTO.getIdentificationType()){
            //多证合一
            builder.withIdentificationType(Constants.IDENTIFICATION_TYPE_ALLINONE);
            //社会信用代码
            builder.withOrganizationRegNo(customerDetailDTO.getBizCreditCode());
            //营业执照复印件
            builder.withOrganizationRegImg(uploadFile(customerDetailDTO.getBizLogoUrl()));
        }else if(IdentificationTypeEnum.IDENTIFICATION_TYPE_TRADITIONAL == customerDetailDTO.getIdentificationType()){
            //传统三证
            builder.withIdentificationType(Constants.IDENTIFICATION_TYPE_TRADITIONAL);
            //营业执照号
            builder.withOrganizationRegNo(customerDetailDTO.getOrganizationRegNo());
            //营业执照复印件
            builder.withOrganizationRegImg(uploadFile(customerDetailDTO.getBizLogoUrl()));
            //组织结构代码
            builder.withOrganizationCode(customerDetailDTO.getOrganizationCode());
            //组织机构复印件
            builder.withOrganizationCodeImg(uploadFile(customerDetailDTO.getOrganizationCodeImg()));
            //税务登记扫描件
            builder.withTaxCertificateImg(uploadFile(customerDetailDTO.getTaxCertificateImg()));
        }
        //企业类型(默认选企业)
        builder.withOrganizationType(OrganizationType.ENTERPRISE.getCode());
        //企业公章图片，图片规格170*170PX，背景透明。该字段只适用与不提交君子签企业授权服务书。
        builder.withSignImg(uploadFile(customerDetailDTO.getSignImg()));
//        //君子签企业授权服务书
//        builder.withSignApplication(uploadFile(customerDetailDTO.getSignApplication()));
        return builder;
    }

    /**
     * 文件上传
     * @param localFilePath
     * @return
     */
    private static UploadFile uploadFile(String localFilePath) throws Exception {
        Resource urlResource = new UrlResource(localFilePath);
        String fileName = localFilePath.substring(localFilePath.lastIndexOf('/')+1);
        fileName = fileName.substring(0,fileName.lastIndexOf('.')-1);
        System.out.println(fileName);
        byte[] contentx = FileCopyUtils.copyToByteArray(urlResource.getInputStream());
        return new UploadFile(fileName,contentx);
    }

    /**
     * 发送短信
     * @param phone
     */
    private void sendMsg(String phone){
        MsgDTO msgDTO = new MsgDTO();
        Set<String> set=new HashSet<>();
        msgDTO.setTemplateCode(smsProperties.getCustomerAuditSuccess());
        msgDTO.setBizType(BizType.OTHER).setPhones(set);
        set.add(phone);
        msgService.sendSms(msgDTO);
    }
}
