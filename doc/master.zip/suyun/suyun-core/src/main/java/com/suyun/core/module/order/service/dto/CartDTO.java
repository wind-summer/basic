package com.suyun.core.module.order.service.dto;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author caosg
 * @version V1.0
 * @Description: 购物车
 * @date 2017/12/6 下午1:58
 */
@Data
@Accessors(fluent = true)
public class CartDTO {
    private Long loginId;
    private Long productId;
    private Long skuId;
    private Integer quantity;
}
