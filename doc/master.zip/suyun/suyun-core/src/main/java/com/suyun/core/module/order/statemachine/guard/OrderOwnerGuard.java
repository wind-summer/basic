package com.suyun.core.module.order.statemachine.guard;

import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.service.OrderConstant;
import com.suyun.core.utils.CurrentUserUtils;
import org.springframework.messaging.Message;
import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.guard.Guard;
import org.springframework.stereotype.Component;

/**
 * @author caosg
 * @version V1.0
 * @Description: 确认和签收操作，要确保当前登陆者是订单的下单人
 * @date 2017/12/15 上午9:14
 */
@Component
public class OrderOwnerGuard implements Guard<OrderStatus,OrderEvent> {

    @Override
    public boolean evaluate(StateContext<OrderStatus, OrderEvent> stateContext) {
        Message<OrderEvent> message = stateContext.getMessage();
        if (message != null && message.getHeaders().containsKey(OrderConstant.EVENT_MESSAGE_HEADER_KEY)) {
            Order order = message.getHeaders().get("order", Order.class);
            return order.getCustomerId().equals(CurrentUserUtils.getLogin().getCustomerId());
        }
        return false;
    }
}
