package com.suyun.core.module.demo.dao;

import com.suyun.core.module.demo.entity.Demo;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 示例Demo Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-11-23
 */
public interface DemoDao extends BaseMapper<Demo> {
    /**
     * JSON数据类型示例
      * @param demo
     */
   void saveJson(Demo demo);

   List<String> getId();
}
