package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.google.common.collect.Maps;
import com.junziqian.api.common.IdentityType;
import com.junziqian.api.response.ApplySignResponse;
import com.junziqian.api.response.SignLinkResponse;
import com.junziqian.api.util.LogUtils;
import com.suyun.common.exception.BizException;
import com.suyun.common.utils.DateUtils;
import com.suyun.common.utils.NumberToCN;
import com.suyun.core.junziqian.JunziQianProperties;
import com.suyun.core.junziqian.OrderSignService;
import com.suyun.core.module.customer.enums.IdentificationTypeEnum;
import com.suyun.core.module.customer.service.dto.BankAttributeDTO;
import com.suyun.core.module.customer.service.dto.BaseAttributeDTO;
import com.suyun.core.module.customer.service.dto.BizAttributeDTO;
import com.suyun.core.module.order.dao.OrderContractDao;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.entity.OrderContract;
import com.suyun.core.module.order.enums.ContractStatus;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.service.OrderContractService;
import com.suyun.core.module.order.service.OrderService;
import com.suyun.core.module.order.service.dto.OrderDTO;
import com.suyun.core.sys.service.SysDictionaryService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 订单销售合同 服务实现类
 * </p>
 *
 * @author caosg
 * @since 2018-02-08
 */
@Service
@AllArgsConstructor
@Slf4j
public class OrderContractServiceImpl extends ServiceImpl<OrderContractDao, OrderContract> implements OrderContractService {

    private final OrderSignService orderSignService;

    private final OrderService orderService;

    private final JunziQianProperties junziQianProperties;

    private final SysDictionaryService dictionaryService;

    @Override
    @Async
    @Transactional(rollbackFor = Exception.class)
    public OrderContract sign(Long orderId) {

       OrderDTO orderDTO = orderService.getOrderById(orderId);
       if(orderDTO == null) {
          throw new BizException("订单："+orderId+" 不存在");
       }
       OrderContract orderContract = buildApplySign(orderDTO);
       if(orderContract!=null){
           this.insertOrUpdate(orderContract);
           //修改订单电子上传标志
           orderService.updateById(orderDTO.getOrder().setSignStatus(ContractStatus.UPLOADED));
       }
       return orderContract;
    }

    @Override
    public String signLink(Long orderId) {
        OrderContract  orderContract = this.getContractByOrderId(orderId);
        if(orderContract == null ){
           orderContract = this.sign(orderId);
           return orderContract.getSignLink();
        }
        if(orderContract!=null&& StringUtils.isNotEmpty(orderContract.getSignLink()) ){
            Date now = new Date();
            //签约地址有效期为24小时
            if(now.getTime() - orderContract.getSignLinkStart().getTime()>= junziQianProperties.getExpireTime()*60*60*1000){
                //获取签约地址链接
                Map<String,Object> customer = Maps.newHashMap();
                customer.put("fullName",orderContract.getFullName());
                customer.put("idType",orderContract.getIdentityType()== IdentificationTypeEnum.IDENTIFICATION_TYPE_TRADITIONAL? IdentityType.BIZLIC:IdentityType.USCC);
                customer.put("idCard",orderContract.getIdentityNo());
                SignLinkResponse signLinkResponse = orderSignService.signLink(orderContract.getApplyNo(),customer);
                if (signLinkResponse.isSuccess()){
                    try {
                        orderContract.setSignLink(signLinkResponse.getLink()+"&backUrl="+ URLEncoder.encode(junziQianProperties.getBackUrl(),"UTF-8"));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    orderContract.setSignLinkStart(new Date());
                    this.updateById(orderContract);
                }else {
                    log.error("获取签约地址出现异常:{}",signLinkResponse.getError());
                    LogUtils.logResponse(signLinkResponse);
                    throw new BizException("获取签约地址出现异常："+signLinkResponse.getError().getCode());
                }
            }
            return orderContract.getSignLink();
        }else {
            throw new BizException("获取签约地址出现异常");
        }
    }

    @Override
    public String signDetailLink(Long orderId) {
        OrderContract  orderContract = this.getContractByOrderId(orderId);
        if(orderContract == null){
            throw new BizException("订单："+orderId+" 还未签约。");
        }
        Date now = new Date();
        if (StringUtils.isNotEmpty(orderContract.getContractLink())&&
                (now.getTime()-orderContract.getContractLinkStart().getTime()< junziQianProperties.getExpireTime()*60*60*1000) ){
            return orderContract.getContractLink();
        }
        //获取签约详情查看链接
        SignLinkResponse detailLinkResponse = orderSignService.signDetail(orderContract.getApplyNo());
        if(detailLinkResponse.isSuccess()){
            orderContract.setContractLink(detailLinkResponse.getLink());
            orderContract.setContractLinkStart(new Date());
            this.updateById(orderContract);
        }else {
            LogUtils.logResponse(detailLinkResponse);
            log.error("获取签约详情地址出现异常：{}",detailLinkResponse.getError());
            throw new BizException("获取签约详情地址出现异常："+detailLinkResponse.getError().getCode());
        }
        return orderContract.getContractLink();
    }

    @Override
    public String signDownloadLink(Long orderId) {
        OrderContract  orderContract = this.getContractByOrderId(orderId);
        if(orderContract == null){
            throw   new BizException("订单："+orderId+" 还未签约。");
        }
        Date now = new Date();
        if (StringUtils.isNotEmpty(orderContract.getDownloadLink())&&
                (now.getTime() - orderContract.getDownloadLinkStart().getTime()< junziQianProperties.getExpireTime()*60*60*1000) ){
            return orderContract.getDownloadLink();
        }
        //获取电子合同下载链接
        SignLinkResponse downloadLinkResponse = orderSignService.fileLink(orderContract.getApplyNo());
        if(downloadLinkResponse.isSuccess()){
            orderContract.setDownloadLink(downloadLinkResponse.getLink());
            orderContract.setDownloadLinkStart(new Date());
            this.updateById(orderContract);
        }else {
            log.error("获取电子合同下载地址出现异常：{}",downloadLinkResponse.getError());
            LogUtils.logResponse(downloadLinkResponse);
            throw new BizException("获取电子合同下载地址出现异常："+downloadLinkResponse.getError().getCode());
        }
        return orderContract.getDownloadLink();
    }

    @Override
    public OrderContract getContractByOrderId(Long orderId) {
        return baseMapper.selectOne(new OrderContract().setOrderId(orderId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void callback(String applyNo, int status) {
        OrderContract  orderContract = baseMapper.selectOne(new OrderContract().setApplyNo(applyNo));
        if(orderContract==null){
            throw  new BizException("签约单号："+applyNo+"不存在");
        }
        ContractStatus contractStatus = ContractStatus.getContractStatusByValue(status);
        if(orderContract.getStatus() == contractStatus) {
            return;
        }
        orderContract.setStatus(contractStatus);
        //用户已签约，自动完成订单确认操作
        if(contractStatus==ContractStatus.SUCCESS){
            boolean result;
            result = orderService.handleEvent(orderContract.getOrderId(), OrderEvent.CONFIRM, false);
            if (!result) {
                throw new BizException("订单状态不符合流程");
            }

        }
        //用户拒签，取消订单
        if(contractStatus==ContractStatus.REJECT){
            boolean result;
            result = orderService.handleEvent(orderContract.getOrderId(), OrderEvent.CANCEL, false);
            if (!result) {
                throw new BizException("订单状态不符合流程");
            }

        }

        //修改订单电子上传标志
        Order order = orderService.selectById(orderContract.getOrderId());
        orderService.updateById(order.setSignStatus(contractStatus));
        this.updateById(orderContract);

    }

    private OrderContract buildApplySign(OrderDTO orderDTO){
        //组装企业客户信息
        Map<String,Object> customer = Maps.newHashMap();
        customer.put("fullName",orderDTO.getUser().getCustomer().getName());
        customer.put("mobile",orderDTO.getUser().getCustomer().getPrimaryPhone());
        customer.put("email",orderDTO.getUser().getCustomer().getEmail());
        //客户工商信息
        BizAttributeDTO bizAttributeDTO =  (BizAttributeDTO)orderDTO.getUser().getAttributes().stream().filter(
                attributes ->attributes instanceof BizAttributeDTO
        ).collect(Collectors.toList()).get(0);
        customer.put("idType",bizAttributeDTO.getIdentificationType()== IdentificationTypeEnum.IDENTIFICATION_TYPE_TRADITIONAL? IdentityType.BIZLIC:IdentityType.USCC);
        customer.put("idCard",
                bizAttributeDTO.getIdentificationType()== IdentificationTypeEnum.IDENTIFICATION_TYPE_TRADITIONAL? bizAttributeDTO.getOrganizationRegNo():bizAttributeDTO.getBizCreditCode());
        Map<String,Object> contract = Maps.newHashMap();
        //todo 组装合同模板变量
        contract.put("contract_number",orderDTO.getOrder().getOrderCode());
        contract.put("buyer_name",orderDTO.getUser().getCustomer().getName());
        contract.put("sign_date", DateUtils.format(new Date(),DateUtils.DATE_TIME_PATTERN));
        contract.put("product_name",orderDTO.getOrder().getItems().get(0).getName());
        contract.put("product_model",orderDTO.getOrder().getItems().get(0).getGradeCode());
        contract.put("unit",dictionaryService.getNameByCode("UNIT", orderDTO.getOrder().getItems().get(0).getSku().getUnitCode()) );
        contract.put("unit_price",orderDTO.getOrder().getItems().get(0).getRetailPrice());
        contract.put("amount",orderDTO.getOrder().getItems().get(0).getQuantity());
        contract.put("money",orderDTO.getOrder().getTotal());
        contract.put("big_money", NumberToCN.number2CNMontrayUnit(orderDTO.getOrder().getTotal()));
        contract.put("buyer_linker",orderDTO.getUser().getCustomer().getLinker());
        contract.put("buyer_tel",orderDTO.getUser().getCustomer().getPrimaryPhone());
        contract.put("buyer_email",orderDTO.getUser().getCustomer().getEmail());
        contract.put("buyer_address",orderDTO.getUser().getDefaultAddress().getProvinceName()+orderDTO.getUser().getDefaultAddress().getCityName()+
                        orderDTO.getUser().getDefaultAddress().getAreaName()+orderDTO.getUser().getDefaultAddress().getAddress());
        contract.put("buyer_fax",orderDTO.getUser().getCustomer().getFax());
        //企业客户法人信信息
        BaseAttributeDTO baseAttributeDTO = (BaseAttributeDTO)orderDTO.getUser().getAttributes().stream()
                .filter(attributes -> attributes instanceof BaseAttributeDTO ).collect(Collectors.toList()).get(0);
        contract.put("deputy",baseAttributeDTO.getLegalName());
        //客户银行信息
        BankAttributeDTO bankAttributeDTO =(BankAttributeDTO)orderDTO.getUser().getAttributes().stream()
                .filter(attributes -> attributes instanceof BankAttributeDTO ).collect(Collectors.toList()).get(0);
        contract.put("card",bankAttributeDTO.getAccountNo());
        contract.put("bank",bankAttributeDTO.getBank());
        //todo 合同模板内容结束
        log.info("*** apply sign to JunZiQian API *******");
        ApplySignResponse applySignResponse=orderSignService.applySign(customer,contract);
        OrderContract  orderContract  ;
        if(applySignResponse.isSuccess()){
            String applyNo = applySignResponse.getApplyNo();
            orderContract = this.getContractByOrderId(orderDTO.getOrder().getId());
            if(orderContract==null){
                orderContract = new OrderContract();
            }
            orderContract.setApplyNo(applyNo).setOrderId(orderDTO.getOrder().getId()).setIdentityType(bizAttributeDTO.getIdentificationType())
                    .setStatus(ContractStatus.UPLOADED).setFullName(orderDTO.getUser().getCustomer().getName())
                    .setIdentityNo((String) customer.get("idCard"));
            //获取签约地址链接
            SignLinkResponse signLinkResponse = orderSignService.signLink(applyNo,customer);
            if (signLinkResponse.isSuccess()){
                try {
                    orderContract.setSignLink(signLinkResponse.getLink()+"&backUrl="+ URLEncoder.encode(junziQianProperties.getBackUrl(),"UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                orderContract.setSignLinkStart(new Date());
            }else {
                LogUtils.logResponse(signLinkResponse);
                throw new BizException("获取签约地址出现异常："+signLinkResponse.getError().getCode());
            }
        }else {
            log.error("上传签约失败：{}",applySignResponse.getError().getMessage());
            LogUtils.logResponse(applySignResponse);
            throw new BizException("签约失败："+applySignResponse.getError().getCode());
        }
        return orderContract;
    }
}
