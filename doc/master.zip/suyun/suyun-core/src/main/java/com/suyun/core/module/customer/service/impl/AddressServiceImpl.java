package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.common.exception.BizException;
import com.suyun.common.validator.Assert;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.module.customer.dao.AddressDao;
import com.suyun.core.module.customer.dao.CustomerAddressDao;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.entity.CustomerAddress;
import com.suyun.core.module.customer.enums.AddressTypeEnum;
import com.suyun.core.module.customer.service.AddressService;
import com.suyun.core.sys.service.SysAreaService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * 地址 服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
@AllArgsConstructor
@Slf4j
public class AddressServiceImpl extends ServiceImpl<AddressDao, Address> implements AddressService {

    private final AddressDao addressDao;

    private final CustomerAddressDao customerAddressDao;

    private final SysAreaService sysAreaService;
    /**
     * 根据customerId获取收货地址
     * @return
     */
    @Override
    public List<Address> getAddressList(){
        return addressDao.getAddressList(CurrentUserUtils.getLogin().getCustomerId());
    }

    /**
     * 保存收货地址
     * @param address
     * @return
     */
    @Override
    public Address addAddress(Address address) {
        log.info("ADD address info:{}",address);
        ValidatorUtils.validateEntity(address);
        this.buildAddress(address);
        //保存收货地址
        addressDao.insert(address);

        //保存中间表
        CustomerAddress customerAddress = new CustomerAddress()
                .setDefaultAddress(false)
                .setAddressId(address.getId())
                .setAddressName(address.getUserName())
                .setAddressType(AddressTypeEnum.SHIPPING)
                .setCustomerId(CurrentUserUtils.getLogin().getCustomerId());
        customerAddressDao.insert(customerAddress);
        return address;
    }


    /**
     * 根据id获取地址信息
     * @param addressId
     * @return
     */
    @Override
    public Address getAddressById(Long addressId){
        Assert.isNull(addressId,"地址id不能为空");
        return Optional.ofNullable(addressDao.selectById(addressId)).map(address -> {
            return address;
        }).orElseThrow(() -> new BizException("地址ID无效，无法获取数据"));
    }

    /**
     * 修改地址
     * @param address
     * @return
     */
    @Override
    public Address updateAddress(Address address){
        return Optional.ofNullable(addressDao.selectById(address.getId())).map(address1 -> {
            this.buildAddress(address);
            addressDao.updateById(address);
            return address;
        }).orElseThrow(() -> new BizException("地址ID无效，无法获取数据"));
    }

    /**
     * 根据id修改为默认地址
     * @param id
     */
    @Override
    public void updateIsDefault(Long id){
        Optional.ofNullable(addressDao.selectById(id)).map(address -> {
            //恢复原来默认地址
            customerAddressDao.resetDefaultAddress(CurrentUserUtils.getLogin().getCustomerId());
            //设置默认地址
            customerAddressDao.updateIsDefault(CurrentUserUtils.getLogin().getCustomerId(),id);
            return true;
        }).orElseThrow(() -> new BizException("地址ID无效，无法获取数据"));

    }

    /**
     * 获取当前登录人默认地址
     * @return
     */
    @Override
    public Address getdefaultaddress(){
        return customerAddressDao.getdefaultaddress(CurrentUserUtils.getLogin().getCustomerId());
    }

    /**
     * 查询收货地址省市名称
     * @param address
     * @return
     */
    @Override
    public Address  buildAddress(Address address) {
        if(address==null) {
            return address;
        }
        if(address.getProvince()!=null) {
            address.setProvinceName(sysAreaService.findById(address.getProvince()).getName());
        }
        if(address.getCity()!=null) {
            address.setCityName(sysAreaService.findById(address.getCity()).getName());
        }
        if(address.getArea()!=null) {
            address.setAreaName(sysAreaService.findById(address.getArea()).getName());
        }
        return address;
    }
}
