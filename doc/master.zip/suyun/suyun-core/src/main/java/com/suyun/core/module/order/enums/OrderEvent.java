package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 订单事件
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum OrderEvent implements IEnum{

    CREATE("create","创建"),
    AUDIT("audit","审核"),
    CONFIRM("confirm","确认"),
    PAYMENT("payment","支付"),
    DELIVER("deliver","发货"),
    RECEIVE("receive","收货"),
    CANCEL("cancel","取消");

    private String value;
    private String desc;

    OrderEvent(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
