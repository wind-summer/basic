package com.suyun.core.module.order.service.dto;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author caosg
 * @version V1.0
 * @Description: 付款凭证
 * @date 2017/12/12 上午11:47
 */
@Data
@Accessors(chain = true)
public class PayVoucherDTO {

    /**
     * 付款识别码
     */
    private String markCode;
    /**
     * 付款凭证url
     */
    private String voucherImage;
}
