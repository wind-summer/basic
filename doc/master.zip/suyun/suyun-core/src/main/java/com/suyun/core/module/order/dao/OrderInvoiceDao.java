package com.suyun.core.module.order.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.order.entity.OrderInvoice;

/**
 * <p>
 * 订单发票 Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
public interface OrderInvoiceDao extends BaseMapper<OrderInvoice> {

}
