package com.suyun.core.module.financing.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.financing.dao.FinancingContactLogDao;
import com.suyun.core.module.financing.entity.FinancingContactLog;
import com.suyun.core.module.financing.service.FinancingContactLogService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
@Service
public class FinancingContactLogServiceImpl extends ServiceImpl<FinancingContactLogDao, FinancingContactLog> implements FinancingContactLogService {

}
