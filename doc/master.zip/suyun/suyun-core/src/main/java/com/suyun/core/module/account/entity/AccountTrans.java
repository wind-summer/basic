package com.suyun.core.module.account.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.module.account.enums.TransReason;
import com.suyun.core.module.account.enums.TransStatus;
import com.suyun.core.module.account.enums.TransType;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 账户收支明细
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_account_trans")
public class AccountTrans extends BaseEntity<AccountTrans> {

    private static final long serialVersionUID = 1L;

    /**
     * 流水号
     */
    @TableField("trans_code")
    private String transCode;
    /**
     * 支出类型
     * 0： 账户充值
     * 1 ：账户提现
     * 2： 账户调整
     * 3: 缴纳保证金
     */
    @TableField("trans_type")
    private TransType transType;
    /**
     * 支出原因
     * 0：收入
     * 1：支出
     * 2：消费
     * 3：退款
     * 4. 竞价
     */
    @TableField("reason_type")
    private TransReason reasonType;
    /**
     * 备注信息
     */
    private String remark;

    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 状态
     * 0：失败
     * 1：成功
     * 2：待审
     * 3: 冻结
     * 4：解冻
     */
    @TableField("status")
    private TransStatus status;
    /**
     * 扩展信息属性
     */
    private String attributes;
    /**
     * 创建日期
     */
    @TableField("create_at")
    private Date createAt;
    /**
     * 修改日期
     */
    @TableField("update_at")
    private Date updateAt;
    /**
     * 支付编号
     */
    @TableField("payment_code")
    private String paymentCode;
    @TableField("account_id")
    private Long accountId;
    @TableField("customer_id")
    private Long customerId;

    /**
     * 接收公司
     */
    @TableField("receive_company")
    private String receiveCompany;

    /**
     * 账户余额
     */
    @TableField("balance")
    private BigDecimal balance;
}
