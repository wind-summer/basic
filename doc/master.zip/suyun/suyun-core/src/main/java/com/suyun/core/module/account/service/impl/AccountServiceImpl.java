package com.suyun.core.module.account.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.common.exception.BizException;
import com.suyun.common.utils.ConfigConstant;
import com.suyun.common.utils.SnowFlakeIdGenerator;
import com.suyun.core.module.account.dao.AccountDao;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.enums.AccountStatus;
import com.suyun.core.module.account.enums.AccountType;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.account.service.dto.AccountDetailDTO;
import com.suyun.core.module.account.service.dto.WithDrawDTO;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.entity.CustomerAttribute;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.service.CustomerAttributeService;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.sys.service.SysConfigService;
import com.suyun.core.sys.service.dto.PlatformBankDTO;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import static com.suyun.core.module.account.service.AccountConstant.ACCOUNT_CODE_PREFIX;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@Service
@AllArgsConstructor
public class AccountServiceImpl extends ServiceImpl<AccountDao, Account> implements AccountService {

    private final SysConfigService sysConfigService;

    private final CustomerService customerService;

    private final CustomerAttributeService customerAttributeService;

    private final SnowFlakeIdGenerator snowFlakeIdGenerator;

    /**
     * 创建账户
     *
     * @param account
     * @return
     */
    @Override
    public boolean createAccount(Account account) {
        return this.insert(account);
    }

    /**
     * 用客户ID查询账户
     *
     * @param customId
     * @return
     */
    @Override
    public Account findAccountByCustomerId(Long customId) {
        return Optional.ofNullable(this.selectOne(new EntityWrapper<Account>().eq("customer_id", customId)))
                .map((Account account) -> {
                    CustomerLogin customerLogin = CurrentUserUtils.getLogin();
                    String paymentcode = RandomStringUtils.randomNumeric(6);
                    if (customerLogin != null) {
                        CustomerAttribute customerAttribute = customerAttributeService.selectOne(new EntityWrapper<CustomerAttribute>().eq("customer_id", customId));
                        account.setPhone(customerLogin.getMobileNo())
                                .setPayment(paymentcode)
                                .setDto(sysConfigService.getConfigObject(ConfigConstant.PLATFORM_BANK_KEY, PlatformBankDTO.class));
                        if (customerAttribute != null) {
                            account.setCustomerdto(customerService.getBank(customId));
                        }
                    }
                    return account;
                }).orElseThrow(() -> new BizException("您的账户不存在"));
    }



    /**
     * 客户提现前查看账户信息
     *
     * @return
     */
    @Override
    public WithDrawDTO findWithDraw() {
        Account account = this.selectOne(new EntityWrapper<Account>().eq("customer_id", CurrentUserUtils.getLogin().getCustomerId()));
        CustomerLogin customerLogin = CurrentUserUtils.getLogin();
        if (customerLogin != null) {
            WithDrawDTO withdraw = new WithDrawDTO();
            CustomerAttribute customerAttribute = customerAttributeService.selectOne(new EntityWrapper<CustomerAttribute>().eq("customer_id", CurrentUserUtils.getLogin().getCustomerId()));
            if (account != null) {
                if (customerAttribute != null) {
                    withdraw.setPhone(customerLogin.getMobileNo())
                            .setId(account.getId()).setAmount(account.getAmount())
                            .setAvaliableAmount(account.getAvaliableAmount())
                            .setCustomerBank(customerService.getBank(CurrentUserUtils.getLogin().getCustomerId()));
                } else {
                    throw new BizException("该账户没有银行信息");
                }
                return withdraw;
            } else {
                this.createAccount(customerLogin.getCustomerId());
                return this.findWithDraw();
            }
        } else {
            throw new BizException("客户未登录");
        }
    }

    /**
     * 分页查询账户信息
     *
     * @param map
     * @param page
     * @return
     */
    @Override
    public Page<Account> findpage(Map<String, Object> map, Page<Account> page) {
        if (map.containsKey("parameter")) {
            map.put("parameter", map.get("parameter").toString().replace(" ", ""));
        }
        return Optional.ofNullable(baseMapper.findpage(map, page)).map(account -> {
            return page.setRecords(account);
        }).orElseThrow(() -> new BizException("暂时没数据"));
    }

    /**
     * 用id查询当前账户详细信息 后台
     *
     * @param accountId
     * @return
     */
    @Override
    public AccountDetailDTO findAccount(Long accountId) {
        return Optional.ofNullable(this.selectOne(new EntityWrapper<Account>().eq("id", accountId))).map(account -> {
            Customer customer = customerService.selectById(account.getCustomerId());
            return new AccountDetailDTO().setId(account.getId()).setAmount(account.getAmount()).setAvaliableAmount(account.getAvaliableAmount())
                    .setFreezeAmount(account.getFreezeAmount()).setCode(customer.getCode()).setCustomerType(customer.getCustomerType().getDesc())
                    .setName(customer.getName()).setLogoUrl(customer.getLogoUrl()).setCustomerId(customer.getId()).setStatus(account.getStatus());
        }).orElseThrow(() -> new BizException("查询条件无效，无法获取数据"));
    }

    /**
     * 用客户ID查询账户相关信息
     *
     * @return
     */
    @Override
    public AccountDetailDTO findBalanceByCustomerId() {
        Account account = this.selectOne(new EntityWrapper<Account>().eq("customer_id", CurrentUserUtils.getLogin().getCustomerId()));
        if (account != null) {
            return new AccountDetailDTO().setAvaliableAmount(account.getAvaliableAmount()).setAmount(account.getAmount()).setId(account.getId())
                    .setFreezeAmount(account.getFreezeAmount()).setStatus(account.getStatus());
        } else {
            this.createAccount(CurrentUserUtils.getLogin().getCustomerId());
            return findBalanceByCustomerId();
        }
    }

    /**
     * 创建账户
     *
     * @param customerId
     * @return
     */
    @Override
    public void createAccount(Long customerId) {
        Account account = this.selectOne(new EntityWrapper<Account>().eq("customer_id", customerId));
        if (account == null) {
            this.insert(new Account().setAccountType(AccountType.CASH_ACCOUNT)
                    .setAccountCode(ACCOUNT_CODE_PREFIX + snowFlakeIdGenerator.nextId())
                    .setCreateAt(new Date())
                    .setStatus(AccountStatus.ACTIVATE_STATUS)
                    .setCustomerId(customerId));
        }
    }
}