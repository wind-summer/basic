package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/2 上午8:44
 */
@Data
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME,include = JsonTypeInfo.As.PROPERTY,property = "group")
@JsonSubTypes({@JsonSubTypes.Type(value = BaseAttributeDTO.class),@JsonSubTypes.Type(value = BankAttributeDTO.class),@JsonSubTypes.Type(value = BizAttributeDTO.class)})
public class CustomerAttributeDTO implements Serializable{
    private String  group;
}