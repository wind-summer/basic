package com.suyun.core.module.order.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 发货记录
 * </p>
 *
 * @author caosg
 * @since 2018-03-05
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_order_shipping")
public class OrderShipping extends BaseEntity<OrderShipping> {

    private static final long serialVersionUID = 1L;

	@TableField("order_code")
	private String orderCode;
    /**
     * 发货单号
     */
	@TableField("shipping_code")
	private String shippingCode;
    /**
     * 发货时间
     */
	@TableField("shipping_time")
	private Date shippingTime;
    /**
     * 发货数量
     */
	private BigDecimal quantiy;
	@TableField("order_id")
	private Long orderId;

	@TableField(value = "create_date" ,fill = FieldFill.INSERT)
	private Date createDate;


}
