package com.suyun.core.module.bidding.service.dto;

import com.suyun.core.module.bidding.entity.BiddingRule;
import com.suyun.core.module.bidding.enums.BiddingRecordStatus;
import com.suyun.core.module.bidding.enums.BiddingStatus;
import com.suyun.core.module.order.enums.YesOrNo;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author wlf
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/27 下午2:32
 */
@Data
@Accessors(chain = true)
public class BiddingProductDTO {
    /**
     * 竞价产品ID
     */
    private Long id;
    /**
     * 产品ID
     */
    private Long productId;
    /**
     * 规则ID
     */
    private Long biddingRuleId;
    /**
     * skuID
     */
    private Long skuId;
    /**
     * sku编码
     */
    private String skuCode;/**
     * 产品名称
     */
    private String productName;
    /**
     * 类别名称
     */
    private String categoryName;
    /**
     * 规格/牌号 编码
     */
    private String gradeCode;
    /**
     * 产地编码
     */
    private String manufacturerCode;
    /**
     * 仓库编码
     */
    private String warehouseCode;
    /**
     * 单位编码
     */
    private String unitCode;
    /**
     * 数量
     */
    private Long quantity;
    /**
     * 最小跳量
     */
    private Long minJumpQuantity;
    /**
     * 起拍数量
     */
    private Long startQuantity;
    /**
     * 起拍单价
     */
    private BigDecimal startUnitPrice;
    /**
     * 最大竞拍价格
     */
    private BigDecimal maxBiddingPrice;
    /**
     * 最小竞拍价格
     */
    private BigDecimal minBiddingPrice;
    /**
     * 竞价次数
     */
    private Integer biddingCount;
    /**
     * 总竞价数量
     */
    private Long allBiddingQuantity;
    /**
     * 总成交数量
     */
    private Long allDealQuantity;
    /**
     * 开始日期
     */
    private Date startDate;
    /**
     * 结束日期
     */
    private Date endDate;
    /**
     * 产品ID
     */
    private BiddingStatus biddingStatus;
    /**
     * 产品ID
     */
    private BiddingRule biddingRule;
    /**
     * 围观次数
     */
    private Double onlookers;

    /**
     * 联系人姓名
     */
    private String contactName;

    /**
     * 联系人电话
     */
    private String contactPhone;

    /**
     * 库存
     */
    private BigDecimal stock;

    /**
     * 产品价格
     */
    private BigDecimal productPrice;

    /**
     *  报名人数
     */
    private Integer signUpCount;

    /**
     *  服务器当前时间
     */
    private Date nowDate;
}
