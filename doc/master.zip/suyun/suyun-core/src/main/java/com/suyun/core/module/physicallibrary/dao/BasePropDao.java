package com.suyun.core.module.physicallibrary.dao;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.physicallibrary.entity.BaseProp;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.physicallibrary.service.dto.BaseProductDTO;
import com.suyun.core.module.physicallibrary.service.dto.BaseProductDetailDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 产品主表 Mapper 接口
 * </p>
 *
 * @author zjq
 * @since 2018-01-12
 */
public interface BasePropDao extends BaseMapper<BaseProp> {

    /**
     *
     * @param map
     * @param page
     * @return
     */
    List<BaseProductDTO> selectBaseProductByCondition(Map<String, Object> map, Page<BaseProductDTO> page);

    /**
     * 查询产品详细信息
     *
     * @param productId
     * @return
     */
    BaseProductDetailDTO findBaseProductDetailByProductId(@Param("productId") String productId);

}
