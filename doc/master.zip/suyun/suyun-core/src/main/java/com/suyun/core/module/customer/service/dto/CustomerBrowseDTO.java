package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 企业浏览
 *
 * @author luyang
 * @date 2018年1月4日 19:54:21
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerBrowseDTO implements Serializable {
    //点击量
    private int browse;
    //排名
    private int rank;
    //客户信息
    private Customer customer;
}