package com.suyun.core.module.order.service;

import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.order.entity.OrderAttribute;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
public interface OrderAttributeService extends IService<OrderAttribute> {

}
