package com.suyun.core.module.account.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.annotations.Version;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.account.enums.AccountStatus;
import com.suyun.core.module.account.enums.AccountType;
import com.suyun.core.module.customer.service.dto.BankAttributeDTO;
import com.suyun.core.sys.entity.BaseEntity;
import com.suyun.core.sys.service.dto.PlatformBankDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * <p>
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_account")
public class Account extends BaseEntity<Account> {

    private static final long serialVersionUID = 1L;

    @TableField("account_code")
    private String accountCode;
    /**
     * 账户类型
     * 0：现金账户
     * 1 :  优惠券账户
     */
    @TableField("account_type")
    private AccountType accountType;
    /**
     * 总额
     */
    @TableField("amount")
    private BigDecimal amount = new BigDecimal(0);
    /**
     * 冻结金额
     */
    @TableField("freeze_amount")
    private BigDecimal freezeAmount = new BigDecimal(0);
    /**
     * 可用金额
     */
    @TableField("avaliable_amount")
    private BigDecimal avaliableAmount = new BigDecimal(0);
    /**
     * 0: 已激活
     * 1：冻结
     * 2：作废
     */
    private AccountStatus status;
    /**
     * 创建日期
     */
    @TableField(value = "create_at", fill = FieldFill.INSERT)
    private Date createAt;
    /**
     * 修改日期
     */
    @TableField(value = "update_at", fill = FieldFill.UPDATE)
    private Date updateAt;
    /**
     * 客户ID
     */
    @TableField("customer_id")
    private Long customerId;
    /**
     * 扩展信息属性
     */
    private String attributes;
    /**
     * 有效起始日期
     */
    @TableField("from_time")
    private Date fromTime;
    /**
     * 有效终止日期
     */
    @TableField("end_time")
    private Date endTime;

    /**
     * 账户名称
     */
    @TableField(exist = false)
    private String name;

    /**
     * 账户类型
     */
    @TableField(exist = false)
    private String roleName;

    @Version
    @TableField("version")
    private Integer version;

    /**
     * 客户电话号码
     */
    @TableField(exist = false)
    private String phone;

    /**
     * 付款识别码
     */
    @TableField(exist = false)
    private String payment;

    /**
     * 银行账户信息
     */
    @TableField(exist = false)
    private PlatformBankDTO dto;

    /**
     * 客户银行信息
     */
    @TableField(exist = false)
    private BankAttributeDTO customerdto;

    /**
     * 账户编码
     */
    @TableField(exist = false)
    private String code;

}
