package com.suyun.core.module.order.statemachine.guard;

import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.enums.PaymentMethod;
import com.suyun.core.module.order.service.OrderConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.guard.Guard;
import org.springframework.stereotype.Component;

/**
 * @author caosg
 * @version V1.0
 * @Description: 检测订单支付方式，以决定执行后续订单流程
 * @date 2017/12/11 下午6:54
 */
@Component
@Slf4j
public class PaymentGuard implements Guard<OrderStatus,OrderEvent>{

    @Override
    public boolean evaluate(StateContext<OrderStatus, OrderEvent> stateContext) {
        log.info("Pay Guard evaluate from {} to {} " ,stateContext.getSource().getId(),stateContext.getTarget().getId());
        Message<OrderEvent> message = stateContext.getMessage();
        if (message != null && message.getHeaders().containsKey(OrderConstant.EVENT_MESSAGE_HEADER_KEY)) {
            Order order = message.getHeaders().get("order", Order.class);
            return order.getPaymentMethod()== PaymentMethod.PRE_PAY;
        }
        return false;
    }
}
