package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 订单状态
 * @author caosg
 * @Date 2017-12-04
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum OrderStatus  implements IEnum {

    INIT(0,"初始化"),
    AWAITING_AUDIT(1,"待审核"),
    AWAITING_CONFIRM(2,"待确认"),
    AWAITING_PAYMENT(3,"待支付"),
    AWAITING_DELIVERY(4,"待发货"),
    AWAITING_RECEIVE(5,"待收货"),
    COMPLETED(6,"已签收"),
    CANCELED(7,"已取消");

    private Integer value;
    private String desc;

    OrderStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }


    @Override
    public String toString() {
        return "OrderStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
