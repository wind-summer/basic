package com.suyun.core.junziqian;

import com.junziqian.api.JunziqianClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author caosg
 * @version V1.0
 * @Description: 君子签客户端配置类
 * @date 2018/2/7 下午2:38
 */
@Configuration
public class JunZiQianConfig {
    @Bean
    public JunziqianClient junziqianClient(JunziQianProperties junziQianProperties){
        return
                new JunziqianClient(junziQianProperties.getServiceUrl(),
                        junziQianProperties.getAppKey(),junziQianProperties.getAppSecret());
    }
}
