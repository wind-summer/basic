package com.suyun.core.module.customer.enums;

import com.baomidou.mybatisplus.enums.IEnum;

import java.io.Serializable;

/**
 * <p>
 *     定义客户类型
 * </p>
 * @author csg
 * @date 2017-12-01
 */


public enum CustomerTypeEnum  implements IEnum {

    CUSTOMER(1,"客户"),
    EXPERT(2,"专家"),
    CUSTOMER_EMPLOYEE(3,"员工");

    private long value;
    private String desc;

    CustomerTypeEnum(final long value, final String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Serializable getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
