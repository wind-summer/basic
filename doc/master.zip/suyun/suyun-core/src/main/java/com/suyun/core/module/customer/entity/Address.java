package com.suyun.core.module.customer.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Email;

import javax.validation.constraints.Pattern;

/**
 * <p>
 * 地址
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_address")
public class Address extends BaseEntity<Address> {

    private static final long serialVersionUID = 1L;

    /**
     * 用户名称
     */
	@TableField("user_name")
	private String userName;
    /**
     * 省代码
     */
	private Long province;
	private String provinceName;
    /**
     * 城市代码
     */
	private Long city;
	private String cityName;
    /**
     * 区县代码
     */
	private Long area;
	private String areaName;
    /**
     * 详细地址
     */
	private String address;
	/**
	 * Email
	 */
	@TableField("email_address")
	@Email
	private String emailAddress;
	private String address2;
    /**
     * 主联系电话
     */
	@TableField("primary_phone")
	@Pattern(regexp = "^[1][3,4,5,7,8][0-9]{9}$")
	private String primaryPhone;
    /**
     * 公司名称
     */
	@TableField("company_name")
	private String companyName;

}
