package com.suyun.core.module.open.dao;

import com.suyun.core.module.open.entity.ApiClient;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
public interface ApiClientDao extends BaseMapper<ApiClient> {

}
