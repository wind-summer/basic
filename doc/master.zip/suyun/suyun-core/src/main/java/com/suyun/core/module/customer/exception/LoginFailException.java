package com.suyun.core.module.customer.exception;

import com.suyun.common.exception.BizException;

/**
 * @author caosg
 * @Description: 登陆失败异常
 * @date 2017/12/1 下午1:59
 */
public class LoginFailException extends BizException{

    public LoginFailException() {
        super("账号或密码错误",400);
    }

    public LoginFailException(String msg) {
        super(msg,400);
    }
}
