package com.suyun.core.module.customer.service;

import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.entity.CustomerAddress;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerAddressService extends IService<CustomerAddress> {

    /**
     * 获取客户默认地址
     * @param customerId
     * @return
     */
    Address getDefaultAddressByCustomerId(Long customerId);

}
