package com.suyun.core.module.order.service.dto;

import com.suyun.core.module.order.enums.PaymentMethod;
import com.suyun.core.module.order.enums.ShippingMethod;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * 发送给浪潮ERP数据
 */
@Data
@Accessors(chain = true)
public class OrderPushDTO {

    /*
    订单ID,塑云电商唯一标识
     */
    private String orderCode;
    /*
    客户编号，浪潮客户编码
     */
    private String customerId;
    /*
    商品编码，浪潮系统产品唯一标识
     */
    private String productCode;
    /*
    数量
     */
    private BigDecimal quantity;
    /*
    价格
     */
//    private BigDecimal retailPrice;
    /*
    配送方式
     */
    private String shippingMethod;
    /*
    付款方式
     */
    private String paymentMethod;
    /**
     * 公司
     */
    private String companyCode;
    /*
    收货人
     */
//    private String userName;
    /*
    联系电话
     */
//    private String primaryPhone;
    /**
    收货地址
    */
//    private String address;
    /*
    仓库编码
     */
//    private String warehouseCode;

    /*
     联系人
     */
    private String linkMan;

    /*
    联系电话
     */
    private String linkPhoneNo;

    /*
     收货地址
     */
    private String linkAddress;
    /*
    仓库编码
     */
    private String wareHousesId;

    /**
     * 价格
     */
    private BigDecimal price;

}
