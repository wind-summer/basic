package com.suyun.core.module.customer.enums;

import com.baomidou.mybatisplus.enums.IEnum;

import java.io.Serializable;

/**
 * 认证类型
 */
public enum IdentificationTypeEnum implements IEnum {

    IDENTIFICATION_TYPE_TRADITIONAL(0,"传统三证"),
    IDENTIFICATION_TYPE_ALLINONE(1,"多证合一");

    private int value;
    private String desc;

    IdentificationTypeEnum(final int value, final String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Serializable getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
