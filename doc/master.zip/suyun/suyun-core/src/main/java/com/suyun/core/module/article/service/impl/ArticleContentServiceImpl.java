package com.suyun.core.module.article.service.impl;

import com.suyun.core.module.article.entity.ArticleContent;
import com.suyun.core.module.article.dao.ArticleContentDao;
import com.suyun.core.module.article.service.ArticleContentService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 文章详细内容 服务实现类
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
@Service
public class ArticleContentServiceImpl extends ServiceImpl<ArticleContentDao, ArticleContent> implements ArticleContentService {

}
