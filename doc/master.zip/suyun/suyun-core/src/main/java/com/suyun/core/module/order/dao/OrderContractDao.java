package com.suyun.core.module.order.dao;

import com.suyun.core.module.order.entity.OrderContract;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 订单销售合同 Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2018-02-08
 */
public interface OrderContractDao extends BaseMapper<OrderContract> {

}
