package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.order.dao.OrderEventDao;
import com.suyun.core.module.order.entity.OrderEvent;
import com.suyun.core.module.order.service.OrderEventService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Service
public class OrderEventServiceImpl extends ServiceImpl<OrderEventDao, OrderEvent> implements OrderEventService {

}
