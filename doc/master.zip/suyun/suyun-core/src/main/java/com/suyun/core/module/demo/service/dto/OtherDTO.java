package com.suyun.core.module.demo.service.dto;

import com.suyun.core.sys.service.dto.BaseDTO;
import lombok.Data;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/11/30 上午9:36
 */
@Data
public class OtherDTO extends BaseDTO{
    private Integer number;
    private String  remark;
}
