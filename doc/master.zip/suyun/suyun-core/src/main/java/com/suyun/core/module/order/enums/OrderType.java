package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 订单类型
 * @author csg
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum OrderType implements IEnum {

    SALE("0","销售订单"),
    BIDDING("1","竞价订单");

    private String value;
    private String desc;

    OrderType(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
