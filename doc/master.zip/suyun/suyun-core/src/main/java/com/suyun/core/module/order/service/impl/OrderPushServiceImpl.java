package com.suyun.core.module.order.service.impl;

import com.alibaba.druid.support.json.JSONUtils;
import com.suyun.core.config.LangChaoProperties;
import com.suyun.core.module.order.entity.OrderPush;
import com.suyun.core.module.order.dao.OrderPushDao;
import com.suyun.core.module.order.enums.PaymentMethod;
import com.suyun.core.module.order.enums.PushStatus;
import com.suyun.core.module.order.enums.ShippingMethod;
import com.suyun.core.module.order.service.OrderPushService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.order.service.OrderService;
import com.suyun.core.module.order.service.dto.OrderDTO;
import com.suyun.core.module.order.service.dto.OrderPushDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONUtil;
import net.sf.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  推送浪潮ERP
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
@Service
@Slf4j
@AllArgsConstructor
public class OrderPushServiceImpl extends ServiceImpl<OrderPushDao, OrderPush> implements OrderPushService {

    private final OrderService orderService;

    private final RestTemplate restTemplate;

    private final OrderPushDao orderPushDao;

    private final LangChaoProperties langChaoProperties;

    @Override
    public void pushOrderByOrderId(Long orderId) {
        OrderDTO orderDTO = orderService.getOrderById(orderId);
        List<OrderPush> orderPshList = orderPushDao.queryOrderPushByorderId(orderId, PushStatus.STATUS_SUCCESS.getValue());
        if(null!= orderPshList && orderPshList.size()!=0){
            return;
        }
        //获取数据
        OrderPushDTO orderPushDTO = this.getOrderPush(orderDTO);
        //发送浪潮ERP
        OrderPush orderPush = new OrderPush();
        log.info("-------------------orderPushDTO:"+ JSONObject.fromObject(orderPushDTO).toString());
        try {
            //调用浪潮ERP接口\
            Map<String ,Object> postData = new HashMap<String ,Object>();
            postData.put("data", JSONObject.fromObject(orderPushDTO).toString());
//            postData.put("data", JSONUtils.toJSONString(orderPushDTO));
//            JSONObject json = restTemplate.postForEntity(langChaoProperties.getServiceUrl(),postData, JSONObject.class).getBody();
            log.info("准备请求浪潮erp,地址为：",langChaoProperties.getServiceUrl());
            HttpHeaders headers = new HttpHeaders();
            MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
            headers.setContentType(type);
            headers.add("Accept", MediaType.APPLICATION_JSON.toString());
            JSONObject jsonObj = JSONObject.fromObject(JSONObject.fromObject(orderPushDTO).toString());
            HttpEntity<String> formEntity = new HttpEntity<String>(jsonObj.toString(), headers);
            String result = restTemplate.postForObject(langChaoProperties.getServiceUrl(), formEntity, String.class);
            JSONObject resultJson = JSONObject.fromObject(result);
            log.info("浪潮erp返回结果",result);
            //浪潮ERP 返回结果
            String flag = resultJson.get("flag").toString();
            //浪潮ERP 错误信息
            String msg = resultJson.get("Message").toString();
            orderPush.setOrderId(orderId);
            if (flag.equals(String.valueOf(PushStatus.STATUS_SUCCESS.getValue()))) {
                orderPush.setStatus(PushStatus.STATUS_SUCCESS.getValue());
            } else {
                orderPush.setStatus(PushStatus.STATUS_FAIL.getValue());
            }
            orderPush.setRemark(msg);
        }catch (Exception e){
            e.printStackTrace();
            log.error("pushOrderByOrderId:[orderId:"+orderId+"]推送浪潮ERP异常："+e.getMessage());
            orderPush.setStatus(PushStatus.STATUS_FAIL.getValue());
            orderPush.setRemark("推送浪潮ERP异常："+e.getMessage());
            orderPush.setOrderId(orderId);//异常时，id不能正确存储
        }
        orderPushDao.insert(orderPush);
        log.info("----推送浪潮ERP END--[ORDERID："+orderId+"]----");
    }

    /**
     * 获取递送到浪潮ERP数据
     * @param orderDTO
     * @return
     */
    private OrderPushDTO getOrderPush(OrderDTO orderDTO){
        OrderPushDTO orderPushDTO = new OrderPushDTO();
        //订单ID,塑云电商唯一标识
        orderPushDTO.setOrderCode(orderDTO.getOrder().getOrderCode());
        //客户编号，浪潮客户编码
        orderPushDTO.setCustomerId(orderDTO.getOrder().getReserveAttribute1());
        //商品编码，浪潮系统产品唯一标识
        orderPushDTO.setProductCode(orderDTO.getOrder().getItems().get(0).getSku().getProduct().getErpCode());
        //数量
        orderPushDTO.setQuantity(orderDTO.getOrder().getItems().get(0).getQuantity());
        //价格
        orderPushDTO.setPrice(orderDTO.getOrder().getTotal());
        //配送方式
        //orderPushDTO.setShippingMethod(orderDTO.getOrder().getShippingMethod());
        if(orderDTO.getOrder().getShippingMethod().equals(ShippingMethod.SELF)){//自提
            orderPushDTO.setShippingMethod("01");
        }else{//配送
            orderPushDTO.setShippingMethod("03");
        }
        //付款方式
        if(orderDTO.getOrder().getPaymentMethod() == PaymentMethod.PRE_PAY){//款到发货
            orderPushDTO.setPaymentMethod("2");
        }else{//货到付款
            orderPushDTO.setPaymentMethod("1");
        }
        //orderPushDTO.setPaymentMethod(orderDTO.getOrder().getPaymentMethod());
        //公司
        orderPushDTO.setCompanyCode(langChaoProperties.getCompanyCode());
        //收货人
        orderPushDTO.setLinkMan(orderDTO.getAddress().getUserName());
        //联系电话
        orderPushDTO.setLinkPhoneNo(orderDTO.getAddress().getPrimaryPhone());
        //收货地址
        orderPushDTO.setLinkAddress(orderDTO.getAddress().getProvinceName()+orderDTO.getAddress().getCityName()+orderDTO.getAddress().getAreaName()+orderDTO.getAddress().getAddress());
        //仓库编码
        orderPushDTO.setWareHousesId(orderDTO.getOrder().getItems().get(0).getSku().getWarehouseCode());
        return orderPushDTO;
    }

    /**
     * 根据订单id查询最新的推送信息
     * 用于推送失败时再次提送的校验条件
     * @author wanggf
     * @param orderId
     * @return
     */
    public OrderPush findNewOrderPushById(Long orderId){
        return this.orderPushDao.queryNewOrderPushByOrderId(orderId);
    }
}
