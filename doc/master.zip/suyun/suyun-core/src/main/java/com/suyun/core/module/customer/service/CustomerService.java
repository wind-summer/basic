package com.suyun.core.module.customer.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.entity.CustomerAttribute;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.service.dto.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerService extends IService<Customer> {

    /**
     * 添加客户详细信息
     * @param customerDTO
     */
    Long addCustomer(CustomerDTO customerDTO);

    /**
     * 后台修改客户信息
     * @param customerDTO
     */
    Long updateCustomerByBackstage(CustomerDTO customerDTO);

    /**
     * 查询客户详情
     * @param customerId 客户ID
     * @return
     */
    CustomerDTO getCustomer(Long customerId);

    /**
     * 注册客户
     * @param registerDTO
     */
    void register(RegisterDTO registerDTO);

    /**
     * 校验当前手机号码是否存在
     * @param phone
     * @return
     */
    boolean getPhoneIsNull(String phone);

    /**
     * 校验公司名称是否重复
     * @param name
     * @return
     */
    boolean getNameIsNull(String name);

    /**
     * 校验邮箱是否重复
     * @param email
     * @return
     */
    boolean getEmailIsNull(String email,Long customerId);

    /**
     * 编辑校验公司名称是否重复
     * @param name
     * @param customerId
     * @return
     */
    boolean getNameIsNullByBackstage(String name,Long customerId);

    /**
     * 完善企业信息
     * @param customerDTO
     */
    void updateCustomer(CustomerDTO customerDTO);

    /**
     * 修改个人信息
     * @param customerLogin
     */
    void updateLoginUser(CustomerLogin customerLogin);

    /**
     * 获取最新企业
     * @param num
     * @return
     */
    List<Customer> getNewCustomer(Long num);

    /**
     * 条件查询客户信息
     * @param name
     * @param page
     * @return
     */
    Page<Customer> getCustomerByName(String name, Page<Customer> page);

    /**
     * 后台客户管理 - 查询接口
     * @param param
     * @param page
     * @return
     */
    Page<CustomerDetailDTO> getCustomerList(Map<String, Object> param, Page<CustomerDetailDTO> page);

    /**
     * 修改审批状态
     * @param customerId
     * @param status
     */
    void updateAuditStatus(Long customerId,CustomerStatusEnum status,String failReasonl);

    /**
     * 解冻
     * @param customerId
     */
    void updateAudisStatusByThaw(Long customerId);

    /**
     * 查询银行信息
     * @param customerId
     * @return
     */
    BankAttributeDTO getBank(Long customerId);

    /**
     * 需改手机号码
     * @param phone
     */
    void updatePhoneById(String phone,String verificationCode);

    /**
     * 根据客户id获取详细信息
     * @param customerId
     * @return
     */
    List<CustomerAttributeDTO> getCustomerAttributes(Long customerId);

    /**
     * 增加企业浏览数量
     * @param customerId
     */
    void addBrowse(Long customerId);

    /**
     * 获取最热企业
     * @param num
     * @return
     */
    List<CustomerBrowseDTO> getHotCustomer(int num);

    /**
     * JSON类型转换为list
     * @param customerAttribute
     * @return
     */
    List<CustomerAttributeDTO> getCustomerAttributeList(CustomerAttribute customerAttribute);

    /**
     * 统计待审客户的客户信息
     * @return
     */
    Integer getCustomerByStatus();

    /**
     * 获取客户详细信息
     * @param customerDetailDTO
     * @return
     */
    List<CustomerAttributeDTO> getAttribute(CustomerDetailDTO customerDetailDTO);

    /**
     * attributeDTOS 转换到customerDetailDTO
     * @param customerDetailDTO
     * @param attributeDTOS
     */
    void getCustomerDetailDTO(CustomerDetailDTO customerDetailDTO,List<CustomerAttributeDTO> attributeDTOS);

    /**
     * 校验营业执照是否重复
     * @param customerId
     * @param organizationRegNo
     * @return
     */
    boolean getOrganizationRegNoIsNull(Long customerId,String organizationRegNo);
}
