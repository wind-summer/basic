package com.suyun.core.module.order.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * <P>
 *     订单支付方式
 * </P>
 * @author caosg
 * @date 2-107-12-11
 *
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum PaymentMethod implements IEnum{

    PRE_PAY("0","款到发货"),
    POST_PAY("1","货到付款");

    private String value;
    private String desc;

    PaymentMethod(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
