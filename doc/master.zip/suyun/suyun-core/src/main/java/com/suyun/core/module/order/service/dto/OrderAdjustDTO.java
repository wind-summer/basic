package com.suyun.core.module.order.service.dto;

import com.suyun.core.module.order.entity.Order;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/14 下午2:32
 */
@Data
@Accessors(chain = true)
public class OrderAdjustDTO {

    private Order oldOrder;
    private Order newOrder;
}
