package com.suyun.core.module.account.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 交易类别
 *
 * @author zhangjq
 * @Date 2017-12-29
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum TransType implements IEnum {

    //表示交易类别为收入
    INCOME_TRANS(0, "账户充值"),
    //表示交易类别为支出
    PAY_TRANS(1, "账户提现"),
    //表示交易类别为调整
    ADJUSE_TRANS(2, "账户调整"),
    //表示缴纳保证金
    CASH_TRANS(3, "竞价保证金");

    private Integer value;
    private String desc;

    TransType(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return this.desc;
    }


    @Override
    public String toString() {
        return "ApplyStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
