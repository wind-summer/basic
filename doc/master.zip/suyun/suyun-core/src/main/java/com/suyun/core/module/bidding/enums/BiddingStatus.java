package com.suyun.core.module.bidding.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 竞价产品状态
 * @author wlf
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum BiddingStatus implements IEnum  {

    FINISHED(0,"已结束"),
    AWAITING_BIDDING(1,"未开始"),
    BIDDING(2,"竞价中");

    //当前登录用户已经参加过之后的状态
    /*BID_BIDDING(3,"参拍中"),
    BID_SUCCESS(4,"竞价成功"),
    BID_FAIL(5,"竞价失败");*/

    private Integer value;
    private String desc;

    BiddingStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }

    @Override
    public String toString() {
        return "BiddingStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }

}
