package com.suyun.core.module.account.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 充值申请
 *
 * @author zhangjq
 * @Date 2017-12-28
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum ApplyStatus implements IEnum {

    //表示该申请为待审核状态
    WAIT_APPLY(0, "待审核"),
    //表示该申请审核通过
    PASS_APPLY(1, "审核通过"),
    //表示该申请审核不通过
    FAIL_APPLY(2, "审核失败");

    private Integer value;
    private String desc;

    ApplyStatus(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return this.desc;
    }


    @Override
    public String toString() {
        return "ApplyStatus{" +
                "value=" + value +
                ", desc='" + desc + '\'' +
                '}';
    }
}
