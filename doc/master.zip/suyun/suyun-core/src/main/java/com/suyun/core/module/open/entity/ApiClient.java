package com.suyun.core.module.open.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sy_api_client")
public class ApiClient extends BaseEntity<ApiClient> {

    private static final long serialVersionUID = 1L;

    /**
     * 客户端ID
     */
	@TableField("client_id")
	private String clientId;
	@TableField("client_secret")
	private String clientSecret;
	@TableField("client_name")
	private String clientName;
    /**
     * 0：待审核 1：正常 2：禁用
     */
	private Integer status;
	@TableField("create_date")
	private Date createDate;

}
