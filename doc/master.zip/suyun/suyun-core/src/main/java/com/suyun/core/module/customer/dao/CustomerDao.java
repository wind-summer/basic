package com.suyun.core.module.customer.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.service.dto.CustomerDetailDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface CustomerDao extends BaseMapper<Customer> {

    /**
     * 根据手机号码查询用户是否存在
     * @param name
     * @return
     */
    List<Customer> queryCustomerByName(@Param("name")String name);

    /**
     * 根据邮箱查询邮箱是否重复
     * @param email
     * @return
     */
    List<Customer> queryCustomerByEmail(@Param("email") String email);
    /**
     * 根据营业执照查询营业执照是否重复
     * @param organizationRegNo
     * @return
     */
    List<Customer> queryCustomerByOrganizationRegNo(@Param("organizationRegNo") String organizationRegNo);

    /**
     * 获取最新企业
     * @param num
     * @return
     */
    List<Customer> getNewCustomer(@Param("num") Long num);

    /**
     * 条件查询客户信息
     * @param name
     * @param page
     * @return
     */
    List<Customer> getCustomerByName(@Param("name") String name, Page<Customer> page);

    /**
     * 后台客户管理查询LIST
     * @param param
     * @param page
     * @return
     */
    List<CustomerDetailDTO> getCustomerList(Map<String, Object> param, Page<CustomerDetailDTO> page);

    /**
     * 修改审核状态
     * @param customerId
     * @param status
     */
    void updateAuditStatus(@Param("customerId") Long customerId,@Param("status") CustomerStatusEnum status,@Param("failReasonl") String failReasonl);

    /**
     * 修改手机号
     * @param id
     * @param phone
     */
    void updatePhoneById(@Param("id")Long id,@Param("phone") String phone);

    /**
     * 统计待审核的客户数量
     * @return
     */
    Integer getCustomerByStatus(@Param("status") CustomerStatusEnum status);
}
