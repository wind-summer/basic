package com.suyun.core.module.order.service;

import com.suyun.core.module.order.entity.OrderShipping;
import com.baomidou.mybatisplus.service.IService;

import java.util.List;

/**
 * <p>
 * 发货记录 服务类
 * </p>
 *
 * @author caosg
 * @since 2018-03-05
 */
public interface OrderShippingService extends IService<OrderShipping> {

    /**
     * 根据订单编号查询发货记录
     * @param orderCode
     * @return
     */
    List<OrderShipping> getShippingsByOrderCode(String orderCode);

    /**
     * 根据订单Id查询发货记录
     * @param orderId
     * @return
     */
    List<OrderShipping> getShippingsByOrderId(Long orderId);

}
