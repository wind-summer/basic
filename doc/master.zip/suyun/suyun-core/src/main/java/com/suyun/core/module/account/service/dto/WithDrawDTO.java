package com.suyun.core.module.account.service.dto;

import com.suyun.core.module.customer.service.dto.BankAttributeDTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * @author zhangjq
 */
@Data
@Accessors(chain = true)
public class WithDrawDTO {

    /**
     * 账户id
     */
    private Long id;

    /**
     * 账户总额
     */
    private BigDecimal amount;

    /**
     * 客户手机号
     */
    private String phone;


    /**
     * 可用余额
     */
    private BigDecimal avaliableAmount;

    /**
     * 客户银行信息
     */
    private BankAttributeDTO customerBank;

}
