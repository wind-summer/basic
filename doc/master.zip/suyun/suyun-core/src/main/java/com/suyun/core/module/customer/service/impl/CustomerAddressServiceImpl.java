package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.customer.dao.AddressDao;
import com.suyun.core.module.customer.dao.CustomerAddressDao;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.entity.CustomerAddress;
import com.suyun.core.module.customer.service.CustomerAddressService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
@AllArgsConstructor
public class CustomerAddressServiceImpl extends ServiceImpl<CustomerAddressDao, CustomerAddress> implements CustomerAddressService {

    private final AddressDao addressDao;

    /**
     * 获取客户默认地址
     *
     * @param customerId
     * @return
     */
    @Override
    public Address getDefaultAddressByCustomerId(Long customerId) {
        return Optional.ofNullable(this.selectOne(new EntityWrapper<CustomerAddress>().eq("is_default",true).eq("customer_id",customerId)))
                .map(customerAddress -> addressDao.selectById(customerAddress.getAddressId()))
                .orElse(null);
    }
}
