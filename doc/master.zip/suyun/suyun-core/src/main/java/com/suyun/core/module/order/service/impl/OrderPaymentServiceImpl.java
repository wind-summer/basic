package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.order.dao.OrderPaymentDao;
import com.suyun.core.module.order.entity.OrderPayment;
import com.suyun.core.module.order.service.OrderPaymentService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Service
public class OrderPaymentServiceImpl extends ServiceImpl<OrderPaymentDao, OrderPayment> implements OrderPaymentService {

}
