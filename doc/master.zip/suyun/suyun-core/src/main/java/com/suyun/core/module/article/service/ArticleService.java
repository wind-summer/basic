package com.suyun.core.module.article.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.article.entity.Article;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
public interface ArticleService extends IService<Article> {
    /**
     * 添加文章
     * @param article
     */
    void addArticle(Article article);

    /**
     * 修改文章
     * @param article
     */
    void editArticle(Article article);

    /**
     * 根据文章id查询文章内容
     * @param articleId
     * @return
     */
    Article findArticleByid(Long articleId);

    /**
     * 查询文章列表
     * @param param
     * @param page
     * @return
     */
    Page<Article> queryArticle(Map<String, Object> param,Page<Article> page);

    /**
     * 删除文章
     * @param articleId
     */
    void deleteById(Long articleId);

    /**
     * 上线文章
     * @param articleId
     */
    void downLineById(Long articleId);

    /**
     * 下线文章
     * @param articleId
     */
    void upLineById(Long articleId);
}
