package com.suyun.core.module.customer.service;

import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.customer.entity.Address;

import java.util.List;

/**
 * <p>
 * 地址 服务类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
public interface AddressService extends IService<Address> {

    /**
     * 根据customerId获取收货地址
     * @return
     */
    List<Address> getAddressList();

    /**
     * 保存收货地址
     * @param address
     * @return
     */
    Address addAddress(Address address);

    /**
     * 根据id获取地址信息
     * @param addressId
     * @return
     */
    Address getAddressById(Long addressId);

    /**
     * 修改地址
     * @param address
     * @return
     */
    Address updateAddress(Address address);

    /**
     * 根据id修改为默认地址
     * @param id
     */
    void updateIsDefault(Long id);

    /**
     * 获取当前登录人默认地址
     * @return
     */
    Address getdefaultaddress();

    /**
     * 获取省市区名称
     * @param address
     * @return
     */
    Address buildAddress(Address address);
}
