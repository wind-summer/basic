package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.suyun.common.exception.BizException;
import com.suyun.common.utils.SnowFlakeIdGenerator;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.module.bidding.service.BiddingRecordService;
import com.suyun.core.module.customer.dao.AddressDao;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.BizAttributeDTO;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.module.order.dao.*;
import com.suyun.core.module.order.entity.*;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.*;
import com.suyun.core.module.order.service.*;
import com.suyun.core.module.order.service.dto.*;
import com.suyun.core.module.order.statemachine.OrderPersistStateMachineHandler;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.module.product.service.ProductService;
import com.suyun.core.sys.service.SysAreaService;
import com.suyun.core.utils.CurrentUserUtils;
import com.suyun.core.utils.LoginUtils;
import com.suyun.core.utils.ShiroUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * <p>
 *  订单服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Service
@AllArgsConstructor
@Slf4j
public class OrderServiceImpl extends ServiceImpl<OrderDao, Order> implements OrderService {

    private final CustomerService customerService;

    private final OrderPriceManager orderPriceManager;

    private final ProductService productService;

    private final OrderInvoiceDao orderInvoiceDao;

    private final OrderItemDao orderItemDao;

    private final SnowFlakeIdGenerator snowFlakeIdGenerator;

    private final OrderPersistStateMachineHandler persistStateMachineHandler;

    private final OrderPaymentDao orderPaymentDao;

    private final AddressDao addressDao;

    private final OrderAdjustmentDao orderAdjustmentDao;

    private final OrderEventService orderEventService;

    private final ObjectMapper objectMapper;

    private final BiddingRecordService biddingRecordService;

    private final SysAreaService sysAreaService;

    private final OrderShippingService orderShippingService;

    private final OrderPushDao orderPushDao;

    /**
     * 根据订单编号查询订单
     *
     * @param orderNo 订单编号
     * @return
     */
    @Override
    public OrderDTO getOrderByOrderNo(String orderNo) {
      return   Optional.ofNullable(this.selectOne(new EntityWrapper<Order>().eq("order_code",orderNo)))
                .map(order -> buildOrderDTO(order))
                .orElseThrow(()-> new BizException("订单:"+orderNo+"不存在"));
    }

    @Override
    public OrderDTO getOrderById(Long orderId) {
      return   Optional.ofNullable(this.selectById(orderId))
                .map(order -> buildOrderDTO(order))
                .orElseThrow(()-> new BizException("订单:"+orderId+"不存在"));
    }

    private OrderDTO buildOrderDTO(Order order){
        OrderDTO orderDTO = new OrderDTO();
        order.setItems(orderItemDao.selectList(new EntityWrapper<OrderItem>().eq("order_id",order.getId())));
        order.getItems().forEach(orderItem -> orderItem.setSku(productService.getSku(orderItem.getSkuId())));
        orderDTO.setOrder(order).setAddress(buildAddress(addressDao.selectById(order.getAddressId())));
        orderDTO.setUser(customerService.getCustomer(order.getCustomerId()).setLogin(null));
        orderDTO.setEvents(this.queryOrderLog(order.getId()));
        orderDTO.setShipping(buildShippings(order));
        if(order.getPaymentStatus().equals(YesOrNo.YES)){
           orderDTO.setPayments(orderPaymentDao.selectList(new EntityWrapper<OrderPayment>().eq("order_id",order.getId())));
        }


        orderDTO.setOrderInvoice(orderInvoiceDao.selectOne(new OrderInvoice().setOrderId(order.getId())));
        return orderDTO;
    }

    /**
     * 查询订单发货记录
     * @param order
     * @return
     */
    private ShippingDTO buildShippings(Order order){
        BigDecimal totalQuantity = order.getItems().get(0).getQuantity();
        List<OrderShipping> shippingList = orderShippingService.getShippingsByOrderId(order.getId());
        BigDecimal shippedQuantity;
        shippedQuantity = CollectionUtils.isEmpty(shippingList)?
                new BigDecimal("0") : shippingList.stream().map(orderShipping -> orderShipping.getQuantiy()).reduce(new BigDecimal(0),(a, b)-> a.add(b));
        ShippingDTO shippingDTO = new ShippingDTO();
        shippingDTO.setShippedQuantity(shippedQuantity);
        shippingDTO.setNoQuantity(totalQuantity.subtract(shippedQuantity));
        shippingDTO.setRecords(shippingList);
        return shippingDTO;
    }
    private Address  buildAddress(Address address) {
        if(address==null) {
            return address;
        }
        if(address.getProvince()!=null&& StringUtils.isEmpty(address.getProvinceName())) {
            address.setProvinceName(sysAreaService.findById(address.getProvince()).getName());
        }
        if(address.getCity()!=null&& StringUtils.isEmpty(address.getCityName())) {
            address.setCityName(sysAreaService.findById(address.getCity()).getName());
        }
        if(address.getArea()!=null&& StringUtils.isEmpty(address.getAreaName())) {
            address.setAreaName(sysAreaService.findById(address.getArea()).getName());
        }
        return address;
    }

    /**
     * 客户下单
     *
     * @param order
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Order createOrder(Order order) {
        ValidatorUtils.validateEntity(order);
        //客户信息
        CustomerDTO customer = customerService.getCustomer(CurrentUserUtils.getLogin().getCustomerId());
        if(customer.getCustomer().getStatus()!= CustomerStatusEnum.SUCCESS){
            throw new BizException("客户您还没认证，暂不允许下单");
        }
        //构造订单默认属性信息
        order.setCustomerId(customer.getCustomer().getId()).setOrderCode(OrderConstant.ORDER_CODE_PREFIX+ snowFlakeIdGenerator.nextId())
                .setOrderStatus(OrderStatus.AWAITING_AUDIT).setCreateBy(LoginUtils.getLoginName());
        order.setReserveAttribute2(RandomStringUtils.randomNumeric(6));
        log.debug("order info :{}",order);
        //构造订单明细信息
        order.getItems().forEach(orderItem -> {
            Sku sku = productService.getSku(orderItem.getSkuId());
            log.debug("sku info:{}",sku.getSalePrice());
            orderItem.setName(sku.getProduct().getName()).setGradeCode(sku.getProduct().getGradeCode())
                    .setItemType(OrderItemType.SALE).setProductId(sku.getProductId())
                    .setPrice(sku.getMarketPrice()).setSalePrice(sku.getSalePrice());
            //非竞拍订单以商品原始价格为主，竞价订单以竞价为主
            if(order.getOrderType()==OrderType.SALE) {
                orderItem.setRetailPrice(sku.getSalePrice());
            }
        });
        //计算订单价格
        orderPriceManager.calculateOrderPrice(order);
        //保存订单
        this.insert(order);
        //保存订单明细
        this.createItems(order);
        //保存发票信息
        this.createInvoice(order,customer);
        //启动订单状态机
        this.sendCreateEvent(order);
        return order;
    }

    /**
     * 编辑订单,只允许编辑产品数量、价格、支付方式
     *
     * @param adjustParamDTO
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Order editOrder(AdjustParamDTO adjustParamDTO) {

      return   Optional.ofNullable(this.selectById(adjustParamDTO.getOrderId()))
                .map(order -> {
                    OrderPush pushEntity = this.orderPushDao.queryNewOrderPushByOrderId(adjustParamDTO.getOrderId());//获取最新推送结果
                    //订单待审核状态或者同步ERP失败状态才允许修改
                    if(order.getOrderStatus().equals(OrderStatus.AWAITING_AUDIT) || (order.getOrderStatus().equals(OrderStatus.AWAITING_DELIVERY)&& pushEntity != null && pushEntity.getStatus()==0)) {
                        boolean orderUpdated = false;
                        AtomicBoolean itemUpdated = new AtomicBoolean(false);
                        order.setItems(orderItemDao.selectList(new EntityWrapper<OrderItem>().eq("order_id",adjustParamDTO.getOrderId()))) ;
                        OrderAdjustDTO  orderAdjustDTO = new OrderAdjustDTO();
                        orderAdjustDTO.setOldOrder(order);
                        if(adjustParamDTO.getPaymentMethod()!=order.getPaymentMethod()) {
                            order.setPaymentMethod(adjustParamDTO.getPaymentMethod());
                            orderUpdated = true;
                        }
                        if(StringUtils.isNotEmpty(adjustParamDTO.getExtCustomerCode())){
                            order.setReserveAttribute1(adjustParamDTO.getExtCustomerCode());
                        }
                        order.getItems().forEach(orderItem -> adjustParamDTO.getItems().forEach(itemAdjust->{
                            if(orderItem.getId().equals(itemAdjust.getItemId())) {
                                if (!orderItem.getRetailPrice().equals(itemAdjust.getPrice()) || !orderItem.getQuantity().equals(itemAdjust.getQuantity())) {
                                    orderItem.setRetailPrice(itemAdjust.getPrice());
                                    orderItem.setQuantity(itemAdjust.getQuantity());
                                    itemUpdated.set(true);
                                }
                            }
                        }));
                        if(itemUpdated.get()){
                            //重新计算订单价格
                            orderPriceManager.calculateOrderPrice(order);
                            order.getItems().forEach(orderItem -> orderItemDao.updateById(orderItem));
                        }
                        if(orderUpdated||itemUpdated.get()) {
                            this.updateById(order);
                        }
                        // 保存订单调整记录
                        orderAdjustDTO.setNewOrder(order);
                        OrderAdjustment orderAdjustment = new OrderAdjustment();
                        orderAdjustment.setOrderId(adjustParamDTO.getOrderId()).setAdjustDetail(orderAdjustDTO).setCreateBy(ShiroUtils.getUserEntity().getUsername());
                        orderAdjustmentDao.insert(orderAdjustment);
                        return orderAdjustDTO.getNewOrder();
                    }else{
                        throw new BizException("待审核订单才允许编辑");
                    }
//                    boolean orderUpdated = false;
//                    AtomicBoolean itemUpdated = new AtomicBoolean(false);
//                    order.setItems(orderItemDao.selectList(new EntityWrapper<OrderItem>().eq("order_id",adjustParamDTO.getOrderId()))) ;
//                    OrderAdjustDTO  orderAdjustDTO = new OrderAdjustDTO();
//                    orderAdjustDTO.setOldOrder(order);
//                    if(adjustParamDTO.getPaymentMethod()!=order.getPaymentMethod()) {
//                       order.setPaymentMethod(adjustParamDTO.getPaymentMethod());
//                       orderUpdated = true;
//                    }
//                    if(StringUtils.isNotEmpty(adjustParamDTO.getExtCustomerCode())){
//                        order.setReserveAttribute1(adjustParamDTO.getExtCustomerCode());
//                    }
//                    order.getItems().forEach(orderItem -> adjustParamDTO.getItems().forEach(itemAdjust->{
//                        if(orderItem.getId().equals(itemAdjust.getItemId())) {
//                            if (!orderItem.getRetailPrice().equals(itemAdjust.getPrice()) || !orderItem.getQuantity().equals(itemAdjust.getQuantity())) {
//                                orderItem.setRetailPrice(itemAdjust.getPrice());
//                                orderItem.setQuantity(itemAdjust.getQuantity());
//                                itemUpdated.set(true);
//                            }
//                        }
//
//                    }));
//                    if(itemUpdated.get()){
//                        //重新计算订单价格
//                        orderPriceManager.calculateOrderPrice(order);
//                        order.getItems().forEach(orderItem -> orderItemDao.updateById(orderItem));
//                    }
//                    if(orderUpdated||itemUpdated.get()) {
//                        this.updateById(order);
//                    }
//                    // 保存订单调整记录
//                    orderAdjustDTO.setNewOrder(order);
//                    OrderAdjustment orderAdjustment = new OrderAdjustment();
//                    orderAdjustment.setOrderId(adjustParamDTO.getOrderId()).setAdjustDetail(orderAdjustDTO).setCreateBy(ShiroUtils.getUserEntity().getUsername());
//                    orderAdjustmentDao.insert(orderAdjustment);
//                    return orderAdjustDTO.getNewOrder();
                })
                .orElseThrow(()-> new BizException("订单:"+adjustParamDTO.getOrderId()+"不存在"));
    }


    private boolean sendCreateEvent(Order order){
       boolean result = persistStateMachineHandler.handleEventWithState(
                MessageBuilder.withPayload(OrderEvent.CREATE).setHeader(OrderConstant.EVENT_MESSAGE_HEADER_KEY, order).build(),OrderStatus.INIT);
       if(!result) {
           throw new BizException("订单生成失败");
       }
       return result;
    }


    /**
     * 接收订单事件
     *
     * @param orderId
     * @param orderEvent
     * @param isOwner
     * @param extParams
     * @return
     */
    @Override
    public boolean handleEvent(Long orderId, OrderEvent orderEvent,boolean isOwner, Object... extParams) {
        log.debug("Receive  order:{} event:{} ",orderId,orderEvent);
        return   Optional.ofNullable(this.getOrderById(orderId))
                .map(orderDTO -> {
                    Order order = orderDTO.getOrder();
                    order.setCustomer(orderDTO.getUser().getCustomer());
                    if(isOwner) {
                        //判断该订单是否属于当前登陆用户
                        isLoginUserOrder(order);
                        if(order.getOrderType()==OrderType.BIDDING&& orderEvent== OrderEvent.CANCEL){
                            throw new BizException("竞价订单不允许取消");
                        }
                    }
                    MessageBuilder messageBuilder = MessageBuilder.withPayload(orderEvent)
                            .setHeader(OrderConstant.EVENT_MESSAGE_HEADER_KEY, order);
                    if(extParams.length>0&& extParams[0].equals("manulCancel")){
                        messageBuilder.setHeader(OrderConstant.MANUAL_CANCEL_ORDER_FLAG,true);
                    }
                    if(extParams.length>0&& extParams[0].equals("autoCancel")){
                        messageBuilder.setHeader(OrderConstant.MANUAL_CANCEL_ORDER_FLAG,false);
                    }
                    boolean result = persistStateMachineHandler.handleEventWithState(
                                    messageBuilder.build(), order.getOrderStatus());
                    //如果是竞价订单,支付确认后通知竞价释放保证金
                    if(result && orderEvent==OrderEvent.PAYMENT && order.getOrderType()==OrderType.BIDDING){
                        //todo
                        biddingRecordService.returnBiddingRecord(order.getOrderCode());
                        log.info("通知竞价模块，完成支付，orderId:{}",order.getId());
                    }
                    return result;
                })
                .orElseThrow(()-> new BizException("订单:"+orderId+"不存在"));
    }

    /**
     * 前端用户查询我的订单
     *
     * @return
     */
    @Override
    public Page<Order> queryMyOrder(Page<Order> page,String orderCode) {
      EntityWrapper<Order> entityWrapper = new EntityWrapper<>();
      entityWrapper.eq("customer_id",CurrentUserUtils.getLogin().getCustomerId());
      if(!StringUtils.isEmpty(orderCode)){
          entityWrapper.like("order_code",orderCode);
      }
      entityWrapper.orderBy("create_date",false);
      Page<Order> orderPage =   this.selectPage(page,entityWrapper);
      orderPage.getRecords().forEach(order ->
              order.setItems(orderItemDao.selectList(new EntityWrapper<OrderItem>().eq("order_id",order.getId()))));
      return orderPage;
    }

    @Override
    public Page<Order> queryOrder(Map<String, Object> params, Page<Order> page) {
        List<Order> orders = baseMapper.queryAllOrder(params,page);
        orders.forEach(order -> order.setItems(orderItemDao.selectList(new EntityWrapper<OrderItem>().eq("order_id",order.getId()))));
        orders.forEach(order -> order.setOrderPush(orderPushDao.queryNewOrderPushByOrderId(order.getId())));
        return page.setRecords(orders);
    }

    /**
     * 上传支付凭证
     *
     * @param orderId
     * @param voucherDTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addPayment(Long orderId,PayVoucherDTO voucherDTO) {
        OrderPayment payment = new OrderPayment();
        Optional.ofNullable(this.selectById(orderId))
                .map(order -> {
                    if(order.getPaymentStatus()==YesOrNo.YES){
                        throw new BizException("订单["+order.getOrderCode()+"]已经付款了。");
                    }
                    if(order.getOrderStatus()==OrderStatus.CANCELED){
                        throw new BizException("订单["+order.getOrderCode()+"]已经取消。");
                    }
                    try {
                        //判断该订单是否属于当前登陆用户
                        isLoginUserOrder(order);
                        voucherDTO.setMarkCode(order.getReserveAttribute2());
                        payment.setOrderId(orderId).setCustomerId(CurrentUserUtils.getLogin().getCustomerId())
                                .setAmount(order.getTotal())
                                .setPaymentInfo(objectMapper.writeValueAsString(voucherDTO)).setPaymentType(PayType.TRANSFER);
                    } catch (JsonProcessingException e) {
                        log.error("Json parse error:{}",e.getMessage());
                    }
                    this.updateById(order.setPaymentStatus(YesOrNo.YES));
                    return orderPaymentDao.insert(payment);
                })
                .orElseThrow(()-> new BizException("订单:"+orderId+"不存在"));

    }

    @Override
    public List<com.suyun.core.module.order.entity.OrderEvent> queryOrderLog(Long orderId) {
        return orderEventService.selectList(new EntityWrapper<com.suyun.core.module.order.entity.OrderEvent>().eq("order_id",orderId) );
    }

    @Override
    public List<CustomerOrderDashboardDTO> getMyOrderDashboard() {
        List<CustomerOrderDashboardDTO> result = new ArrayList<>();
        LocalDateTime today = LocalDate.now().atStartOfDay();
        //本月的第一天零点零分零秒
        LocalDateTime firstDayOfMonth = LocalDateTime.of(today.getYear(),today.getMonth(),1,0,0,0);
        //本周的第一天
        LocalDateTime firstDayOfWeek = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        EntityWrapper<Order> entityWrapper = new EntityWrapper<>();
        entityWrapper.where("customer_id={0}",CurrentUserUtils.getLogin().getCustomerId())
                .between("create_date",firstDayOfMonth,LocalDateTime.now());
        List<Order> ordersOfMonth = baseMapper.selectList(entityWrapper);
        List<Order> ordersOfWeek = ordersOfMonth.stream()
                .filter(order -> LocalDateTime.ofInstant(order.getCreateDate().toInstant(), ZoneId.systemDefault()).isAfter(firstDayOfWeek))
                .collect(Collectors.toList());
        List<Order> ordersOfDay = ordersOfWeek.stream()
                .filter(order -> LocalDateTime.ofInstant(order.getCreateDate().toInstant(), ZoneId.systemDefault()).isAfter(today))
                .collect(Collectors.toList());
        //统计本天
        CustomerOrderDashboardDTO dayDashboardDTO = new CustomerOrderDashboardDTO();
        dayDashboardDTO.setGroup("day").setOrderCount(ordersOfDay.size())
                .setOrderSum(ordersOfDay.stream().map(order -> order.getTotal()).reduce(new BigDecimal(0),(a, b)-> a.add(b)));
        Map<OrderStatus,Long> statusCountOfDay = new HashMap<>(2);
        statusCountOfDay.put(OrderStatus.AWAITING_PAYMENT,ordersOfDay.stream().filter(order ->
                order.getPaymentStatus()==YesOrNo.NO && order.getOrderStatus()== OrderStatus.AWAITING_PAYMENT).count());
        statusCountOfDay.put(OrderStatus.AWAITING_DELIVERY,ordersOfDay.stream().filter(order ->
                order.getShippingStatus()==YesOrNo.NO && order.getOrderStatus()==OrderStatus.AWAITING_DELIVERY).count());
        dayDashboardDTO.setStatusCount(statusCountOfDay);
        //统计本周
        CustomerOrderDashboardDTO weekDashboardDTO = new CustomerOrderDashboardDTO();
        weekDashboardDTO.setGroup("week").setOrderCount(ordersOfWeek.size())
                .setOrderSum(ordersOfWeek.stream().map(order -> order.getTotal()).reduce(new BigDecimal(0),(a, b)-> a.add(b)));
        Map<OrderStatus,Long> statusCountOfWeek = new HashMap<>(2);
        statusCountOfWeek.put(OrderStatus.AWAITING_PAYMENT,ordersOfWeek.stream().filter(order ->
                order.getPaymentStatus()==YesOrNo.NO && order.getOrderStatus()== OrderStatus.AWAITING_PAYMENT).count());
        statusCountOfWeek.put(OrderStatus.AWAITING_DELIVERY,ordersOfWeek.stream().filter(order ->
                order.getShippingStatus()==YesOrNo.NO && order.getOrderStatus()==OrderStatus.AWAITING_DELIVERY).count());
        weekDashboardDTO.setStatusCount(statusCountOfWeek);
        //统计本月
        CustomerOrderDashboardDTO monthDashboardDTO = new CustomerOrderDashboardDTO();
        monthDashboardDTO.setGroup("month").setOrderCount(ordersOfMonth.size())
                .setOrderSum(ordersOfMonth.stream().map(order -> order.getTotal()).reduce(new BigDecimal(0),(a, b)-> a.add(b)));
        Map<OrderStatus,Long> statusCountOfMonth = new HashMap<>(2);
        statusCountOfMonth.put(OrderStatus.AWAITING_PAYMENT,ordersOfMonth.stream().filter(order ->
                order.getPaymentStatus()==YesOrNo.NO && order.getOrderStatus()== OrderStatus.AWAITING_PAYMENT).count());
        statusCountOfMonth.put(OrderStatus.AWAITING_DELIVERY,ordersOfMonth.stream().filter(order ->
                order.getShippingStatus()==YesOrNo.NO && order.getOrderStatus()==OrderStatus.AWAITING_DELIVERY).count());
        monthDashboardDTO.setStatusCount(statusCountOfMonth);
        //统计全部
        List<Order> allOrders = this.selectList(new EntityWrapper<Order>().eq("customer_id",CurrentUserUtils.getLogin().getCustomerId()));
        CustomerOrderDashboardDTO allDashboardDTO = new CustomerOrderDashboardDTO();
        allDashboardDTO.setGroup("all").setOrderCount(allOrders.size())
                .setOrderSum(allOrders.stream().map(order -> order.getTotal()).reduce(new BigDecimal(0),(a, b)-> a.add(b)));
        Map<OrderStatus,Long> statusCountOfAll = new HashMap<>(2);
        statusCountOfAll.put(OrderStatus.AWAITING_PAYMENT,allOrders.stream().filter(order ->
                order.getPaymentStatus()==YesOrNo.NO && order.getOrderStatus()== OrderStatus.AWAITING_PAYMENT).count());
        statusCountOfAll.put(OrderStatus.AWAITING_DELIVERY,allOrders.stream().filter(order ->
                order.getShippingStatus()==YesOrNo.NO && order.getOrderStatus()==OrderStatus.AWAITING_DELIVERY).count());
        allDashboardDTO.setStatusCount(statusCountOfAll);

        result.add(dayDashboardDTO);
        result.add(weekDashboardDTO);
        result.add(monthDashboardDTO);
        result.add(allDashboardDTO);
        log.info("{} ,customer:{}  order's size:{}",firstDayOfMonth,CurrentUserUtils.getLogin().getCustomerId(),ordersOfMonth.size());

        return result;
    }

    @Override
    public Map<String, Integer> countOrderStatus() {
        Integer awaitAuditOrders = baseMapper.selectCount(new EntityWrapper<Order>().eq("order_status",OrderStatus.AWAITING_AUDIT.getValue()));
        Map<String,Integer> map = new HashMap<>(1);
        map.put("awaitAuditOrders",awaitAuditOrders);
        return map;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deliver(String orderCode, List<OrderShipping> shippings) {
        OrderDTO orderDTO = this.getOrderByOrderNo(orderCode);
        // 判断是否待发货状态
//        if(orderDTO.getOrder().getOrderStatus() != OrderStatus.AWAITING_DELIVERY){
//            throw   new BizException("订单："+orderCode+"暂不允许发货");
//        }
        //判断是否已发货完成
        if(orderDTO.getOrder().getShippingStatus()==YesOrNo.YES){
            throw   new BizException("订单："+orderCode+"已发货完成");
        }

        BigDecimal totalQuantity = orderDTO.getOrder().getItems().get(0).getQuantity();
        List<OrderShipping> existShippings = orderShippingService.getShippingsByOrderCode(orderCode);
        List<OrderShipping> filterShippins = shippings.stream().filter(this.isNotExist(existShippings))
                .map(orderShipping -> orderShipping.setOrderId(orderDTO.getOrder().getId()))
                .collect(Collectors.toList());
        existShippings.addAll(filterShippins);
        BigDecimal nowQuantity = existShippings.stream().map(orderShipping -> orderShipping.getQuantiy()).reduce(new BigDecimal(0),(a, b)-> a.add(b));
        //判断发货数量是否正确
        log.info("**** order:{},total quantity:{},shipped quantity:{} ******",orderCode,totalQuantity,nowQuantity);
        if(nowQuantity.compareTo(totalQuantity) > 0){
            throw new BizException("订单："+orderCode+"发货数量超过订单数量");
        }
        //发货全部完成，修改发货状态
        if(nowQuantity.compareTo(totalQuantity) == 0){
            this.updateById(orderDTO.getOrder().setShippingStatus(YesOrNo.YES));
        }
        if(!CollectionUtils.isEmpty(filterShippins)) {
            orderShippingService.insertBatch(filterShippins);
        }
    }

    @Override
    public void finish(OrderFinishDTO orderFinishDTO) {

        String orderCode = orderFinishDTO.getOrderCode();
        OrderDTO orderDTO = this.getOrderByOrderNo(orderCode);
        // 判断是否待发货状态
//        if(orderDTO.getOrder().getOrderStatus() != OrderStatus.AWAITING_DELIVERY){
//            throw   new BizException("订单："+orderCode+"暂不允许发货");
//        }
        //判断是否已发货完成
        if(orderFinishDTO.getFlag().equals(OrderFinishDTO.FINISH)
                && orderDTO.getOrder().getShippingStatus()==YesOrNo.YES){
            throw  new BizException("订单："+orderCode+"已发货完成");
        }
        //发货强制完成，发货数量可能小于订单数量;
        if(orderFinishDTO.getFlag().equals(OrderFinishDTO.FINISH)){
            log.info("order:{} was forced to finished,info:{} ",orderCode,orderFinishDTO);
            this.updateById(orderDTO.getOrder().setShippingStatus(YesOrNo.YES));
        }
        //取消订单
        if(orderFinishDTO.getFlag().equals(OrderFinishDTO.CANCEL) && orderDTO.getOrder().getShippingStatus()==YesOrNo.YES){
            this.updateById(orderDTO.getOrder().setShippingStatus(YesOrNo.NO));
        }
        log.info("强制完成(取消)订单：",orderFinishDTO.getOrderCode(),";订单状态：",orderFinishDTO.getFlag());
    }

    private Predicate<OrderShipping> isNotExist(List<OrderShipping> existShippings){
        return orderShipping ->
                existShippings.stream().filter(orderShipping1 -> orderShipping1.getShippingCode().equals(orderShipping.getShippingCode())).count() == 0;
    }


    /**
     * 生成订单发票信息
     * @param order
     * @param customer
     */
    private void createInvoice(Order order,CustomerDTO customer){
        BizAttributeDTO attributeDTO = (BizAttributeDTO) customer.getAttributes().stream()
                .filter(customerAttributeDTO -> customerAttributeDTO instanceof BizAttributeDTO)
                .findFirst().get();
        String taxCode = attributeDTO == null? "":attributeDTO.getTaxCode();
        OrderInvoice invoice = new OrderInvoice().setOrderId(order.getId())
                .setOpen(false).setTitle(customer.getCustomer().getName())
                .setInvoiceNumber(taxCode).setAmount(order.getTotal());
        orderInvoiceDao.insert(invoice);
    }

    /**
     * 生成订单明细
     * @param order
     */
    private void createItems(Order order){
        order.getItems().forEach(orderItem -> orderItemDao.insert(orderItem.setOrderId(order.getId())));
    }

    /**
     * 判断是否是当前登陆用户的订单
     * @param order
     */
    private void isLoginUserOrder(Order order){
        if(CurrentUserUtils.getLogin()!=null && !order.getCustomerId().equals(CurrentUserUtils.getLogin().getCustomerId())) {
            throw new BizException("订单：" + order.getOrderCode() + "不是当前登陆用户的订单");
        }
    }


}
