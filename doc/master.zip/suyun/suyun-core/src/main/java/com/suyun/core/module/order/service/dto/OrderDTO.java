package com.suyun.core.module.order.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.module.order.entity.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2018/1/3 下午3:32
 */
@Data
@Accessors(chain = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class OrderDTO {
    Order order;
    CustomerDTO user;
    Address address;
    OrderInvoice orderInvoice;
    List<OrderEvent> events;
    List<OrderPayment> payments;

    ContractDTO contract;
    ShippingDTO shipping;
}
