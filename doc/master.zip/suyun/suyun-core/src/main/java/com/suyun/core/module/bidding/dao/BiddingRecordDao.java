package com.suyun.core.module.bidding.dao;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.bidding.service.dto.BiddingProductDTO;
import com.suyun.core.module.bidding.service.dto.BiddingRecordDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 竞价记录表 Mapper 接口
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
public interface BiddingRecordDao extends BaseMapper<BiddingRecord> {


    /**
     * 根据客户ID和竞价产品ID修改数据
     * @param customerId
     * @param biddingProductId
     * @return
     */
    void updateBiddingRecordStatus(@Param("customerId") Long customerId, @Param("biddingProductId")Long biddingProductId);

    /**
     * 分页查询(获取我的竞价记录)
     * @param params
     * @param page
     * @return
     */
    List<BiddingRecordDTO> selectMyBiddingRecordList(Map<String,Object> params, Page<BiddingRecordDTO> page);

    /**
     * 统计待处理的竞价任务 竞价产品状态为0：已结束，竞价记录状态为1：竞价中
     */
    Integer selectCountAwaitBiddingRecord();

}
