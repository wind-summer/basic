package com.suyun.core.module.customer.enums;

import com.baomidou.mybatisplus.enums.IEnum;

import java.io.Serializable;

/**
 *@author luy
 * @version V1.0
 * @Description: 用户状态 0:未认证 1：待审核  2：正常 3：未通过 4：冻结 5:认证中
 * @date 2017/12/1 下午4:00
 */
public enum CustomerStatusEnum implements IEnum {

    NOT_AUTHENTICATION(0,"未认证"),
    AWAIT(1,"待审核"),
    SUCCESS(2,"正常"),
    FAIL(3,"未通过"),
    FROZEN(4,"冻结"),
    AWAIT_AUTHENTICATION(5,"认证中");

    private long value;
    private String desc;

    CustomerStatusEnum(final long value, final String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Serializable getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }
}
