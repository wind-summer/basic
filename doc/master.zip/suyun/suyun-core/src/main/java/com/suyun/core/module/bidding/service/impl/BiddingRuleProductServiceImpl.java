package com.suyun.core.module.bidding.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.common.exception.BizException;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.bidding.dao.BiddingRuleProductDao;
import com.suyun.core.module.bidding.entity.BiddingDeposit;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.suyun.core.module.bidding.entity.BiddingRule;
import com.suyun.core.module.bidding.entity.BiddingRuleProduct;
import com.suyun.core.module.bidding.enums.BiddingRecordStatus;
import com.suyun.core.module.bidding.enums.BiddingStatus;
import com.suyun.core.module.bidding.service.*;
import com.suyun.core.module.bidding.service.dto.BiddingOrderDTO;
import com.suyun.core.module.bidding.service.dto.BiddingProductDTO;
import com.suyun.core.module.bidding.service.dto.CustomerDepositDTO;
import com.suyun.core.module.bidding.service.dto.HotBiddingProductDTO;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.OrderType;
import com.suyun.core.module.order.enums.PaymentMethod;
import com.suyun.core.module.order.enums.ShippingMethod;
import com.suyun.core.module.order.enums.ShippingPaymentMethod;
import com.suyun.core.module.order.service.OrderService;
import com.suyun.core.module.product.entity.CategoryProduct;
import com.suyun.core.module.product.entity.Product;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.module.product.service.CategoryProductService;
import com.suyun.core.module.product.service.ProductService;
import com.suyun.core.module.product.service.SkuService;
import com.suyun.core.sys.entity.SysUser;
import com.suyun.core.sys.service.SysUserService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@Service
@AllArgsConstructor
@Slf4j
public class BiddingRuleProductServiceImpl extends ServiceImpl<BiddingRuleProductDao, BiddingRuleProduct> implements BiddingRuleProductService {

    private final BiddingRuleService biddingRuleService;

    private final BiddingRecordService biddingRecordService;

    private final BiddingDepositService biddingDepositService;

    private final OrderService orderService;

    private final SysUserService sysUserService;

    private final ProductService productService;

    private final SkuService skuService;

    private final CategoryProductService categoryProductService;

    private final ZSetOperations<String,Object> zSetOperations;

    private final ApplicationProperties applicationProperties;

    private final AccountApplyService accountApplyService;

    /**
     * 添加竞价规则和产品关联表数据
     * @param biddingRule
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addBiddingRuleAndProduct(BiddingRule biddingRule) {
        ValidatorUtils.validateEntity(biddingRule);
        //判断当前开始日期是否过期
        if(System.currentTimeMillis() >=biddingRule.getStartDate().getTime()){
            biddingRule.setStartDate(new Date());
            //throw new BizException("开始时间应该在当前时间之前");
        }
        biddingRuleService.insert(biddingRule);
        if (biddingRule.getId() == null) {
            throw new BizException("竞价规则添加失败");
        }

        //保存竞价规则和产品关联表数据
        List<BiddingRuleProduct> biddingRuleProductList = biddingRule.getBiddingProductList();
        Optional.ofNullable(biddingRuleProductList).map(products -> {
            products.forEach(p -> {
                //判断竞价产品数量不能小于起拍数量
                if(p.getQuantity()<p.getStartQuantity()){
                    throw new BizException("产品竞拍数量不能小于起拍数量");
                }
                Sku sku = skuService.selectById(p.getSkuId());
                Product product = productService.selectById(p.getProductId());
                CategoryProduct categoryProduct = categoryProductService.findByProductId(p.getProductId());
                p.setBiddingRuleId(biddingRule.getId())
                        .setStartDate(biddingRule.getStartDate())
                        .setEndDate(biddingRule.getEndDate())
                        .setSkuCode(sku.getSkuCode())
                        .setWarehouseCode(sku.getWarehouseCode())
                        .setProductName(product.getName())
                        .setGradeCode(product.getGradeCode())
                        .setManufacturerCode(product.getManufacturerCode())
                        .setCategoryId(categoryProduct.getCategoryId())
                        .setCategoryName(categoryProduct.getCategoryName())
                        .setUnitCode(sku.getUnitCode());
            });
            return true;
        });
        this.insertBatch(biddingRuleProductList);
        //把竞价产品ID放入缓存
        biddingRuleProductList.forEach(p -> {
            zSetOperations.add(BiddingConstant.AWAITING_START_BIDDING_PRODUCT_KEY,p.getId(),biddingRule.getStartDate().getTime());
            zSetOperations.add(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY,p.getId(),biddingRule.getEndDate().getTime());
        });
    }

    /**
     * 分页查询
     * @param param  条件
     * @param page   页面条件
     * @return
     */
    @Override
    public Page<BiddingProductDTO> queryBiddingRuleProduct(Map<String, Object> param, Page<BiddingProductDTO> page) {
        List<BiddingProductDTO> biddingProductDTOS = baseMapper.selectBiddingProductList(param,page);
        return page.setRecords(biddingProductDTOS);
    }

    /**
     * api分页查询
     * @param param  条件
     * @param page   页面条件
     * @return
     */
    @Override
    public Page<BiddingProductDTO> queryBiddingRuleProductApi(Map<String, Object> param, Page<BiddingProductDTO> page) {
        List<BiddingProductDTO> biddingProductDTOS = baseMapper.selectBiddingProductApiList(param,page);
        return page.setRecords(biddingProductDTOS);
    }
    /**
     * 根据id获取竞价产品详情
     * @param id
     * @return
     */
    @Override
    public BiddingProductDTO getBiddingProductInfoById(Long id) {
        BiddingProductDTO biddingProducDTO = baseMapper.selectBiddingProductById(id);
        Optional.ofNullable(biddingProducDTO).map(p->{
            return p.setBiddingRule(biddingRuleService.selectOne(new EntityWrapper<BiddingRule>().eq("id", p.getBiddingRuleId())));
        }).orElseThrow(()-> new BizException("没有该产品数据"));

        //获取浏览量
        double score = 0;
        try {
            score = zSetOperations.score(BiddingConstant.ONLOOKERS_BIDDING_PRODUCT_KEY,id);
        }catch (NullPointerException e){
            score = 0;
        }
        biddingProducDTO.setOnlookers(score);
        //报名人数
        Integer signUpCount = biddingDepositService.selectCount(new EntityWrapper<BiddingDeposit>()
                .eq("bidding_product_id",id));
        biddingProducDTO.setSignUpCount(signUpCount);
        //添加竞价规则
        biddingProducDTO.setBiddingRule(biddingRuleService.selectById(biddingProducDTO.getBiddingRuleId()));
        //添加联系人和联系人电话
        Sku sku = skuService.selectById(biddingProducDTO.getSkuId());
        //组装产品价格和库存
        biddingProducDTO.setStock(sku.getQuantityAvailable()).setProductPrice(sku.getSalePrice());
        SysUser sysUser = sysUserService.queryObject(sku.getUserId());
        if(sysUser != null) {
            biddingProducDTO.setContactName(sysUser.getNick());
            biddingProducDTO.setContactPhone(sysUser.getMobile());
        }
        return biddingProducDTO;
    }

    /**
     * 出价竞价产品
     * @param biddingRecord
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void bidBiddingProduct(BiddingRecord biddingRecord){
        //校验保证金是否交够
        CustomerDepositDTO customerDepositDTO = this.checkCustomerDeposit(biddingRecord.getBiddingProductId());
        if(customerDepositDTO.getPass()){
            //保存数据之前要校验一下产品
            BiddingRuleProduct biddingRuleProduct = baseMapper.selectById(biddingRecord.getBiddingProductId());
            BiddingRule biddingRule = biddingRuleService.selectById(biddingRuleProduct.getBiddingRuleId());

            //最小跳价
            BigDecimal minJumpPrice = biddingRule.getMinJumpPrice();
            //起拍单价
            BigDecimal startUnitPrice = biddingRuleProduct.getStartUnitPrice();
            //最高单价
            BigDecimal maxUnitPrice = biddingRuleProduct.getMaxPrice();
            //产品起拍数量
            Long startQuantity = biddingRuleProduct.getStartQuantity();
            if(maxUnitPrice == null) {
                maxUnitPrice = startUnitPrice;
            }else{
                maxUnitPrice = maxUnitPrice.add(minJumpPrice);
            }
            if(biddingRuleProduct.getBiddingStatus() != BiddingStatus.BIDDING) {
                throw new BizException("该产品竞价状态错误");
            }
            if(biddingRecord.getBiddingQuantity() < startQuantity) {
                throw new BizException("竞拍数量错误，竞拍数量至少为：" + startQuantity);
            }
            if(biddingRecord.getBiddingPrice().compareTo(maxUnitPrice) == -1) {
                throw new BizException("竞拍单价错误，竞拍单价至少为：" + maxUnitPrice);
            }
            Integer addPrice = biddingRecord.getBiddingPrice().subtract(biddingRuleProduct.getStartUnitPrice()).intValue();
            Integer jumpPrice = minJumpPrice.intValue();
            if(addPrice % jumpPrice!= 0){
                throw new BizException("增加的价格应该是加价幅度的整数倍");
            }
            if(!biddingRecord.getBiddingQuantity().equals(biddingRuleProduct.getStartQuantity())){
                if((biddingRecord.getBiddingQuantity() - biddingRuleProduct.getStartQuantity())%biddingRuleProduct.getMinJumpQuantity() != 0){
                    throw new BizException("增加的数量应该是加量幅度的整数倍");
                }
            }
            if(biddingRecord.getBiddingPrice().compareTo(maxUnitPrice) == -1) {
                throw new BizException("竞拍单价错误，竞拍单价至少为：" + maxUnitPrice);
            }
            if(biddingRecord.getBiddingQuantity()> biddingRuleProduct.getQuantity()) {
                throw new BizException("竞拍数量大于当前竞拍产品总数");
            }

            Long customerId = CurrentUserUtils.getLogin().getCustomerId();
            //把当前用户对该产品的所有竞拍记录都设置为已关闭
            biddingRecordService.updateBiddingRecordStatus(customerId, biddingRecord.getBiddingProductId());
            //保存数据
            biddingRuleProduct
                    .setLastBiddingTime(new Date())
                    .setMaxPrice(biddingRecord.getBiddingPrice())
                    .updateById();
            biddingRecord
                    .setCustomerId(customerId)
                    .setBidder(CurrentUserUtils.getLogin().getUserName())
                    .setBiddingStatus(BiddingRecordStatus.BIDDING)
                    .insert();
            //判断是否进入倒计时
            Long countdownTimes = biddingRule.getCountdownTime()*60*1000;
            Long lastTimes = biddingRuleProduct.getLastBiddingTime().getTime();
            Long endDateTimes =biddingRuleProduct.getEndDate().getTime();
            if(countdownTimes + lastTimes > endDateTimes){
                //顺延结束时间
                //Long delayTimes = biddingRule.getCountdownTime()*60*1000;
                double score = lastTimes+countdownTimes;
                zSetOperations.add(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY,biddingRuleProduct.getId(), score);
                biddingRuleProduct.setEndDate(new Date(countdownTimes + lastTimes)).updateById();
            }

        } else {
            throw new BizException("保证金校验未通过");
        }
    }

    /**
     * 检查当前竞价产品，当前用户是否已经交保证金交够
     * @param id                竞价产品ID
     * @return
     * , Long quantity, BigDecimal biddingPrice
     */
    @Override
    public CustomerDepositDTO checkCustomerDeposit(Long id) {
        BiddingRuleProduct biddingRuleProduct = baseMapper.selectById(id);
        if(biddingRuleProduct == null){
            throw new BizException("没有该竞价产品");
        }
        BiddingRule biddingRule = biddingRuleService.selectOne(
                new EntityWrapper<BiddingRule>().eq("id", biddingRuleProduct.getBiddingRuleId()));
        //保证金比例
        BigDecimal depositPercent = biddingRule.getDeposit();
        //总金额=起拍单价*总数量
        BigDecimal allAmount = biddingRuleProduct.getStartUnitPrice()
                .multiply(new BigDecimal(biddingRuleProduct.getQuantity()));

        //至少要交的定金
        BigDecimal deposit = allAmount.multiply(depositPercent).divide(new BigDecimal(100));
        //如果需要交的定金大于最高定金，需要交的定金就用最高定金
        if(deposit.compareTo(applicationProperties.getBidding().getMaxDeposit()) == 1){
            deposit = applicationProperties.getBidding().getMaxDeposit();
        }
        //DecimalFormat decimalFormat = new DecimalFormat("#,###.00");
        //decimalFormat.format(deposit);
        //应该交的定金不能小于deposit

        //已经交付的该产品的总定金
        BigDecimal depositSum = new BigDecimal(0);
        List<BiddingDeposit> biddingDepositList = biddingDepositService.selectList(
                new EntityWrapper<BiddingDeposit>()
                        .eq("bidding_product_id", id)
                        .eq("customer_id", CurrentUserUtils.getLogin().getCustomerId())
                        .eq("is_refunded",false));
        for(BiddingDeposit bd : biddingDepositList) {
            depositSum = depositSum.add(bd.getDeposit());
        }
        CustomerDepositDTO customerDepositDTO = new CustomerDepositDTO();
        if(depositSum.compareTo(deposit) == -1) {
            //说明已经交的定金不够
            customerDepositDTO.setPass(false);
        } else {
            customerDepositDTO.setPass(true);
        }
        customerDepositDTO.setCurrentDeposit(depositSum);
        customerDepositDTO.setNeedDeposit(deposit);
        return customerDepositDTO;
    }

    /**
     * 创建订单
     * @param biddingOrderDTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createBiddingOrder(BiddingOrderDTO biddingOrderDTO) {
        //验证改竞拍是否已经成功
        BiddingRecord biddingRecord = biddingRecordService.selectById(biddingOrderDTO.getRecordId());
        if(biddingRecord == null) {
            throw new BizException("没有该条竞价记录");
        }
        if(!biddingRecord.getBiddingStatus().equals(BiddingRecordStatus.SUCCESS)){
            throw new BizException("竞拍成功的竞价记录才能下单");
        }
        //验证该竞价产品是否已经结束
        BiddingRuleProduct biddingRuleProduct = this.selectById(biddingRecord.getBiddingProductId());
        if(!biddingRuleProduct.getBiddingStatus().equals(BiddingStatus.FINISHED)){
            throw new BizException("该竞价产品竞价流程还没结束");
        }
        Order order = new Order();
        order.setPaymentMethod(PaymentMethod.PRE_PAY)
                .setShippingMethod(ShippingMethod.SHIPPING)
                .setOrderType(OrderType.BIDDING)
                .setAddressId(biddingOrderDTO.getAddressId())
                .setRemark(biddingOrderDTO.getRemark())
                .setItems(biddingOrderDTO.getItemList())
                .setShippingPaymentMethod(ShippingPaymentMethod.ONE);

        //创建订单
        Order afterOrder = orderService.createOrder(order);
        //修改相应的竞价记录和把单号存进去，状态改为已下单
        biddingRecord.setOrderCode(afterOrder.getOrderCode()).setBiddingStatus(BiddingRecordStatus.ORDERED).updateById();
    }

    /**
     * 增加竞价产品围观次数
     * @param id
     */
    @Override
    public void addOnlookers(Long id) {
        double score = 0;
        try {
            score = zSetOperations.score(BiddingConstant.ONLOOKERS_BIDDING_PRODUCT_KEY,id);
        }catch (NullPointerException e){
            score = 0;
        }
        zSetOperations.add(BiddingConstant.ONLOOKERS_BIDDING_PRODUCT_KEY,id, score+1);
    }

    /**
     * 查询热门竞价产品
     * @return
     */
    @Override
    public List<HotBiddingProductDTO> queryHotBiddingProduct(Page page) {
        //设置页面数量和按创建时间早排序
        page.setSize(8).setOrderByField("create_date").setAsc(true);
        //查询热门竞价产品列表
        List<BiddingRuleProduct> biddingRuleProducts
                = this.selectList(new EntityWrapper<BiddingRuleProduct>()
                .eq("bidding_status", BiddingStatus.BIDDING));
        List<HotBiddingProductDTO> hotBiddingProductDTOS = new ArrayList<HotBiddingProductDTO>();
        Date nowDate = new Date();
        //品质hotDto列表
        biddingRuleProducts.forEach(b -> {
            Product p = productService.selectById(b.getProductId());
            HotBiddingProductDTO h = new HotBiddingProductDTO();
            h.setBiddingProductId(b.getProductId())
                    .setBiddingRuleId(b.getBiddingRuleId())
                    .setSkuId(b.getSkuId())
                    .setEndDate(b.getEndDate())
                    .setBiddingProductId(b.getId())
                    .setProductName(p.getName())
                    .setNowDate(nowDate);
            hotBiddingProductDTOS.add(h);
        });
        return hotBiddingProductDTOS;
    }

    /**
     * 根据ID查询竞价产品是否已经超过竞拍结束时间，如果超过就把状态改为已结束
     * @param id
     */
    @Override
    public void checkBiddingProductStatus(Long id) {
        BiddingRuleProduct biddingRuleProduct = this.selectById(id);
        //如果当前时间已经超时
        if(biddingRuleProduct != null
                && biddingRuleProduct.getEndDate() != null
                && System.currentTimeMillis() >= biddingRuleProduct.getEndDate().getTime()){
            //修改状态为已结束，并且把缓存里面的当前对象id去掉
            this.endBiddingProduct(id);
            //biddingRuleProduct.setBiddingStatus(BiddingStatus.FINISHED).updateById();
            //zSetOperations.remove(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY,biddingRuleProduct.getId());
        }
    }

    /**
     * 结束竞价活动
     * @param id 产品ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void endBiddingProduct(Long id) {
        //更新状态
        BiddingRuleProduct biddingRuleProduct = this.selectById(id);
        if(biddingRuleProduct!= null && biddingRuleProduct.getBiddingStatus().equals(BiddingStatus.BIDDING)){
            //检查定金记录，没有竞拍过的用户定金解冻
            //1.先查询出来该产品订单交易记录
            List<BiddingDeposit> depositList = biddingDepositService
                    .selectList(new EntityWrapper<BiddingDeposit>()
                            .eq("bidding_product_id", id)
                            .eq("is_refunded" , 0));
            //处理保证金key：customerId value：deposit
            Map<Long,BigDecimal> depositMap = new HashMap<Long,BigDecimal>();
            //已客户为key 统计保证金
            depositList.forEach(deposit -> {
                Long customerId = deposit.getCustomerId();
                BigDecimal amount = deposit.getDeposit();
                BigDecimal allAmount = depositMap.get(customerId);
                if(allAmount == null) {
                    allAmount = new BigDecimal(0);
                }
                allAmount = allAmount.add(amount);
                depositMap.put(customerId, allAmount);
            });

            //2.先查询出来该产品竞价记录状态为1：竞价中:
            List<BiddingRecord> biddingRecordList = biddingRecordService.selectList(
                    new EntityWrapper<BiddingRecord>().eq("bidding_product_id", id)
                            .eq("bidding_status", 1));
            biddingRecordList.forEach(br -> {
                //竞价记录状态由竞价中变为统计中
                br.setBiddingStatus(BiddingRecordStatus.STATISTICS);
                depositMap.remove(br.getCustomerId());
            });
            //更新状态
            if(biddingRecordList!=null && biddingRecordList.size()>0){
                biddingRecordService.updateAllColumnBatchById(biddingRecordList);
            }

            //解冻账户
            depositMap.forEach((customerId, allAmount) -> {
                //调用账户接口，解冻保证金
                accountApplyService.unFreezeByCustomerId(customerId, allAmount, 4);
                //修改定金记录为已退回
                List<BiddingDeposit> deposits = biddingDepositService.selectList(
                        new EntityWrapper<BiddingDeposit>()
                                .eq("is_refunded", 0)
                                .eq("customer_id",customerId)
                                .eq("bidding_product_id", id));
                deposits.forEach(d -> {
                    d.setRefunded(true);
                });
                if(deposits!=null && deposits.size()>0){
                    biddingDepositService.updateAllColumnBatchById(deposits);
                }
            });
            //竞价产品改为已结束
            biddingRuleProduct.setBiddingStatus(BiddingStatus.FINISHED).updateById();
            zSetOperations.remove(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY,id);
        }else{
            if(biddingRuleProduct.getBiddingStatus().equals(BiddingStatus.FINISHED)){
                zSetOperations.remove(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY,id);
            }
        }
    }

    /**
     * 判断商品是否可以下架
     * @param skuId SKU   ID
     * @return
     */
    @Override
    public Boolean isOffShelfSku(Long skuId) {
        Boolean isOffShel = true;
        List<BiddingRuleProduct> biddingRuleProducts = this.selectList(
                new EntityWrapper<BiddingRuleProduct>().eq("sku_id",skuId));
        if(biddingRuleProducts.size() != 0){
            for( BiddingRuleProduct bp : biddingRuleProducts) {
                //如果产品状态不是已结束
                if(!bp.getBiddingStatus().equals(BiddingStatus.FINISHED)){
                    isOffShel = false;
                    break;
                }else{
                    //如果产品状态是已结束,就要判断当前产品是否有竞价记录，有竞价记录就要检查竞价记录2：竞价成功，或者1：竞价中 或者8：统计中
                    List<BiddingRecord> biddingRecords = biddingRecordService.selectList(
                            new EntityWrapper<BiddingRecord>()
                                    .eq("bidding_product_id",bp.getId())
                                    .eq("bidding_status", new Integer[]{1,2,8}));
                    if(biddingRecords.size() > 0 ){
                        isOffShel = false;
                    }
                }
            }
        }
        return isOffShel;
    }
}
