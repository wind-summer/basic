package com.suyun.core.module.bidding.dao;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.bidding.entity.BiddingRuleProduct;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.bidding.service.dto.BiddingProductDTO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
public interface BiddingRuleProductDao extends BaseMapper<BiddingRuleProduct> {

    /**
     * 根据id取竞价产品详情
     * @param id
     * @return
     */
    BiddingProductDTO selectBiddingProductById(Long id);

    /**
     * 分页查询(sql关联查询)
     * @param params
     * @param page
     * @return
     */
    List<BiddingProductDTO> selectBiddingProductList(Map<String,Object> params, Page<BiddingProductDTO> page);

    /**
     * api端使用分页查询(sql关联查询)
     * @param params
     * @param page
     * @return
     */
    List<BiddingProductDTO> selectBiddingProductApiList(Map<String,Object> params, Page<BiddingProductDTO> page);

}
