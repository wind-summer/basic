package com.suyun.core.module.open.service;

import com.suyun.core.module.open.entity.ApiClient;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caosg
 * @since 2018-03-06
 */
public interface ApiClientService extends IService<ApiClient> {

    /**
     * 根据客户端Id查询客户端信息
     * @param clientId
     * @return
     */
    ApiClient getClientByClientId(String clientId);

    /**
     * 清空客户端缓存信息
     */
    void clearCache();
}
