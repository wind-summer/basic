package com.suyun.core.module.order.statemachine.action;

import com.suyun.common.sms.SmsProperties;
import com.suyun.common.utils.ConfigConstant;
import com.suyun.core.module.bidding.service.BiddingRecordService;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.enums.OrderType;
import com.suyun.core.module.order.service.OrderConstant;
import com.suyun.core.module.order.service.OrderEventService;
import com.suyun.core.module.order.service.OrderPushService;
import com.suyun.core.module.order.service.OrderSms;
import com.suyun.core.module.order.statemachine.annotation.StatesOnStates;
import com.suyun.core.module.order.statemachine.annotation.WithOrderStateMachine;
import com.suyun.core.sys.service.SysConfigService;
import com.suyun.core.sys.service.dto.SysConfigDTO;
import com.suyun.core.utils.LoginUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.messaging.Message;
import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.annotation.OnEventNotAccepted;
import org.springframework.statemachine.annotation.OnStateChanged;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单处理流程，事件监听
 * @date 2017/12/11 上午11:40
 */
@WithOrderStateMachine
@Slf4j
@AllArgsConstructor
public class OrderStateChangeAction {

    private final OrderEventService orderEventService;

    private final ZSetOperations<String, Object> zSetOperations;

    private final SysConfigService sysConfigService;

    private final BiddingRecordService biddingRecordService;

    private final OrderSms orderSms;

    private final SmsProperties smsProperties;

    private final OrderPushService orderPushService;


    @StatesOnStates(source = OrderStatus.AWAITING_AUDIT,target = OrderStatus.AWAITING_CONFIRM)
    public void auditSuccess(StateContext<OrderStatus,OrderEvent> stateContext){

        Order order = this.getOrderFromHeaders(stateContext);
        if(order!=null){
            //短信通知
            orderSms.sendSms(order,smsProperties.getOrderAuditTemplateCode());
            //待确认订单超时
            SysConfigDTO sysConfigDTO = sysConfigService.getConfigObject(ConfigConstant.SYS_GLOBAL_CONFIG_KEY, SysConfigDTO.class);
            Long expireTime = System.currentTimeMillis() + +sysConfigDTO.getOrderExpireConfirm()*60*1000;
            zSetOperations.add(OrderConstant.AWAITING_CONFIRM_ORDER_KEY,order.getId(),expireTime);
            log.info(" ----推送至Redis等待确认集合，订单ID:{} -- 超时时间:{} 秒",order.getId(),expireTime);
        }
    }

    @StatesOnStates(target = OrderStatus.AWAITING_RECEIVE)
    public void deliverSuccess(StateContext<OrderStatus,OrderEvent> stateContext){

        Order order = this.getOrderFromHeaders(stateContext);
        if(order!=null){
            //短信通知
            orderSms.sendSms(order,smsProperties.getOrderDeliverTemplateCode());

        }
    }

    @StatesOnStates(source = OrderStatus.AWAITING_PAYMENT,target = OrderStatus.AWAITING_DELIVERY)
    public void paySuccess(StateContext<OrderStatus,OrderEvent> stateContext){

        Order order = this.getOrderFromHeaders(stateContext);
        if(order!=null){
            //短信通知
            orderSms.sendSms(order,smsProperties.getOrderPayTemplateCode());

        }
    }
    @StatesOnStates(target = OrderStatus.AWAITING_DELIVERY)
    public void pushErp(StateContext<OrderStatus,OrderEvent> stateContext){

        Order order = this.getOrderFromHeaders(stateContext);
        log.info("------ 同步订单数据到ERP系统----- \n order info:{} ",order);
        if(order!=null){
            //TODO 推送给浪潮系统发货
            orderPushService.pushOrderByOrderId(order.getId());
        }
    }

    @StatesOnStates(source = OrderStatus.AWAITING_CONFIRM,target = OrderStatus.AWAITING_PAYMENT)
    public void confirmToPay(StateContext<OrderStatus,OrderEvent> stateContext){

        Order order = this.getOrderFromHeaders(stateContext);
        if(order!=null){
            //待支付订单超时
            SysConfigDTO sysConfigDTO = sysConfigService.getConfigObject(ConfigConstant.SYS_GLOBAL_CONFIG_KEY, SysConfigDTO.class);
            Long expireTime = System.currentTimeMillis() + +sysConfigDTO.getOrderExpirePay()*60*1000;
            zSetOperations.add(OrderConstant.AWAITING_PAY_ORDER_KEY,order.getId(),expireTime);
            log.info(" ----推送至Redis等待支付集合，订单ID:{} -- 超时时间:{} 秒",order.getId(),expireTime);

        }
    }

    @StatesOnStates(target = OrderStatus.CANCELED)
    public void releaseBiddingepositD(StateContext<OrderStatus,OrderEvent> stateContext){
        Order order = this.getOrderFromHeaders(stateContext);
        if(order!=null&&order.getOrderType()== OrderType.BIDDING){
            Message<OrderEvent>  message = stateContext.getMessage();
            if (message != null && message.getHeaders().containsKey(OrderConstant.MANUAL_CANCEL_ORDER_FLAG)) {
                Boolean isManulCancel = message.getHeaders().get(OrderConstant.EVENT_MESSAGE_HEADER_KEY, Boolean.class);
                if(isManulCancel){
                    biddingRecordService.returnBiddingRecord(order.getOrderCode());
                    log.info(" ----释放订单保证金，订单ID:{} -- ",order.getId());
                }else {
                    biddingRecordService.breakPromiseBidding(order.getOrderCode());
                    log.info(" ----扣减订单保证金，订单ID:{} -- ",order.getId());
                }
            }

        }
    }

    @OnStateChanged
    public void stateChanged(StateContext<OrderStatus,OrderEvent> stateContext){
        if(stateContext.getSource() !=null) {
            log.info("State from {}  changed to {}",stateContext.getSource().getId(), stateContext.getTarget().getId());
            Order order = this.getOrderFromHeaders(stateContext);
            if (order != null ) {
                com.suyun.core.module.order.entity.OrderEvent orderEvent = new com.suyun.core.module.order.entity.OrderEvent();
                orderEvent.setOrderId(order.getId())
                        .setSourceStatus(stateContext.getSource() == null ? OrderStatus.INIT : stateContext.getSource().getId())
                        .setTargetStatus(stateContext.getTarget().getId())
                        .setOrderEvent(stateContext.getEvent())
                        .setCreateBy(LoginUtils.getLoginName());
                orderEventService.insert(orderEvent);
            }
        }
    }
    @OnEventNotAccepted
    public void anyEventNotAccepted(Message<OrderEvent> message){
        log.error("Event not accepted : {} ", message.getPayload());
    }

    private Order getOrderFromHeaders(StateContext<OrderStatus,OrderEvent> stateContext){
        Order order = null ;
        Message<OrderEvent>  message = stateContext.getMessage();
        if (message != null && message.getHeaders().containsKey(OrderConstant.EVENT_MESSAGE_HEADER_KEY)) {
           order  = message.getHeaders().get(OrderConstant.EVENT_MESSAGE_HEADER_KEY, Order.class);
        }
        return order;
    }
}
