package com.suyun.core.module.order.statemachine;

import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.StateMachine;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/12/5 下午9:29
 */
@Configuration
public class PersisterStateMachineConfig {
//    @Bean
//    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
//    public ProxyFactoryBean stateMachine() {
//        ProxyFactoryBean pfb = new ProxyFactoryBean();
//        pfb.setTargetSource(poolTargetSource());
//        return pfb;
//    }
//
//    @Bean
//    public CommonsPool2TargetSource poolTargetSource() {
//        CommonsPool2TargetSource pool = new CommonsPool2TargetSource();
//        pool.setMaxSize(3);
//        pool.setTargetBeanName("stateMachineOrder");
//        return pool;
//    }
//
//
//    @Bean
//    public StateMachinePersister<OrderStatus, OrderEvent,String>  redisStateMachinePersister(
//            RedisConnectionFactory connectionFactory){
//        InMemoryStateMachinePersist inMemoryStateMachinePersist = new InMemoryStateMachinePersist(connectionFactory);
//        StateMachinePersister<OrderStatus, OrderEvent,String> redisStateMachinePersister = new DefaultStateMachinePersister<>(inMemoryStateMachinePersist);
//        return redisStateMachinePersister;
//    }

    @Bean
    public OrderPersistStateMachineHandler persistStateMachineHandler(@Autowired StateMachine<OrderStatus, OrderEvent> stateMachine){
        OrderPersistStateMachineHandler orderPersistStateMachineHandler = new OrderPersistStateMachineHandler(stateMachine);
        orderPersistStateMachineHandler.addPersistStateChangeListener(persistStateChangeListener());
        return orderPersistStateMachineHandler;
    }

    @Bean
    public OrderPersistStateChangeListener persistStateChangeListener(){
        return new OrderPersistStateChangeListener();
    }
}
