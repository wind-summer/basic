package com.suyun.core.module.bidding.dao;

import com.suyun.core.module.bidding.entity.BiddingRule;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
public interface BiddingRuleDao extends BaseMapper<BiddingRule> {

}
