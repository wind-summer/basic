package com.suyun.core.module.bidding.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.bidding.service.dto.BiddingRecordDTO;

import java.util.Map;

/**
 * <p>
 * 竞价记录表 服务类
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
public interface BiddingRecordService extends IService<BiddingRecord> {

    /**
     * 根据竞价产品ID分页查询竞价记录
     * @param productId
     * @param page
     * @return
     */
    Page<BiddingRecord> queryBiddingRecordByProductId(Long productId, Page<BiddingRecord> page);

    /**
     * 根据客户ID和竞价产品ID修改数据
     * @param customerId
     * @param biddingProductId
     * @return
     */
    void updateBiddingRecordStatus(Long customerId,Long biddingProductId);

    /**
     * 根据id取消竞价记录
     * @param id
     */
    void cancelBiddingRecord(Long id);

    /**
     * 根据orderCode退还押金
     * @param orderCode
     */
    void returnBiddingRecord(String orderCode);

    /**
     * 扣除押金
     * @param orderCode
     */
    void breakPromiseBidding(String orderCode);

    /**
     * 分页查询(sql关联查询)
     * @param param  条件
     * @param page   页面条件
     * @return
     */
    Page<BiddingRecordDTO> queryMyBiddingRecord(Map<String, Object> param, Page<BiddingRecordDTO> page);

    /**
     * 根据id获取我的竞价详情
     * @param id
     * @return
     */
    BiddingRecord getMyBiddingRecord(Long id);

    /**
     * 根据id成交竞价记录
     * @param id
     */
    void dealBiddingRecord(Long id);

    /**
     * 统计待处理的竞价记录
     * @return
     */
    Integer countAwaitBiddingRecord();

}
