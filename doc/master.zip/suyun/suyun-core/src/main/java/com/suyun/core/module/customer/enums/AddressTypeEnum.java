package com.suyun.core.module.customer.enums;

import com.baomidou.mybatisplus.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;

/**
 * <p>地址类型</p>
 */
@JsonFormat(shape= JsonFormat.Shape.OBJECT)
public enum AddressTypeEnum implements IEnum{
    SHIPPING(1,"收货地址"),
    BILLING(2,"账单地址");

    private long value;
    private String desc;

    AddressTypeEnum(final long value, final String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public Serializable getValue() {
        return this.value;
    }

    public String getDesc(){
        return this.desc;
    }

}
