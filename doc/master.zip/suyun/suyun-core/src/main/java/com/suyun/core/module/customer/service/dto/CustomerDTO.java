package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.entity.CustomerLogin;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author caosg
 * @Description: 客户详细信息
 * @date 2017/12/1 上午11:52
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerDTO {
    //客户基本信息
    private Customer customer;
    //登录信息
    private CustomerLogin login;
    //详细信息
    private List<CustomerAttributeDTO> attributes;
    //默认收货地址
    private Address defaultAddress;
    private String token;
}
