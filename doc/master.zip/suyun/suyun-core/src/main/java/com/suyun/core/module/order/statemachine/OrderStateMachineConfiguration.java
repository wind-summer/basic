package com.suyun.core.module.order.statemachine;

import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.service.OrderConstant;
import com.suyun.core.module.order.statemachine.guard.OrderOwnerGuard;
import com.suyun.core.module.order.statemachine.guard.PaymentGuard;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.config.EnableStateMachine;
import org.springframework.statemachine.config.EnumStateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineConfigurationConfigurer;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;
import org.springframework.statemachine.guard.Guard;

import java.util.EnumSet;

/**
 * @author caosg
 * @Description: 订单状态机配置
 * @date 2017/12/5 下午5:05
 */
@Configuration
@Slf4j
@AllArgsConstructor
@EnableStateMachine(name = "stateMachineOrder",contextEvents = false)
public class OrderStateMachineConfiguration extends EnumStateMachineConfigurerAdapter<OrderStatus,OrderEvent> {


    private final PaymentGuard paymentGuard;

    private final OrderOwnerGuard orderOwnerGuard;

    @Override
    public void configure(StateMachineConfigurationConfigurer<OrderStatus, OrderEvent> config)
            throws Exception {
        config
                .withConfiguration().autoStartup(true).machineId(OrderConstant.STATE_MACHINE_ID);
    }
    @Override
    public void configure(StateMachineStateConfigurer<OrderStatus, OrderEvent> states)
            throws Exception {
        states
                .withStates()
                .initial(OrderStatus.INIT)
                .states(EnumSet.allOf(OrderStatus.class));
    }

    @Override
    public void configure(StateMachineTransitionConfigurer<OrderStatus, OrderEvent> transitions)
            throws Exception {
        transitions
                // (0) 创建订单
                .withExternal()
                .source(OrderStatus.INIT)
                .target(OrderStatus.AWAITING_AUDIT)
                .event(OrderEvent.CREATE)
                .and()
                .withExternal()
                // (1) 审核
                .source(OrderStatus.AWAITING_AUDIT)
                .target(OrderStatus.AWAITING_CONFIRM)
                .event(OrderEvent.AUDIT)
                .and()
                // (2) 先付款确认后： 待确认 -》 待付款
                .withExternal()
                .source(OrderStatus.AWAITING_CONFIRM)
                .target(OrderStatus.AWAITING_PAYMENT)
                .guard(orderOwnerGuard)
                .guard(paymentGuard)
                .event(OrderEvent.CONFIRM)
                .and()
                 //后付款确认后： 待确认 -》 待发货
                .withExternal()
                .source(OrderStatus.AWAITING_CONFIRM)
                .target(OrderStatus.AWAITING_DELIVERY)
                .guard(not(paymentGuard))
                .event(OrderEvent.CONFIRM)
                .and()
                // 先付款 支付  待支付 -> 待发货
                .withExternal()
                .source(OrderStatus.AWAITING_PAYMENT)
                .target(OrderStatus.AWAITING_DELIVERY)
                .guard(paymentGuard)
                .event(OrderEvent.PAYMENT)
                .and()
                // (4) 发货 待发货-》待收货
                .withExternal()
                .source(OrderStatus.AWAITING_DELIVERY)
                .target(OrderStatus.AWAITING_RECEIVE)
                .event(OrderEvent.DELIVER)
                .and()
                // 先付款收货 待收货 -》 已完成
                .withExternal()
                .source(OrderStatus.AWAITING_RECEIVE)
                .target(OrderStatus.COMPLETED)
                .guard(orderOwnerGuard)
                .guard(paymentGuard)
                .event(OrderEvent.RECEIVE)
                .and()
                //后付款收货后： 待收货 -》 待付款
                .withExternal()
                .source(OrderStatus.AWAITING_RECEIVE)
                .target(OrderStatus.AWAITING_PAYMENT)
                .guard(orderOwnerGuard)
                .guard(not(paymentGuard))
                .event(OrderEvent.RECEIVE)
                .and()
                //后付款执行付款： 待付款 -》已完成
                .withExternal()
                .source(OrderStatus.AWAITING_PAYMENT)
                .target(OrderStatus.COMPLETED)
                .guard(not(paymentGuard))
                .event(OrderEvent.PAYMENT)
                .and()
                // (5) 审核不通过 待审核 -》 取消
                .withExternal()
                .source(OrderStatus.AWAITING_AUDIT)
                .target(OrderStatus.CANCELED)
                .event(OrderEvent.CANCEL)
                .and()
                // 先付款 支付  待支付 -> 取消
                .withExternal()
                .source(OrderStatus.AWAITING_PAYMENT)
                .target(OrderStatus.CANCELED)
                .guard(paymentGuard)
                .event(OrderEvent.CANCEL)
                .and()
                // (5) 待确认前取消 待确认 -》 取消
                .withExternal()
                .source(OrderStatus.AWAITING_CONFIRM)
                .target(OrderStatus.CANCELED)
                .event(OrderEvent.CANCEL);
    }

    private Guard<OrderStatus, OrderEvent> not(Guard<OrderStatus, OrderEvent> guard) {
        return context -> !guard.evaluate(context);
    }


}

