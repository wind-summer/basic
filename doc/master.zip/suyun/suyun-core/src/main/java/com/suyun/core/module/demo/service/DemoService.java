package com.suyun.core.module.demo.service;

import com.suyun.core.module.demo.entity.Demo;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 示例Demo 服务类
 * </p>
 *
 * @author caosg
 * @since 2017-11-23
 */
public interface DemoService extends IService<Demo> {
    void saveDemoWithJson(Demo demo);

    void testOracle();
}
