package com.suyun.core.module.bidding.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.suyun.core.module.bidding.enums.BiddingRecordStatus;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.sys.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 竞价记录表
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName(value = "sy_bidding_record",resultMap = "BaseResultMap")
public class BiddingRecord extends BaseEntity<BiddingRecord> {

    private static final long serialVersionUID = 1L;

    /**
     * 关联竞价规则产品表id
     */
	@TableField("bidding_product_id")
	@NotNull(message = "竞价产品ID不能为空")
	private Long biddingProductId;
    /**
     * 竞价单号
     */
	@TableField("order_code")
	private String orderCode;
    /**
     * 竞价人
     */
	@TableField("bidder")
	private String bidder;
    /**
     * 关联customerId
     */
	@TableField("customer_id")
	private Long customerId;
    /**
     * 竞价数量
     */
	@TableField("bidding_quantity")
	@NotNull(message = "竞价数量不能为空")
	private Long biddingQuantity;
    /**
     * 成交数量
     */
	@TableField("deal_quantity")
	private Long dealQuantity;
    /**
     * 竞价
     */
	@TableField("bidding_price")
	@NotNull(message = "竞价价格不能为空")
	private BigDecimal biddingPrice;
    /**
     * 竞价状态:0:已关闭 1：竞价中 2：竞价成功 3：竞价失败
     */
	@TableField("bidding_status")
	private BiddingRecordStatus biddingStatus;
    /**
     * 保证金
     */
	@TableField("earnest_money")
	private BigDecimal earnestMoney;
    /**
     * 创建时间
     */
	@TableField(value = "create_date",fill = FieldFill.INSERT)
	private Date createDate;
    /**
     * 修改时间
     */
	@TableField(value = "update_date",fill = FieldFill.UPDATE)
	private Date updateDate;

	/**
	 * 绑定sku对象
	 */
	@TableField(exist = false)
	private Sku sku;

}
