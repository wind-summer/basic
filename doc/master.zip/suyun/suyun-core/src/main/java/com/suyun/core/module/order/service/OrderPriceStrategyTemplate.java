package com.suyun.core.module.order.service;

import com.suyun.core.module.order.entity.Order;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单价格计算，混合模板策略模式
 * @date 2017/12/7 下午3:34
 */
public abstract class OrderPriceStrategyTemplate {

   protected abstract boolean isSupport(Order order);

   protected abstract void calculate(Order order);

   public  void  price(Order order){
       if(isSupport(order)) {
           calculate(order);
       }
   }
}
