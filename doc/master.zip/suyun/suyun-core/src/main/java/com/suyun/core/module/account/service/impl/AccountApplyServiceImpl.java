package com.suyun.core.module.account.service.impl;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.suyun.common.exception.BizException;
import com.suyun.common.sms.*;
import com.suyun.common.utils.ConfigConstant;
import com.suyun.common.utils.RedisUtils;
import com.suyun.common.utils.SnowFlakeIdGenerator;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.module.account.dao.AccountApplyDao;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.entity.AccountApply;
import com.suyun.core.module.account.entity.AccountTrans;
import com.suyun.core.module.account.enums.*;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.account.service.AccountConstant;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.account.service.AccountTransService;
import com.suyun.core.module.account.service.dto.ApplyDTO;
import com.suyun.core.module.account.service.dto.RechargeAndDrawDTO;
import com.suyun.core.module.account.service.dto.RechargeDTO;
import com.suyun.core.module.account.service.dto.WithDrawApplyDTO;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.sys.entity.SysUser;
import com.suyun.core.sys.service.SysConfigService;
import com.suyun.core.sys.service.dto.PlatformBankDTO;
import com.suyun.core.utils.CurrentUserUtils;
import com.suyun.core.utils.LoginUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;

import static com.suyun.core.module.account.enums.TransReason.*;
import static com.suyun.core.module.account.service.AccountConstant.AWAITING_CONFIRM_RECHARGE_KEY;
import static java.util.Optional.ofNullable;

/**
 * <p>
 * 账户业务实现类
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@Service
@AllArgsConstructor
@Slf4j

public class AccountApplyServiceImpl extends ServiceImpl<AccountApplyDao, AccountApply> implements AccountApplyService {

    private final CustomerService customerService;

    private final SnowFlakeIdGenerator snowFlakeIdGenerator;

    private final AccountService accountService;

    private final AccountTransService accountTransService;

    private final ObjectMapper objectMapper;

    private final SysConfigService sysConfigService;

    private final MsgService msgService;

    private final ApplicationProperties applicationProperties;

    private final RedisUtils redisUtils;

    private  final SmsProperties smsProperties;

    /**
     * 客户充值申请
     *
     * @param applyDTO
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createApply(ApplyDTO applyDTO) {
        if (applyDTO.getAmount().compareTo(applicationProperties.getAccount().maxAmount) > 0) {
            new BizException("您充值金额超出系统规定上限");
        }
        //客户信息
        CustomerDTO customer = customerService.getCustomer(CurrentUserUtils.getLogin().getCustomerId());
        if(customer.getCustomer().getStatus()!= CustomerStatusEnum.SUCCESS){
            throw new BizException("您的账号未认证，暂不支持充值业务");
        }
        if (redisUtils.get(AWAITING_CONFIRM_RECHARGE_KEY + CurrentUserUtils.getLogin().getCustomerId()) == null ||
                !applyDTO.getPaymentCode().equals(redisUtils.get(AWAITING_CONFIRM_RECHARGE_KEY + CurrentUserUtils.getLogin().getCustomerId()))) {
            throw new BizException("支付编码不正确,或者付款识别码已过期，过期时间为10分钟,请刷新页面");
        }
        //保留2位小数四舍五入
        applyDTO.setAmount(applyDTO.getAmount().setScale(2, BigDecimal.ROUND_HALF_UP));
        Long currentCustomerId = CurrentUserUtils.getLogin().getCustomerId();
        AccountApply accountApply = new AccountApply().setCustomerId(currentCustomerId)
                .setApplyCode(new StringBuilder().append(AccountConstant.APPLY_CODE_PREFIX).append(snowFlakeIdGenerator.nextId()).toString())
                .setAmount(applyDTO.getAmount())
                .setStatus(ApplyStatus.WAIT_APPLY)
                .setCreateAt(new Date())
                .setPicture(applyDTO.getPicture());
        AccountTrans trans = new AccountTrans().setTransCode(accountApply.getApplyCode())
                .setTransType(TransType.INCOME_TRANS).setReasonType(OFFLINE_TOPUP)
                .setAmount(applyDTO.getAmount())
                .setCreateAt(new Date())
                .setCustomerId(currentCustomerId).setPaymentCode(applyDTO.getPaymentCode())
                .setStatus(TransStatus.APPLY_TRANS)
                .setReceiveCompany(sysConfigService.getConfigObject(ConfigConstant.PLATFORM_BANK_KEY, PlatformBankDTO.class).getBankName());
        //充值金额和余额及之前充值未审核的总金额小于5000RMB
        BigDecimal count = accountTransService.selectList(new EntityWrapper<AccountTrans>()
                .eq("customer_id", CurrentUserUtils.getLogin().getCustomerId())
                .eq("status", TransStatus.APPLY_TRANS).eq("reason_type", OFFLINE_TOPUP))
                .stream().map(AccountTrans::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        Account account = accountService.selectOne(new EntityWrapper<Account>().eq("customer_id", currentCustomerId));
        if (account == null) {
            Account accounts = new Account().setAccountCode(AccountConstant.ACCOUNT_CODE_PREFIX + snowFlakeIdGenerator.nextId())
                    .setAccountType(AccountType.CASH_ACCOUNT)
                    .setStatus(AccountStatus.ACTIVATE_STATUS)
                    .setCreateAt(new Date())
                    .setCustomerId(currentCustomerId);
            //创建账户
            accountService.createAccount(accounts);
            //创建交易明细
            accountTransService.insert(trans.setAccountId(accounts.getId()));
            //创建交易申请
            this.insert(accountApply.setAccountId(accounts.getId()));
        } else {
            if (account.getStatus().getValue() != 0) {
                //冻结止收
                throw new BizException("您的账户不在激活状态");
            }
            if ((account.getAmount().add(count).add(applyDTO.getAmount())).compareTo(applicationProperties.getAccount().maxAmount) < 1) {
                //创建收支明细
                accountTransService.insert(trans.setAccountId(account.getId()).setBalance(account.getAmount()));
                //创建收支申请记录
                this.insert(accountApply.setAccountId(account.getId()));
            } else {
                throw new BizException("您充值金额超出系统规定范围,您最多能充值"+applicationProperties.getAccount().getMaxAmount().subtract(account.getAmount().add(count))+"元");
            }
        }
        redisUtils.delete(AWAITING_CONFIRM_RECHARGE_KEY + CurrentUserUtils.getLogin().getCustomerId());
    }

    /**
     * 依据applyID查询申请信息
     *
     * @param applyId
     * @return
     */
    @Override
    @Transactional(readOnly = true, rollbackFor = Exception.class)
    public RechargeAndDrawDTO findAccountApplyById(Long applyId) {
        return Optional.ofNullable(this.selectOne(new EntityWrapper<AccountApply>().eq("id", applyId)))
                .map(new Function<AccountApply, RechargeAndDrawDTO>() {
                    @Override
                    public RechargeAndDrawDTO apply(AccountApply apply) {
                        AccountTrans accountTrans = accountTransService.selectOne(new EntityWrapper<AccountTrans>().eq("trans_code", apply.getApplyCode()));
                        //如果是充值返回前端充值显示信息
                        Customer customer = customerService.selectOne(new EntityWrapper<Customer>().eq("id", apply.getCustomerId()));
                        RechargeAndDrawDTO rechargeAndDrawDTO = new RechargeAndDrawDTO().setStatus(apply.getStatus()).setPicture(apply.getPicture());
                        try {
                            //系统判断该申请是否已经超过2小时
                            Long time = System.currentTimeMillis() - applicationProperties.getAccount().getWithdrawWaitTime() * 1000;
                            if (time > apply.getCreateAt().getTime()) {
                                rechargeAndDrawDTO.setCanCancel(false);
                            } else {
                                rechargeAndDrawDTO.setCanCancel(true);
                            }
                            if (accountTrans.getTransType().getValue() == 0 && accountTrans.getReasonType().getValue() == 0) {
                                return rechargeAndDrawDTO.setPhone(customer.getPrimaryPhone()).setCustomerName(customer.getName())
                                        .setPaymentCode(accountTrans.getPaymentCode()).setAmount(apply.getAmount()).setIdentification(1)
                                        .setId(apply.getId()).setAcccountCode(accountService.selectOne(new EntityWrapper<Account>().eq("id", apply.getAccountId())).getAccountCode());
                            } else if (accountTrans.getTransType().getValue() == 1 && accountTrans.getReasonType().getValue() == 1) {
                                //如果是提现放入客户银行信息
                                return rechargeAndDrawDTO.setBankAttributeDTO(customerService.getBank(apply.getCustomerId())).setAmount(apply.getAmount()).setId(apply.getId()).setIdentification(2);
                            }
                        } catch (Exception e) {
                            throw new BizException("不在业务范围内");
                        }
                        throw new BizException("不在业务范围内");
                    }
                }).orElseThrow(() -> new BizException("申请:" + applyId + "不存在"));
    }


    /**
     * 客户提现申请
     *
     * @param withDrawApplyDTO
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void withDraw(WithDrawApplyDTO withDrawApplyDTO) {
        String applycode = new StringBuilder().append(AccountConstant.APPLY_CODE_PREFIX).append(snowFlakeIdGenerator.nextId()).toString();
        //保留2位小数四舍五入
        withDrawApplyDTO.setAmount(withDrawApplyDTO.getAmount().setScale(2, BigDecimal.ROUND_HALF_UP)).setCustomerId(CurrentUserUtils.getLogin().getCustomerId());
        if (msgService.verifyRandomCode(new VerificationDTO().setBizType(BizType.OTHER).setVerificationCode(withDrawApplyDTO.getCode()).setPhone(CurrentUserUtils.getLogin().getMobileNo()))) {
            Account account = accountService.findAccountByCustomerId(withDrawApplyDTO.getCustomerId());
            //冻结至付
            if (!account.getStatus().equals(AccountStatus.ACTIVATE_STATUS)) {
                throw new BizException("账户不是激活状态！");
            }
            if (account.getAvaliableAmount().compareTo(withDrawApplyDTO.getAmount()) >= 0) {
                if (accountTransService.insert(new AccountTrans().setTransCode(applycode)
                        .setCreateAt(new Date()).setStatus(TransStatus.APPLY_TRANS).setCustomerId(withDrawApplyDTO.getCustomerId())
                        .setAmount(withDrawApplyDTO.getAmount()).setAccountId(account.getId())
                        .setReasonType(WITH_DRAW).setTransType(TransType.PAY_TRANS)
                        .setReceiveCompany(customerService.getCustomer(withDrawApplyDTO.getCustomerId()).getCustomer().getName())
                        .setBalance(account.getAmount().subtract(withDrawApplyDTO.getAmount())))) {
                    this.insert(new AccountApply().setCustomerId(withDrawApplyDTO.getCustomerId())
                            .setApplyCode(applycode).setAmount(withDrawApplyDTO.getAmount()).setStatus(ApplyStatus.WAIT_APPLY)
                            .setCreateAt(new Date()).setAccountId(account.getId()));
                    account.setAmount(account.getAmount().subtract(withDrawApplyDTO.getAmount())).setAvaliableAmount(account.getAvaliableAmount().subtract(withDrawApplyDTO.getAmount())).setUpdateAt(new Date());
                    accountService.updateAllColumnById(account);
                } else {
                    throw new BizException("交易记录创建失败");
                }
            } else {
                throw new BizException("您的账户可用余额不足，请先充值");
            }
        } else {
            throw new BizException("验证码已失效");
        }
    }

    /**
     * 账户冻结部分金额
     *
     * @param accountId
     * @param freeze
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean freeze(Long accountId, BigDecimal freeze, Integer reason) {
        return Optional.ofNullable(accountService.selectOne(new EntityWrapper<Account>().eq("id", accountId)))
                .map((Account account) -> {
                    //冻结金额必须大于0的正数
                    if (freeze.compareTo(BigDecimal.ZERO) == -1) {
                        throw new BizException("您的冻结金额是负数");
                    }
                    if (account.getStatus().getValue() != 0) {
                        //冻结止付
                        throw new BizException("该账户不在激活状态");
                    }
                    if ((account.getAmount().subtract(account.getFreezeAmount())).compareTo(freeze) >= 0) {
                        //创建交易记录
                        AccountTrans accountTrans = new AccountTrans();
                        accountTrans.setStatus(TransStatus.SUCCESS_TRANS);
                        accountTrans.setAccountId(accountId);
                        accountTrans.setTransCode(AccountConstant.ACCOUNT_DJ + snowFlakeIdGenerator.nextId());
                        accountTrans.setAmount(freeze);
                        accountTrans.setCreateAt(new Date());
                        accountTrans.setCustomerId(account.getCustomerId());
                        accountTrans.setBalance(account.getAmount());
                        //4为竞拍冻结
                        if (reason != null && reason.equals(4)) {
                            accountTrans.setReasonType(BIDD_TRANS);
                            accountTrans.setRemark("竞拍客户:" + LoginUtils.getLoginName());
                            accountTrans.setStatus(TransStatus.FREEZE_TRANS);
                            accountTrans.setTransType(TransType.CASH_TRANS);
                        }
                        if (accountTransService.insert(accountTrans)) {
                            //冻结客户账户部分金额
                            return accountService.updateById(account.setFreezeAmount(account.getFreezeAmount().add(freeze)).setUpdateAt(new Date())
                                    .setAvaliableAmount(account.getAvaliableAmount().subtract(freeze)));
                        } else {
                            throw new BizException("账户交易记录创建异常");
                        }
                    } else {
                        throw new BizException("账户可用余额不足，无法满足冻结金额");
                    }
                }).orElseThrow(() -> new BizException("客户账户：" + accountId + "+不存在+"));
    }

    /**
     * 解冻
     *
     * @param accountId
     * @param unfreeze
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean unfreeze(Long accountId, BigDecimal unfreeze, Integer reason) {
        return Optional.ofNullable(accountService.selectOne(new EntityWrapper<Account>().eq("id", accountId)))
                .map(new Function<Account, Boolean>() {
                    @Override
                    public Boolean apply(Account account) {
                        //解冻金额是必须大于0的正数
                        if (unfreeze.compareTo(BigDecimal.ZERO) <= 0) {
                            throw new BizException("您的解冻金额是负数");
                        }
                        if (account.getAmount().subtract(account.getAvaliableAmount()).compareTo(unfreeze) >= 0x0) {
                            String username = LoginUtils.getLoginName();
                            //创建交易记录
                            AccountTrans accountTrans = new AccountTrans().setStatus(TransStatus.SUCCESS_TRANS).setAccountId(accountId).setTransCode(AccountConstant.ACCOUNT_DJ + snowFlakeIdGenerator.nextId())
                                    .setAmount(unfreeze).setCreateAt(new Date())
                                    .setCustomerId(account.getCustomerId())
                                    .setBalance(account.getAmount());
                            //4为竞拍冻结
                            if (reason != null && reason.equals(TransReason.BIDD_TRANS.getValue())) {
                                accountTrans.setReasonType(BIDD_TRANS).setRemark("竞拍客户:" + username).setStatus(TransStatus.UNFREEZE_TRANS).setTransType(TransType.CASH_TRANS);
                            }
                            return accountTransService.insert(accountTrans) && accountService.updateById(account.setFreezeAmount(account.getFreezeAmount().subtract(unfreeze))
                                    .setUpdateAt(new Date()).setAvaliableAmount(account.getAvaliableAmount().add(unfreeze)));
                        }
                        throw new BizException("账户已冻结金额不足，无法满足解冻金额");
                    }
                }).orElseThrow(() -> new BizException("客户账户：" + accountId + "+不存在+"));
    }

    /**
     * 冻结账户
     *
     * @param accountId
     */
    @Override
    public void frost(Long accountId) {
        Account account = accountService.selectOne(new EntityWrapper<Account>().eq("id", accountId));
        if (account != null) {
            accountService.updateAllColumnById(account.setStatus(AccountStatus.FREEZE_STATUS).setUpdateAt(new Date()));
        }
    }

    /**
     * 解冻账户
     *
     * @param accountId
     */
    @Override
    public void unfrost(Long accountId) {
        Account account = accountService.selectOne(new EntityWrapper<Account>().eq("id", accountId));
        if (account != null) {
            accountService.updateAllColumnById(account.setStatus(AccountStatus.ACTIVATE_STATUS).setUpdateAt(new Date()));
        }
    }

    /**
     * 调整额度
     *
     * @param accountId
     * @param adjust
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean adjust(Long accountId, BigDecimal adjust) {
        return ofNullable(accountService.selectOne(new EntityWrapper<Account>().eq("id", accountId)))
                .map(account -> {
                    SysUser sysUser = (SysUser) SecurityUtils.getSubject().getPrincipal();
                    AccountTrans accountTrans = new AccountTrans().setStatus(TransStatus.SUCCESS_TRANS)
                            .setAccountId(accountId).setTransCode(AccountConstant.ACCOUNT_DJ + snowFlakeIdGenerator.nextId())
                            .setTransType(TransType.ADJUSE_TRANS).setAmount(adjust).setCreateAt(new Date())
                            .setCustomerId(account.getCustomerId());
                    if (adjust.compareTo(BigDecimal.ZERO) <= 0 && adjust.compareTo(account.getAvaliableAmount()) <= 0) {
                        //创建交易记录
                        accountTrans.setRemark("后台操作人：" + sysUser.getUsername() + "，调整类型：总额下调");
                        if (accountTransService.insert(accountTrans)) {
                            //总额下调
                            return accountService.updateById(account.setAmount(account.getAmount().subtract(adjust)).setUpdateAt(new Date())
                                    .setAvaliableAmount(account.getAvaliableAmount().subtract(adjust)));
                        }
                    } else if (adjust.compareTo(BigDecimal.ZERO) >= 0) {
                        accountTrans.setRemark("后台操作人：" + sysUser.getUsername() + "，调整类型：总额上调");
                        if (accountTransService.insert(accountTrans)) {
                            //总额上调
                            return accountService.updateById(account.setAmount(account.getAmount().add(adjust)).setUpdateAt(new Date())
                                    .setAvaliableAmount(account.getAvaliableAmount().add(adjust)));
                        }

                    }
                    throw new BizException("调整金额失败");
                }).orElseThrow(() -> new BizException("客户账户：" + accountId + "+不存在+"));
    }

    /**
     * 后台充值审核成功
     *
     * @param applyId
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean success(Long applyId) {
        return ofNullable(this.selectOne(new EntityWrapper<AccountApply>().eq("id", applyId)))
                .map(this::apply).orElseThrow(() -> new BizException("充值申请ID：{" + applyId + "}+不存在+"));
    }

    /**
     * 后台充值审核失败
     *
     * @param applyId
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean failure(Long applyId) {
        return ofNullable(this.selectOne(new EntityWrapper<AccountApply>().eq("id", applyId)))
                .map(this::applyFailure).orElseThrow(() -> new BizException("充值申请ID：{" + applyId + "}+不存在+"));
    }

    /**
     * 提现后台审核
     *
     * @param applyId
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean withDrawApply(Long applyId) {
        return ofNullable(this.selectOne(new EntityWrapper<AccountApply>().eq("id", applyId)))
                .map(this::withApplyException).orElseThrow(() -> new BizException("充值申请：" + applyId + "+不存在+"));

    }


    /**
     * 条件查询客户充值或者提现申请分页列表后台
     *
     * @param map
     * @param page
     * @return
     */
    @Override
    public Page<AccountApply> findAccountPageByCondition(Map<String, Object> map, Page<AccountApply> page) {
        if (map.containsKey("parameter")) {
            map.put("parameter", map.get("parameter").toString().replace(" ", ""));
        }
        return ofNullable(baseMapper.findAppalyPage(map, page)).map((List<AccountApply> apply) -> {
            apply.forEach(this::accept);
            return page.setRecords(apply);
        }).orElseThrow(() -> new BizException("暂无数据"));
    }

    /**
     * 客户id冻结账户部分金额  竞拍
     *
     * @param customerId
     * @param freeze
     * @return
     * @throws Exception
     */
    @Override
    public boolean freezeByCustomerId(Long customerId, BigDecimal freeze, Integer reason) {
        return this.freeze(accountService.selectOne(new EntityWrapper<Account>().eq("customer_id", customerId)).getId(), freeze, reason);
    }

    /**
     * 客户id解冻账户部分金额  竞拍
     *
     * @param customerId
     * @param freeze
     * @return
     * @throws Exception
     */
    @Override
    public boolean unFreezeByCustomerId(Long customerId, BigDecimal freeze, Integer reason) {
        return this.unfreeze(accountService.selectOne(new EntityWrapper<Account>().eq("customer_id", customerId)).getId(), freeze, reason);
    }

    /**
     * 充值申请未受理个数
     *
     * @return
     */
    @Override
    public Integer rechargeCount() {
        return baseMapper.rechargeCount();
    }

    /**
     * 提现申请未受理个数
     *
     * @return
     */
    @Override
    public Integer withDrawCount() {
        return baseMapper.withDrawCount();
    }

    /**
     * 充值后台审核通过业务处理
     *
     * @param apply
     * @return
     */
    private Boolean applySuccess(AccountApply apply) throws JsonProcessingException {
        if (!apply.getStatus().equals(ApplyStatus.WAIT_APPLY)) {
            throw new BizException("当前业务已经处理完毕");
        }
        apply.setStatus(ApplyStatus.PASS_APPLY).setUpdateAt(new Date()).setUpdateBy(LoginUtils.getLoginName());
        Account account = accountService.selectOne(new EntityWrapper<Account>().eq("id", apply.getAccountId()));
        AccountTrans accountTrans = accountTransService.selectOne(new EntityWrapper<AccountTrans>().eq("trans_code", apply.getApplyCode())).setUpdateAt(new Date());
        if (!Objects.equals(OFFLINE_TOPUP, accountTrans.getReasonType())) {
            throw new BizException("不是充值申请，不符合流程");
        }
        //充值金额和可用余额值得和不能超过5000RMB
        if ((account.getAvaliableAmount().add(accountTrans.getAmount())).compareTo(applicationProperties.getAccount().maxAmount) > 0) {
            throw new BizException("充值金额和账户可用余额值不能超过" + applicationProperties.getAccount().maxAmount + "元");
        }
        String bankdesc = objectMapper.writeValueAsString(customerService.getBank(apply.getCustomerId()));
        //发送短信验证码至客户手机rechargeTemplateCode
        MsgDTO msgDTO=new MsgDTO();
        Set<String> set=new HashSet<>();
        Customer customer=customerService.selectOne(new EntityWrapper<Customer>().eq("id",apply.getCustomerId()));
        set.add(customer.getPrimaryPhone());
        msgDTO.setTemplateCode(smsProperties.getRechargeTemplateCode()).setBizType(BizType.OTHER).setPhones(set);
        SendSmsResponse SendSmsResponse=msgService.sendSms(msgDTO);
        return !(!this.updateById(apply) || !accountTransService.updateById(accountTrans.setStatus(TransStatus.SUCCESS_TRANS).setAttributes(bankdesc)) || !accountService.updateById(account.setAmount(account.getAmount().add(apply.getAmount()))
                .setAvaliableAmount(account.getAmount().subtract(account.getFreezeAmount()))
                .setUpdateAt(new Date())));
    }

    /**
     * 充值后台审核不通过业务处理
     *
     * @param apply
     * @return
     */
    private Boolean applyFailure(AccountApply apply) {
        if (!Objects.equals(ApplyStatus.WAIT_APPLY, apply.getStatus())) {
            throw new BizException("当前业务已经处理完毕");
        }
        apply.setStatus(ApplyStatus.FAIL_APPLY).setUpdateAt(new Date()).setUpdateBy(LoginUtils.getLoginName());
        AccountTrans accountTrans = accountTransService.selectOne(new EntityWrapper<AccountTrans>().eq("trans_code", apply.getApplyCode())).setUpdateAt(new Date());
        if (accountTrans != null) {
            if (!accountTrans.getReasonType().equals(OFFLINE_TOPUP)) {
                throw new BizException("不是充值申请，不符合流程");
            }
            return this.updateById(apply) && accountTransService.updateById(accountTrans.setStatus(TransStatus.FAILURE_TRANS));
        } else {
            throw new BizException("收支明细记录不存在");
        }
    }

    /**
     * 后台提现业务处理
     *
     * @param apply
     * @return
     * @throws JsonProcessingException
     */
    private Boolean withDraw(AccountApply apply) throws JsonProcessingException {
        AccountTrans accountTrans = accountTransService.selectOne(new EntityWrapper<AccountTrans>().eq("trans_code", apply.getApplyCode())).setUpdateAt(new Date());
        if (!apply.getStatus().equals(ApplyStatus.WAIT_APPLY)) {
            throw new BizException("该审核流程已经处理完毕，禁止重复提交");
        }
        if (!accountTrans.getReasonType().equals(WITH_DRAW)) {
            throw new BizException("不是提现申请，不符合流程");
        }

        Customer customer=customerService.selectOne(new EntityWrapper<Customer>().eq("id",apply.getCustomerId()));
        MsgDTO msgDTO=new MsgDTO();
        Set<String> set=new HashSet<>();
        set.add(customer.getPrimaryPhone());
        Map<String,String> map=new HashMap<>();
        map.put("money",apply.getAmount().setScale(2).toString());
        msgDTO.setTemplateCode(smsProperties.getWithDrawTemplateCode()).setBizType(BizType.OTHER).setPhones(set).setParams(map);
        SendSmsResponse SendSmsResponse=msgService.sendSms(msgDTO);
        apply.setStatus(ApplyStatus.PASS_APPLY).setUpdateAt(new Date()).setUpdateBy(LoginUtils.getLoginName());
            return this.updateById(apply) && accountTransService.updateById(accountTrans.setStatus(TransStatus.SUCCESS_TRANS)
                    .setAttributes(objectMapper.writeValueAsString(customerService.getBank(apply.getCustomerId()))));
    }

    /**
     * 后台充值审核成功
     *
     * @param apply
     * @return
     */
    private Boolean apply(AccountApply apply) {
        try {
            return applySuccess(apply);
        } catch (JsonProcessingException e) {
            throw new BizException("客户银行信息转换异常");
        }
    }

    /**
     * 条件查询客户充值或者提现申请分页列表后台业务处理
     *
     * @param applyItem
     */
    private void accept(AccountApply applyItem) {
        AccountTrans accountStatus = accountTransService.selectOne(new EntityWrapper<AccountTrans>().eq("trans_code", applyItem.getApplyCode()));
        applyItem.setReasonType(accountStatus.getReasonType());
        applyItem.setAvaliableAmount(accountStatus.getBalance());
    }

    /**
     * 后台提现审核成功
     *
     * @param apply
     * @return
     */
    private Boolean withApplyException(AccountApply apply) {
        try {
            return withDraw(apply);
        } catch (JsonProcessingException e) {
            throw new BizException("企业银行信息数据转化异常");
        }
    }

    /**
     * 账户充值前查看账户信息
     *
     * @return
     */
    @Override
    public RechargeDTO findRecharge() {
        CustomerLogin customerLogin = CurrentUserUtils.getLogin();
        if(redisUtils.get(AWAITING_CONFIRM_RECHARGE_KEY+ CurrentUserUtils.getLogin().getCustomerId())==null){
            redisUtils.set(AWAITING_CONFIRM_RECHARGE_KEY + CurrentUserUtils.getLogin().getCustomerId()
                       , RandomStringUtils.randomNumeric(6)
                       ,applicationProperties.getAccount().getInvalidTime());
        }
        BigDecimal count = accountTransService.selectList(new EntityWrapper<AccountTrans>()
                .eq("customer_id", CurrentUserUtils.getLogin().getCustomerId())
                .eq("status", TransStatus.APPLY_TRANS).eq("reason_type", OFFLINE_TOPUP))
                .stream().map(AccountTrans::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        RechargeDTO recharge = new RechargeDTO().setPhone(customerLogin.getMobileNo()).setPaymentCode(redisUtils.get(AWAITING_CONFIRM_RECHARGE_KEY+ CurrentUserUtils.getLogin().getCustomerId()));
        Optional.ofNullable(accountService.selectOne(new EntityWrapper<Account>().eq("customer_id", CurrentUserUtils.getLogin().getCustomerId())))
                .map(account -> recharge.setId(account.getId()).setAmount(account.getAmount()).setAvaliableAmount(account.getAvaliableAmount())
                .setMaxAmount(applicationProperties.getAccount().getMaxAmount().subtract(count).subtract(account.getAmount()))).orElseGet(() -> {
            accountService.createAccount(customerLogin.getCustomerId());
            return findRecharge();
        });
        if (customerLogin != null) {
            recharge.setPlatformBank(sysConfigService.getConfigObject(ConfigConstant.
                    PLATFORM_BANK_KEY, PlatformBankDTO.class));
        }
        return recharge;
    }
}
