package com.suyun.core.module.article.service;

import com.suyun.core.module.article.entity.ArticleContent;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 文章详细内容 服务类
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
public interface ArticleContentService extends IService<ArticleContent> {

}
