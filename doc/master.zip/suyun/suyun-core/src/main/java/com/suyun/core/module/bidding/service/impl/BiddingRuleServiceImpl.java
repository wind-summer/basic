package com.suyun.core.module.bidding.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.module.bidding.dao.BiddingRuleDao;
import com.suyun.core.module.bidding.entity.BiddingRule;
import com.suyun.core.module.bidding.service.BiddingRuleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@Service
@AllArgsConstructor
@Slf4j
public class BiddingRuleServiceImpl extends ServiceImpl<BiddingRuleDao, BiddingRule> implements BiddingRuleService {

}
