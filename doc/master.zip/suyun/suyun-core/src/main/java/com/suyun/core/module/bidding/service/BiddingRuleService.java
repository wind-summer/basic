package com.suyun.core.module.bidding.service;

import com.suyun.core.module.bidding.entity.BiddingRule;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
public interface BiddingRuleService extends IService<BiddingRule> {

}
