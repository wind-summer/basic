package com.suyun.core.module.account.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.service.dto.AccountDetailDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
public interface AccountDao extends BaseMapper<Account> {

    /**
     * 分页查询账户信息
     *
     * @param map
     * @param page
     * @return
     */
    List<Account> findpage(Map<String, Object> map, Page<Account> page);

}
