package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.common.sms.BizType;
import com.suyun.common.sms.MsgService;
import com.suyun.common.sms.VerificationDTO;
import com.suyun.common.utils.RedisKeys;
import com.suyun.common.utils.RedisUtils;
import com.suyun.common.validator.Assert;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.module.customer.dao.CustomerLoginDao;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.exception.LoginFailException;
import com.suyun.core.module.customer.service.CustomerLoginService;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * 客户登陆信息 服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
@AllArgsConstructor
@Slf4j
public class CustomerLoginServiceImpl extends ServiceImpl<CustomerLoginDao, CustomerLogin> implements CustomerLoginService {

    private final ApplicationProperties applicationConfig;

    private final CustomerService customerService;

    private final CustomerLoginDao customerLoginDao;

    private final MsgService msgService;

    private final RedisUtils redisUtils;


    /**
     * 登陆
     *
     * @param login
     * @param password
     * @return 客户详细信息
     */
    @Override
    public CustomerDTO login(String login, String password) {
        log.info(" Login check by login:{} ,password:{}",login,password);
        Assert.isBlank(login, "登陆账号不能为空");
        Assert.isBlank(password, "密码不能为空");
        return Optional.ofNullable(this.queryByLogin(login))
                .map(customerLogin ->{
                    //获取当前用户是否被禁止登录
                    String loginStr = redisUtils.get(RedisKeys.getProhibitLoginRedisKey()+"_"+ login);
                    if(null!=loginStr){
                        throw new LoginFailException("您当前帐号密码输入错误超过"+applicationConfig.getSecurity().getErrorNum()+"次，禁止登录一小时");
                    }

                    //判断是否被锁定和密码是否匹配
                    if(!customerLogin.getActive()|| !customerLogin.getPassword().equals(DigestUtils.md5Hex(password))){
                        this.addErrorLogin(login);
                        throw new LoginFailException();
                    }
                    CustomerDTO customerDTO = customerService.getCustomer(customerLogin.getCustomerId()).setLogin(customerLogin);
                    if(customerDTO.getCustomer().getStatus().equals(CustomerStatusEnum.FROZEN)){
                        throw new LoginFailException("您当前帐号已冻结，请联系客服");
                    }else{
                        return customerDTO;
                    }
                }).orElseThrow(LoginFailException::new) ;

    }

    /**
     * 手机验证码登录
     * @param verificationDTO
     * @return
     */
    @Override
    public CustomerDTO phoneLogin(VerificationDTO verificationDTO){
        log.debug(" PhoneLogin check by verificationDTO:{}",verificationDTO);
        Assert.isNull(verificationDTO.getPhone(),"手机号码不能为空");
        Assert.isNull(verificationDTO.getVerificationCode(),"验证码不能为空");
        return Optional.ofNullable(this.queryByLoginPhone(verificationDTO.getPhone()))
                .map(customerLogin ->{
                    verificationDTO.setBizType(BizType.LOGIN);
                    //判断验证码输入是否正确
                    if(!msgService.verifyRandomCode(verificationDTO)){
                        throw new LoginFailException("您输入的验证码有误请重新输入");
                    }
                    CustomerDTO customerDTO = customerService.getCustomer(customerLogin.getCustomerId()).setLogin(customerLogin);
                    if(customerDTO.getCustomer().getStatus().equals(CustomerStatusEnum.FROZEN)){
                        throw new LoginFailException("您当前帐号已冻结，请联系客服。");
                    }else{
                        return customerDTO;
                    }
                }).orElseThrow(LoginFailException::new) ;
    }


    /**
     * 找回密码
     * @param login
     * @param phone
     * @param paw
     */
    @Override
    public void backPassword(String login,String phone,String paw){
        if(this.checkPhone(login,phone)){
            customerLoginDao.backPassword(phone,DigestUtils.md5Hex(paw));
        }
    }


    /**
     * 校验手机号码与帐号是否匹配
     * @param login
     * @param phone
     * @return
     */
    @Override
    public boolean checkPhone(String login,String phone){
        CustomerLogin customerLogin;
        customerLogin = this.queryByLogin(login);
        if(null == customerLogin){
            customerLogin = this.queryByLoginPhone(login);
        }
        if(null == customerLogin){
            throw new LoginFailException("当前帐号/手机号不存在");
        }

        if(null == this.queryByLoginPhone(phone)){
            throw new LoginFailException("当前手机号码不存在");
        }

        if(!customerLogin.getMobileNo().equals(phone)){
            throw new LoginFailException("当前手机号码与账号不匹配");
        }

        return true;
    }

    /**
     * 修改密码
     * @param id
     * @param paw
     * @return
     */
    @Override
    public void updatePassword(Long id,String paw){
        if(null != this.selectOne(new EntityWrapper<CustomerLogin>().eq("id",id))){
            customerLoginDao.updatePassword(id,DigestUtils.md5Hex(paw));
        }else{
            throw new LoginFailException("当前用户不存在");
        }
    }

    /**
     * 根据手机号码查询登陆信息
     *
     * @param phone
     * @return 登陆信息
     */
    private CustomerLogin queryByLoginPhone(String phone) {
        Assert.isBlank(phone,"手机号码不能为空");
        return this.selectOne(new EntityWrapper<CustomerLogin>().eq("mobile_no",phone));
    }

    /**
     * 根据登录帐号查询登录信息
     *
     * @param login
     * @return 登录信息
     */
    @Override
    public CustomerLogin queryByLogin(String login){
        Assert.isBlank(login,"登录帐号不能为空");
        return this.selectOne(new EntityWrapper<CustomerLogin>().eq("login",login));
    }

    /**
     * 获取当前客户下所有员工信息
     * @return
     */
    @Override
    public Page<CustomerLogin> getUserAll( CustomerLogin customerLogin,Page<CustomerLogin> page){
        Assert.isNull(CurrentUserUtils.getLogin().getCustomerId(),"登录帐号不能为空");
        page.setRecords(customerLoginDao.getUserAll(CurrentUserUtils.getLogin().getCustomerId(),customerLogin,page));
        return page;
    }

    /**
     * 添加客户员工信息
     * @param customerLogin
     */
    @Override
    public void addCustomerUser(CustomerLogin customerLogin){
        log.info("ADD CustomerUser info:{}",customerLogin);
        //校验如果前端没传客户id则取当前登录人的id
        if(null==customerLogin.getCustomerId()){
            customerLogin.setCustomerId(CurrentUserUtils.getLogin().getCustomerId());
        }else if(customerLogin.getCustomerId().compareTo(CurrentUserUtils.getLogin().getCustomerId())!=0){
            throw new LoginFailException("客户id错误，请重试！");
        }
        //登录帐号设置为手机号码
        customerLogin.setLogin(customerLogin.getMobileNo());
        //将密码加密
        customerLogin.setPassword(DigestUtils.md5Hex(applicationConfig.getSecurity().getDefaultPassword()));
        customerLoginDao.insert(customerLogin);
    }

    /**
     * 修改客户员工信息
     * @param customerLogin
     */
    @Override
    public void updateCustomerUser(CustomerLogin customerLogin){
        //校验id是否存在
        Assert.isNull(customerLogin.getId(),"id不能为空");
        List<CustomerLogin> logins = customerLoginDao.getUserNameIsNull(customerLogin.getUserName());
        if(null != logins && logins.size()>0 && logins.get(0).getId().compareTo(customerLogin.getId())!=0){
            throw new LoginFailException("员工姓名已存在，请重新录入！");
        }
        List<CustomerLogin> customerLogins = customerLoginDao.queryCustomerLoginByPhone(customerLogin.getMobileNo());
        if(null != customerLogins && customerLogins.size()>0 && customerLogins.get(0).getId().compareTo(customerLogin.getId())!=0){
            throw new LoginFailException("手机号码已存在，请重新录入！");
        }
        customerLoginDao.updateById(customerLogin);
    }

    /**
     * 根据id删除客户下员工
     * @param id
     */
    @Override
    public void deleteCustomerUser(Long id){
        if(id.compareTo(CurrentUserUtils.getLogin().getId())==0){
            throw new LoginFailException("请求错误，不能删除当前登录人信息");
        }else{
            customerLoginDao.deleteById(id);
        }
    }

    /**
     * 校验当前手机号码是否存在
     * @param phone
     * @return
     */
    @Override
    public boolean getPhoneIsNull(String phone){
        log.debug("getPhoneIsNull phone {}",phone);
        List<CustomerLogin> customerLogins = customerLoginDao.queryCustomerLoginByPhone(phone);
        return customerLogins.size()==0;
    }

    /**
     * 校验当前帐号是否存在
     * @param login
     * @return
     */
    @Override
    public boolean getLoginIsNull(String login){
        log.debug("getLoginIsNull login {}",login);
        List<CustomerLogin> customerLogins = customerLoginDao.queryCustomerLoginByLogin(login);
        return customerLogins.size() == 0;
    }

    /**
     * 校验员工姓名是否存在
     * @param userName
     * @return
     */
    @Override
    public boolean getUserNameIsNull(String userName){
        log.debug("getUserNameIsNull userName {}",userName);
        List<CustomerLogin> customerLogins = customerLoginDao.getUserNameIsNull(userName);
        return customerLogins.size() == 0;
    }

    /**
     * 登录帐号密码错误超过十次禁止登录
     * @param login
     */
    private void addErrorLogin(String login){
        int errorNum = 1;
        try {
            errorNum = Integer.parseInt(redisUtils.get(RedisKeys.getErrorLoginRedisKey() +"_"+  login));
            if(errorNum>=applicationConfig.getSecurity().getErrorNum()){
                redisUtils.delete(RedisKeys.getErrorLoginRedisKey() +"_"+ login);
                redisUtils.set(RedisKeys.getProhibitLoginRedisKey()+"_"+ login,login,RedisKeys.getProhibitLoginTime());
            }
        }catch (Exception e){
            errorNum = 1;
        }
        if(errorNum<applicationConfig.getSecurity().getErrorNum()){
            redisUtils.set(RedisKeys.getErrorLoginRedisKey()+"_"+ login,errorNum+1,RedisKeys.getErrorLongTime());
        }
    }
}
