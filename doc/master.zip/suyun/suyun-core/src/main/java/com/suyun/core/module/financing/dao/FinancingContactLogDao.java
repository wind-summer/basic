package com.suyun.core.module.financing.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.suyun.core.module.financing.entity.FinancingContactLog;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
public interface FinancingContactLogDao extends BaseMapper<FinancingContactLog> {

}
