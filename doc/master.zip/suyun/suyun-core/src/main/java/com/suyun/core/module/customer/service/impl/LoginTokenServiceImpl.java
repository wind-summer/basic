package com.suyun.core.module.customer.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.module.customer.dao.LoginTokenDao;
import com.suyun.core.module.customer.entity.LoginToken;
import com.suyun.core.module.customer.service.LoginTokenService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@Service
@AllArgsConstructor
@Slf4j
public class LoginTokenServiceImpl extends ServiceImpl<LoginTokenDao, LoginToken> implements LoginTokenService {

   private ApplicationProperties applicationConfig;

    /**
     * 生成token
     *
     * @param loginId 用户登陆ID
     * @return 返回token相关信息
     */
    @Override
    public String createToken(long loginId) {
        //生成一个token
        String token = UUID.randomUUID().toString();
        //当前时间
        Date now = new Date();

        //过期时间
        Date expireTime = new Date(now.getTime() + applicationConfig.getSecurity().getTokenExpire() * 1000);
        log.info("Token:{},expire:{}",token,applicationConfig.getSecurity().getTokenExpire());
        this.insertOrUpdate(
                 Optional.ofNullable(this.selectOne(new EntityWrapper<LoginToken>().eq("customer_login_id",loginId)))
                .map(loginToken -> loginToken.setToken(token).setExpireTime(expireTime).setUpdateTime(now))
                .orElse(new LoginToken().setCustomerLoginId(loginId).setToken(token).setExpireTime(expireTime).setUpdateTime(now)));
        return token;
    }

    /**
     * 根据token查询用户登陆token信息
     *
     * @param token
     * @return
     */
    @Override
    public LoginToken queryByToken(String token) {
        return this.selectOne(new EntityWrapper<LoginToken>().eq("token",token));
    }

    @Override
    public void expireToken(long loginId) {

        //过期时间
        Date expireTime = new Date();
        log.info("Expire Token :{},expire:{}",loginId,expireTime);
        LoginToken loginToken = this.selectOne(new EntityWrapper<LoginToken>().eq("customer_login_id",loginId));
        this.updateById(loginToken.setExpireTime(expireTime).setUpdateTime(expireTime)) ;
    }
}
