package com.suyun.core.module.bidding.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.suyun.core.module.bidding.entity.BiddingRule;
import com.suyun.core.module.bidding.entity.BiddingRuleProduct;
import com.baomidou.mybatisplus.service.IService;
import com.suyun.core.module.bidding.service.dto.BiddingOrderDTO;
import com.suyun.core.module.bidding.service.dto.BiddingProductDTO;
import com.suyun.core.module.bidding.service.dto.CustomerDepositDTO;
import com.suyun.core.module.bidding.service.dto.HotBiddingProductDTO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
public interface BiddingRuleProductService extends IService<BiddingRuleProduct> {

    /**
     * 添加竞价规则和产品关联表数据
     * @param biddingRule
     */
    void addBiddingRuleAndProduct(BiddingRule biddingRule);

    /**
     * 分页查询(sql关联查询)
     * @param param  条件
     * @param page   页面条件
     * @return
     */
    Page<BiddingProductDTO> queryBiddingRuleProduct(Map<String, Object> param, Page<BiddingProductDTO> page);

    /**
     * api分页查询(sql关联查询)
     * @param param  条件
     * @param page   页面条件
     * @return
     */
    Page<BiddingProductDTO> queryBiddingRuleProductApi(Map<String, Object> param, Page<BiddingProductDTO> page);

    /**
     * 根据id获取竞价产品详情
     * @param id
     * @return
     */
    BiddingProductDTO getBiddingProductInfoById(Long id);

    /**
     * 出价竞价产品
     * @param biddingRecord
     */
    void bidBiddingProduct(BiddingRecord biddingRecord);

    /**
     * 检查当前竞价产品，当前用户是否已经交保证金交够
     * @param id
     * , Long quantity, BigDecimal biddingPrice
     * @return
     */
    CustomerDepositDTO checkCustomerDeposit(Long id);

    /**
     * 创建竞价订单
     *
     */
    void createBiddingOrder(BiddingOrderDTO biddingOrderDTO);

    /**
     * 添加围观次数
     */
    void addOnlookers(Long id);

    /**
     * 查询热门竞价产品
     */
    List<HotBiddingProductDTO> queryHotBiddingProduct(Page page);

    /**
     * 检查竞价产品状态
     * @param id
     */
    void checkBiddingProductStatus(Long id);

    /**
     * 竞价活动结束
     * @param id 产品ID
     */
    void endBiddingProduct(Long id);

    /**
     * 是否可以下架sku商品
     * @param skuId SKU   ID
     */
    Boolean isOffShelfSku(Long skuId);
}
