package com.suyun.core.module.account.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.core.module.account.entity.AccountApply;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 账户充值提现申请 Mapper 接口
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
public interface AccountApplyDao extends BaseMapper<AccountApply> {

    /**
     * 条件查询充值提现列表
     *
     * @param map
     * @param page
     * @return
     */
    List<AccountApply> findAppalyPage(Map<String, Object> map, Page<AccountApply> page);

    /**
     * 查询充值待审数量
     *
     * @return
     */
    Integer rechargeCount();

    /**
     * 查询提现待审数量
     *
     * @return
     */
    Integer withDrawCount();

}
