package com.suyun.core.module.customer.service.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.suyun.core.module.customer.enums.CustomerAttributeEnum;
import com.suyun.core.module.customer.enums.IdentificationTypeEnum;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author caosg
 * @Description: 客户工商信息
 * @date 2017/12/1 下午3:31
 */
@Data
@Accessors(chain = true)
@JsonTypeName(value = "CUSTOMER_BUSINESS")
public class BizAttributeDTO extends CustomerAttributeDTO{
    public BizAttributeDTO() {
        super(CustomerAttributeEnum.BUSINESS.getValue());
    }

    /**
     * 单位类型
     */
    private String bizType;
    /**
     * 认证方式
     */
    private IdentificationTypeEnum identificationType;
    /**
     * 营业执照号
     */
    private String organizationRegNo;
    /**
     * 营业执照扫描件
     */
    private String bizLogoUrl;
    /**
     * 组织机构代码
     */
    private String organizationCode;
    /**
     * 组织机构代码扫描件
     */
    private String organizationCodeImg;
    /**
     * 社会信用代码
     */
    private String bizCreditCode;
    /**
     * 税务登记扫描件
     */
    private String taxCertificateImg;

    /**
     * 纳税人识别号
     */
    private String taxCode;

}
