package com.suyun.core.module.order.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.suyun.core.module.order.entity.OrderShipping;
import com.suyun.core.module.order.dao.OrderShippingDao;
import com.suyun.core.module.order.service.OrderShippingService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 发货记录 服务实现类
 * </p>
 *
 * @author caosg
 * @since 2018-03-05
 */
@Service
public class OrderShippingServiceImpl extends ServiceImpl<OrderShippingDao, OrderShipping> implements OrderShippingService {

    @Override
    public List<OrderShipping> getShippingsByOrderCode(String orderCode) {
        return this.selectList(new EntityWrapper<OrderShipping>().eq("order_code",orderCode));

    }

    @Override
    public List<OrderShipping> getShippingsByOrderId(Long orderId) {
        return this.selectList(new EntityWrapper<OrderShipping>().eq("order_id",orderId));
    }
}
