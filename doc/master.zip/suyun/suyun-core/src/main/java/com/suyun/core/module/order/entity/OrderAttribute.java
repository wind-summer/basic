package com.suyun.core.module.order.entity;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@Data
@Accessors(chain = true)
public class OrderAttribute  {

	private String attrName;
	private String attrValue;
	private String attrDescription;


}
