package com.suyun.common.mvc.vm;

import lombok.Data;

/**
 * @author caosg
 * @Description: 参数无效提示信息
 * @date 2017/11/24 上午10:31
 */
@Data
public class ArgumentInvalidVM {
    private String field;
    private Object rejectedValue;
    private String defaultMessage;
}
