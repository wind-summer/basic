package com.suyun.common.mvc.advice;

import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.utils.ApiResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.lang.reflect.Type;

/**
 * @author caosg
 * @Description: 统一封装返回ApiResult对象
 * @date 2017/11/23 上午8:33
 */
@RestControllerAdvice(assignableTypes = { AbstractApiResultController.class } )
@Slf4j
public class ApiResultResponseBodyAdvice  implements ResponseBodyAdvice<Object> {
    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        Type type = returnType.getGenericParameterType();
        boolean noAware = ApiResult.class.equals(type) || String.class.equals(type);
        return !noAware;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
                                  Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request,
                                  ServerHttpResponse response) {
        log.debug("开始封装响应对象:"+returnType.toString());
        return ApiResult.ok(body);
    }
}
