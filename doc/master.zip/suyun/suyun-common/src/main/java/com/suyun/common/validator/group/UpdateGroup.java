package com.suyun.common.validator.group;

/**
 * 更新数据 Group
 * @author csg
 *
 * @date 2017-03-15 21:21
 */

public interface UpdateGroup {

}
