package com.suyun.common.sms;

/**
 * @author caosg
 * @Description: 短信业务场景
 * @date 2017/12/21 上午9:22
 */
public enum BizType {

    REGISTER("0","注册验证码"),
    LOGIN("1","登陆验证码"),
    PASSWORD("2","修改密码验证码"),
    BIND("3","绑定手机号"),
    OTHER("9","通知类短信");

    private String value;
    private String desc;

    BizType(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
