package com.suyun.common.validator.group;

/**
 * 阿里云
 * @author csg
 *
 * @date 2017-03-28 13:51
 */
public interface AliyunGroup {
}
