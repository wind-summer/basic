package com.suyun.common.mvc.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.vm.PageVM;

/**
 * @author caosg
 * @Description: 标识类，继承该类的RestController，返回数据统一使用ApiResult封装
 * @date 2017/11/23 上午9:39
 */
public abstract class AbstractApiResultController {
    /**
     * 转换前端分页信息
     * @param page
     * @return
     */
    protected PageVM toPageVM(Page<?> page){
        return new PageVM(page.getRecords(),page.getTotal(),page.getSize(),page.getCurrent());
    }

}
