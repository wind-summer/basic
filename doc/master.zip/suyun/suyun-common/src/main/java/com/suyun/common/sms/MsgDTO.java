package com.suyun.common.sms;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author caosg
 * @Description: 短信消息
 * @date 2017/12/21 上午9:22
 */
@Data
@Accessors(chain = true)
public class MsgDTO implements Serializable {
    private MsgType msgType=MsgType.TEXT;
    private BizType bizType;
    private Set<String> phones;
    private Map<String,String> params;
    private String bizID;
    private String templateCode;

    public void addParam(String paramKey,String paramValue){
        if(this.params==null) {
            this.params = new HashMap<>(16);
        }
        this.params.put(paramKey,paramValue);
    }

}
