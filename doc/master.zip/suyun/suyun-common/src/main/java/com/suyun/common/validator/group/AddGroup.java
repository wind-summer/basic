package com.suyun.common.validator.group;

/**
 * 新增数据 Group
 * @author csg
 *
 * @date 2017-03-16 0:04
 */
public interface AddGroup {
}
