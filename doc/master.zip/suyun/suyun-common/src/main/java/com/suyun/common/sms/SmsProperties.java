package com.suyun.common.sms;

import lombok.Data;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author caosg
 * @version V1.0
 * @Description: 阿里大于短信配置
 * @date 2017/12/21 上午9:31
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "sms")
public class SmsProperties {

    /**
     * 阿里云大于短信账号
     */
    private String accessKeyId;

    /**
     * 阿里云大于短信密码
     */
    private String accessKeySecret;

    /**
     * 短信签名-可在短信控制台中找到
     */
    private String signName;

    /**
     * 短信验证码失效时间，单位秒
     */
    private int expireTime = 60000;


    /**
     * 短信验证码模板代码
     */
    private String verificationTemplateCode;

    /**
     * 短信验证码模板平台银行账户
     */
    private String platformBankTemplateCode;

    /**
     * 系统用万能验证码
     */
    private String sysVerification;

    /**
     * 验证码长度个数
     */
    private int verificationCodeLength;

    /**
     * 默认发送者
     */
    private String defaultSender;

    /**
     * 订单审核通过短信通知模板代码
     */
    private String orderAuditTemplateCode;

    /**
     * 订单发货短信通知模板代码
     */
    private String orderDeliverTemplateCode;

    /**
     * 订单付款成功短信通知模板代码
     */
    private String orderPayTemplateCode;

    /**
     * 企业审核通过短信通知模版代码
     */
    private String customerAuditSuccess;

    /**
     * 竞价成功短信通知模板代码
     */
    private String bidSuccessTemplateCode;

    /**
     * 竞价失败短信通知模板代码
     */
    private String bidFailTemplateCode;

    /**
     * 后台提现审核通知客户
     */
    private  String withDrawTemplateCode;

    /**
     * 后台充值审核通知客户
     */
    private  String rechargeTemplateCode;

}
