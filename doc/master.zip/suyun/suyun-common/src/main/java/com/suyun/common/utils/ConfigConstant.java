package com.suyun.common.utils;

/**
 * 系统参数相关Key
 * @author csg
 *
 * @date 2017-03-26 10:33
 */
public class ConfigConstant {
    /**
     * 云存储配置KEY
     */
    public final static String CLOUD_STORAGE_CONFIG_KEY = "CLOUD_STORAGE_CONFIG_KEY";

    /**
     * 系统全局配置
     */
    public final static String SYS_GLOBAL_CONFIG_KEY = "SYS_GLOBAL_CONFIG_KEY";

    /**
     * 平台银行信息
     */
    public final static String PLATFORM_BANK_KEY = "PLATFORM_BANK_KEY";
}
