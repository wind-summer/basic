package com.suyun.common.sms;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author caosg
 * @version V1.0
 * @Description: 验证码效验
 * @date 2017/12/21 下午7:32
 */
@Data
@Accessors(chain = true)
public class VerificationDTO {
    private BizType bizType;
    private String phone;
    private String verificationCode;
}
