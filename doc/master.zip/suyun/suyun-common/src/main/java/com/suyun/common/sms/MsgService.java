package com.suyun.common.sms;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.suyun.common.exception.BizException;
import com.suyun.common.utils.RedisKeys;
import com.suyun.common.utils.RedisUtils;
import com.suyun.common.validator.Assert;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;

/**
 * @author caosg
 * @version V1.0
 * @Description: 短信发送
 * @date 2017/12/21 上午9:23
 */
@Component
@Slf4j
public class MsgService {
    @Autowired
    private  SmsProperties smsProperties;
    @Autowired
    private  ObjectMapper objectMapper;
    @Autowired
    private  RedisUtils redisUtils;

    private IAcsClient iAcsClient;

    /**
     * 产品名称:云通信短信API产品,开发者无需替换
     */
    static final String PRODUCT = "Dysmsapi";
    /**
     * 产品域名,开发者无需替换
     */
    static final String DOMAIN = "dysmsapi.aliyuncs.com";

    @PostConstruct
    public void init(){
        //可自助调整超时时间
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");

        //初始化acsClient,暂不支持region化
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", smsProperties.getAccessKeyId(), smsProperties.getAccessKeySecret());
        try {
            DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", PRODUCT, DOMAIN);
        } catch (ClientException e) {
            e.printStackTrace();
            throw new BizException("短信配置初始化错误");
        }
        this.iAcsClient = new DefaultAcsClient(profile);
        log.info("......... 初始化短信网关 。。。。。。。。");
    }

    /**
     * 发送短信
     * @param msgDTO
     * @return
     */
    @Async
    public  SendSmsResponse sendSms(MsgDTO msgDTO) {
        //校验数据是否为空
        Assert.isNull(msgDTO.getPhones(), "手机号码不能为空");

        //组装请求对象-具体描述见控制台-文档部分内容
        SendSmsRequest request = new SendSmsRequest();
        //必填:待发送手机号,支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码
        request.setPhoneNumbers(StringUtils.collectionToCommaDelimitedString(msgDTO.getPhones()));
        //必填:短信签名-可在短信控制台中找到
        request.setSignName(smsProperties.getSignName());
        //必填:短信模板-可在短信控制台中找到
        request.setTemplateCode(msgDTO.getTemplateCode());
        //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
        try {
            request.setTemplateParam(objectMapper.writeValueAsString(msgDTO.getParams()));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new BizException("消息参数JSON转换异常");
        }

        //选填-上行短信扩展码(无特殊需求用户请忽略此字段)
        //request.setSmsUpExtendCode("90997");

        //可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
        request.setOutId(msgDTO.getBizID());

        //hint 此处可能会抛出异常，注意catch
        SendSmsResponse sendSmsResponse = null;
        try {
            sendSmsResponse = iAcsClient.getAcsResponse(request);
        } catch (ClientException e) {
            e.printStackTrace();
            throw new BizException("发送短信错误");
        }
        if(log.isDebugEnabled()) {
            log.debug("发送短信给手机号：{},模板[{}],内容：{},结果：{}", request.getPhoneNumbers(),request.getTemplateCode(), request.getTemplateParam(), sendSmsResponse.getCode());
        }

        return sendSmsResponse;
    }

    /**
     * 发送短信验证码
     * @param msgDTO
     */

    public void sendVerificationCode(MsgDTO msgDTO){
        String randomCode =  RandomStringUtils.randomNumeric(6);
        msgDTO.addParam("code",randomCode);
        msgDTO.getPhones().forEach(phone ->
                redisUtils.set(RedisKeys.getSmsVerificationKey(msgDTO.getBizType().getValue()+phone),randomCode,smsProperties.getExpireTime()));
        msgDTO.setTemplateCode(smsProperties.getVerificationTemplateCode());
        this.sendSms(msgDTO);

    }

    /**
     * 验证验证码是否有效
     * @param verificationDTO
     * @return
     */
    public boolean  verifyRandomCode(VerificationDTO verificationDTO){
        //校验数据是否为空
        Assert.isBlank(verificationDTO.getPhone(), "手机号码不能为空");
        Assert.isBlank(verificationDTO.getVerificationCode(), "验证码不能为空");

        if(verificationDTO.getVerificationCode().equals(smsProperties.getSysVerification())){
            return true;
        }

        String cacheRandomCode = redisUtils.get(RedisKeys.getSmsVerificationKey(verificationDTO.getBizType().getValue()+verificationDTO.getPhone()));
        if (StringUtils.isEmpty(cacheRandomCode)){
            throw new BizException("验证码错误");
        }
        if(!cacheRandomCode.equals(verificationDTO.getVerificationCode())){
            throw new BizException("验证码错误");
        }
        return true;
    }

}
