package com.suyun.common.exception;

import java.io.Serializable;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2017/11/23 上午11:08
 */
public class FieldError implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = -7211367675859446838L;

    private String name;
    private String message;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return String.format("`%s` %s", name, message);
    }
}
