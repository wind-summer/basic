package com.suyun.common.validator.group;

/**
 * 七牛
 * @author csg
 *
 * @date 2017-03-28 13:51
 */
public interface QiniuGroup {
}
