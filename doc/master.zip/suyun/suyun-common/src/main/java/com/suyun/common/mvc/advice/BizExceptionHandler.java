package com.suyun.common.mvc.advice;

import com.suyun.common.exception.BizException;
import com.suyun.common.exception.ParamValidException;
import com.suyun.common.mvc.vm.ArgumentInvalidVM;
import com.suyun.common.utils.ApiResult;
import org.apache.shiro.authz.AuthorizationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.HandlerMethod;

import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

/**
 * 异常处理器
 * 
 * @author csg
 *
 * @date 2016年10月27日 下午10:16:19
 */
@RestControllerAdvice
public class BizExceptionHandler {
	private Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * 自定义异常
	 */
	@ExceptionHandler(BizException.class)
	public ApiResult handleRRException(BizException e){
		ApiResult apiResult = new ApiResult();
		apiResult.put("code", e.getCode());
		apiResult.put("msg", e.getMessage());

		return apiResult;
	}

	@ExceptionHandler(DuplicateKeyException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ApiResult handleDuplicateKeyException(DuplicateKeyException e){
		logger.error(e.getMessage(), e);
		return ApiResult.error("数据库中已存在该记录");
	}

	@ExceptionHandler(AuthorizationException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
	public ApiResult handleAuthorizationException(AuthorizationException e){
		logger.error(e.getMessage(), e);
		return ApiResult.error(HttpStatus.FORBIDDEN.value(),"没有权限，请联系管理员授权");
	}

	@ExceptionHandler(ParamValidException.class)
    @ResponseStatus(HttpStatus.OK)
	public ApiResult paramValidExceptionHandler(ParamValidException ex) {
        logger.warn("参数校验失败:",ex.getMessage());

		return ApiResult.error(HttpStatus.BAD_REQUEST.value(),"参数校验失败");
	}

	@ExceptionHandler(BindException.class)
	public ApiResult bindExceptionHandler(BindException ex){
		return paramValidExceptionHandler(new ParamValidException(ex));
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.OK)
	public ApiResult bindExceptionHandler(MethodArgumentNotValidException ex){
		logger.warn(ex.getBindingResult().toString());
		//按需重新封装需要返回的错误信息
		List<ArgumentInvalidVM> invalidArguments = new ArrayList<>();
		//解析原错误信息，封装后返回，此处返回非法的字段名称，原始值，错误信息
		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			ArgumentInvalidVM invalidArgument = new ArgumentInvalidVM();
			invalidArgument.setDefaultMessage(error.getDefaultMessage());
			invalidArgument.setField(error.getField());
			invalidArgument.setRejectedValue(error.getRejectedValue());
			invalidArguments.add(invalidArgument);
		}
		return ApiResult.error(HttpStatus.BAD_REQUEST.value(),"参数校验失败").put("data",invalidArguments);
	}


	@ExceptionHandler(ConstraintViolationException.class)
	public ApiResult constraintViolationExceptionHandler(ConstraintViolationException ex, HandlerMethod handlerMethod) {
		return paramValidExceptionHandler(new ParamValidException(ex, handlerMethod.getMethodParameters()));
	}
	@ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ApiResult handleException(Exception e){
		logger.error(e.getMessage(), e);
		return ApiResult.error();
	}
}
