package com.suyun.api.module.sys.controller;

import com.baidu.ueditor.ActionEnter;
import com.baidu.ueditor.define.BaseState;
import com.baidu.ueditor.define.State;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.oss.cloud.OSSFactory;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("/api/ueditor")
public class UeditorController extends AbstractApiResultController {

    @GetMapping
    @AuthIgnore
    public String exec(HttpServletRequest request) throws UnsupportedEncodingException {
        request.setCharacterEncoding("utf-8");
        String rootPath = request.getRealPath("/");
        return new ActionEnter(request, rootPath).exec();
    }

    @PostMapping
    @AuthIgnore
    public String uploadFile(MultipartHttpServletRequest multipartRequest) throws Exception  {
        MultipartFile file = multipartRequest.getFile("upfile");
        log.debug("user login:{}", CurrentUserUtils.getLogin());
        if (file.isEmpty()) {
            throw new BizException("上传文件不能为空");
        }
        //上传文件
        String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        String url = OSSFactory.build().uploadSuffix(file.getBytes(), suffix);
        State state = new BaseState(true, 0);
        state.putInfo("url",url);
        //state.putInfo("original", multipartRequest.getFileNames().next());
        return state.toJSONString();
    }
}
