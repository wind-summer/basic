package com.suyun.api.module.physicallibrary.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.physicallibrary.service.BasePropService;
import com.suyun.core.module.physicallibrary.service.dto.BaseProductDTO;
import com.suyun.core.module.physicallibrary.service.dto.BaseProductDetailDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * <p>
 * 产品主表 前端控制器
 * </p>
 *
 * @author zjq
 * @since 2018-01-12
 */
@RestController
@RequestMapping("/api/baseproduct")
@Slf4j
@AllArgsConstructor
public class BasePropController extends AbstractApiResultController {

    private final BasePropService basePropService;

    /**
     * 物性库产品分页条件查找
     *
     * @param map
     * @param page
     * @return
     */
    @GetMapping("findbaseproductbycondition")
    @AuthIgnore
    public Page<BaseProductDTO> findBaseProductByCondition(@RequestParam Map<String, Object> map, Page<BaseProductDTO> page) {
        return basePropService.selectBaseProductByCondition(map, page);
    }

    /**
     * 根据产品ID查询物性库详细信息
     *
     * @param productId
     * @return
     */
    @GetMapping("findbaseproductdetailbyproductid")
    @AuthIgnore
    public BaseProductDetailDTO findBaseProductDetailByProductId(@RequestParam(value = "productId", required = true, defaultValue = "0") String productId) {
        return basePropService.findBaseProductDetailByProductId(productId);
    }

}

