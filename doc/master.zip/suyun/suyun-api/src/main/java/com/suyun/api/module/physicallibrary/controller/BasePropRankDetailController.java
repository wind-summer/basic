package com.suyun.api.module.physicallibrary.controller;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.physicallibrary.service.BasePropRankDetailService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * <p>
 * 物性表-级别分类明细 前端控制器
 * </p>
 *
 * @author zhangjiaqi
 * @since 2017-12-20
 */
@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping("/api/baseproprankdetail")
public class BasePropRankDetailController extends AbstractApiResultController {

    private final BasePropRankDetailService basePropRankDetailService;

    /**
     * 查询物性库产品加工级别，用途级别，特性级别
     *
     * @return
     */
    @GetMapping("findproprankdetail")
    @AuthIgnore
    public Map<String, Object> findPropRankDetail() {
        return basePropRankDetailService.findCommodity();
    }

}

