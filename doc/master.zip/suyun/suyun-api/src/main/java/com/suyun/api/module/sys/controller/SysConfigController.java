package com.suyun.api.module.sys.controller;

import com.suyun.api.annotation.AuthIgnore;
import com.suyun.api.module.sys.vm.PlatformBankVM;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.utils.ConfigConstant;
import com.suyun.core.sys.service.SysConfigService;
import com.suyun.core.sys.service.dto.PlatformBankDTO;
import com.suyun.core.sys.service.dto.SysConfigDTO;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 平台银行信息
 *
 * @author csg
 *
 * @date 2016年12月4日 下午6:55:53
 */
@RestController
@RequestMapping("/api/platform")
public class SysConfigController extends AbstractApiResultController {
    @Autowired
    private SysConfigService sysConfigService;

    /**
     * 查询平台银行信息
     */
    @GetMapping("bank")
    @AuthIgnore
    public PlatformBankVM platformBank(){
       return new PlatformBankVM(sysConfigService.getConfigObject(ConfigConstant.PLATFORM_BANK_KEY, PlatformBankDTO.class), RandomStringUtils.randomNumeric(6)) ;
    }

    /**
     * 查询系统全局配置信息
     */
    @GetMapping("config")
    public SysConfigDTO config(){
        SysConfigDTO config = sysConfigService.getConfigObject(ConfigConstant.SYS_GLOBAL_CONFIG_KEY, SysConfigDTO.class);
        return config;
    }

}