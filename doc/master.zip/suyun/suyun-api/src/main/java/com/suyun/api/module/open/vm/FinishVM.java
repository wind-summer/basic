package com.suyun.api.module.open.vm;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Min;
import java.math.BigDecimal;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单强制完成请求对象
 * @date 2018/3/1 上午11:50
 */
@Data
public class FinishVM {
    @NotEmpty(message = "订单编号不允许为空")
    private String orderCode;
    @Min(value =0, message = "发货数量不允许为空")
    private BigDecimal shippedQuantity;
    @Min(value = 0,message = "未发货数量不允许为空")
    private BigDecimal noQuantity;
    @NotEmpty(message = "类型不允许为空")
    private String flag;
}
