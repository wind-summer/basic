package com.suyun.api.module.financing.controller;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.financing.entity.FinancingApply;
import com.suyun.core.module.financing.service.FinancingApplyService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 融资申请表 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
@RestController
@RequestMapping("/api/financing")
@AllArgsConstructor
@Slf4j
public class FinancingApplyController extends AbstractApiResultController {
    private final FinancingApplyService financingApplyService;

    /**
     * 添加融资申请
     * @param financingApply
     */
    @PostMapping("/add")
    @AuthIgnore
    public void addFinancingApply(@RequestBody @Valid FinancingApply financingApply){
        log.debug("添加融资申请:{}",financingApply);
        financingApplyService.addFinancingApply(financingApply);
    }
}

