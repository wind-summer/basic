package com.suyun.api.module.sys.controller;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.sms.*;
import com.suyun.common.utils.ConfigConstant;
import com.suyun.common.validator.Assert;
import com.suyun.core.module.customer.exception.LoginFailException;
import com.suyun.core.sys.service.SysConfigService;
import com.suyun.core.sys.service.dto.PlatformBankDTO;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * 短信接口  API
 * </p>
 *
 * @author luy
 * @since 2017年12月28日 15:04:22
 */
@RestController
@RequestMapping("/api/msg")
@AllArgsConstructor
@Slf4j
public class MsgController extends AbstractApiResultController {

    private final MsgService msgService;

    private  final SysConfigService sysConfigService;

    private final SmsProperties smsProperties;

    /**
     * 发送手机验证码
     * @param msgDTO
     */
    @PostMapping("sendVerificationCode")
    public void sendVerificationCode(@RequestBody MsgDTO msgDTO){
        Set<String> phones = new HashSet<String>();
        //判断用户是否传递手机号码
        if(null == msgDTO.getPhones() || msgDTO.getPhones().size()<0){
            phones.add(CurrentUserUtils.getLogin().getMobileNo());
            msgDTO.setPhones(phones);
        }
        //判断手机号在数据库中是否存在
        msgService.sendVerificationCode(msgDTO);
    }

    /**
     * 校验验证码是否正确
     * @param verificationDTO
     * @return
     */
    @PostMapping("verifyRandomCode")
    public boolean verifyRandomCode(@RequestBody @Valid VerificationDTO verificationDTO){
        //校验手机号是否为空
        if(StringUtils.isBlank(verificationDTO.getPhone())){
            verificationDTO.setPhone(CurrentUserUtils.getLogin().getMobileNo());
        }
        return msgService.verifyRandomCode(verificationDTO);
    }

    /**
     * 不需要登录-发送手机验证码
     * @param msgDTO
     */
    @PostMapping("sendVerificationCodeNoLogin")
    @AuthIgnore
    public void sendVerificationCodeNoLogin(@RequestBody @Valid MsgDTO msgDTO){
        log.debug("phone :{}",msgDTO);
        //校验手机号是否存在
        if(null == msgDTO.getPhones() || msgDTO.getPhones().size()<0){
            throw new LoginFailException("手机号码不能为空，请重新输入！");
        }
        msgService.sendVerificationCode(msgDTO);
    }

    /**
     * 不需要登录-校验验证码是否正确
     * @param verificationDTO
     */
    @PostMapping("verifyRandomCodeNoLogin")
    @AuthIgnore
    public boolean verifyRandomCodeNoLogin(@RequestBody @Valid VerificationDTO verificationDTO){
        return msgService.verifyRandomCode(verificationDTO);
    }


    /**
     * 更改手机号向当前登录人的手机号发送验证码
     * @param msgDTO
     */
    @PostMapping("sendVerificationCodePhone")
    public void sendVerificationCodePhone(@RequestBody MsgDTO msgDTO){
        if(!CurrentUserUtils.getLogin().getMobileNo().equals(msgDTO.getPhones().iterator().next())){
            throw new LoginFailException("旧手机号与当前登录人手机号码不符，请重新输入！");
        }
        msgService.sendVerificationCode(msgDTO);
    }

    /**
     * 前端发送平台收款信息到手机
     */
    @PostMapping("send")
    public void send(@RequestParam String markCode,@RequestParam String money){
        boolean result=NumberUtils.isNumber(money);
        if(!result){
             throw new BizException("必须是数字类型");
        }
        PlatformBankDTO platformBankDTO=sysConfigService.getConfigObject(ConfigConstant.PLATFORM_BANK_KEY, PlatformBankDTO.class);
        Set<String> set=new HashSet<>();
        MsgDTO msgDTO = new MsgDTO();
        msgDTO.setTemplateCode(smsProperties.getPlatformBankTemplateCode());
        set.add(CurrentUserUtils.getLogin().getMobileNo());
        msgDTO.setBizType(BizType.OTHER).setPhones(set);
        msgDTO.addParam("money",money.toString());
        msgDTO.addParam("account",platformBankDTO.getBankAccount());
        msgDTO.addParam("bankName",platformBankDTO.getBankName());
        msgDTO.addParam("starnBank",platformBankDTO.getBank());
        msgDTO.addParam("code",markCode);
        msgService.sendSms(msgDTO);
    }
}