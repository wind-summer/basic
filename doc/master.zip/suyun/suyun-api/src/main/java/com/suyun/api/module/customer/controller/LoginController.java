package com.suyun.api.module.customer.controller;

import com.google.code.kaptcha.Constants;
import com.google.code.kaptcha.Producer;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.api.module.customer.controller.vm.LoginVM;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.sms.VerificationDTO;
import com.suyun.common.utils.ApiResult;
import com.suyun.common.utils.RedisUtils;
import com.suyun.common.validator.Assert;
import com.suyun.core.module.customer.exception.LoginFailException;
import com.suyun.core.module.customer.service.CustomerLoginService;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.LoginTokenService;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author caosg
 * @Description: 前端登陆操作
 * @date 2017/12/1 上午11:48
 */
@RestController
@RequestMapping("/api")
@AllArgsConstructor
@Slf4j
public class LoginController extends AbstractApiResultController {

    private final CustomerLoginService customerLoginService;

    private final CustomerService customerService;

    private final LoginTokenService loginTokenService;

    private final RedisUtils redisUtils;

    private final Producer producer;


    /**
     * 帐号密码登录
     * @param login
     * @param password
     * @return
     */
    @PostMapping("login")
    @AuthIgnore
    public CustomerDTO login(String login,String password){
       CustomerDTO customerDTO = customerLoginService.login(login,password);
       customerDTO.setToken(loginTokenService.createToken(customerDTO.getLogin().getId()));
       return customerDTO;
    }

    /**
     * 手机验证码登录
     * @param verificationDTO
     * @return
     */
    @PostMapping("phonelogin")
    @AuthIgnore
    public CustomerDTO phoneLogin(@RequestBody @Valid VerificationDTO verificationDTO){
        CustomerDTO customerDTO = customerLoginService.phoneLogin(verificationDTO);
        customerDTO.setToken(loginTokenService.createToken(customerDTO.getLogin().getId()));
        return customerDTO;
    }

    /**
     * 找回密码接口第一步（获取验证码）
     * @return
     */
    @GetMapping("/updatepaw/captcha")
    @AuthIgnore
    public ApiResult getCaptcha(){
        //生成文字验证码
        String text = producer.createText();
        redisUtils.set(Constants.KAPTCHA_SESSION_KEY+":"+text,text);
       return ApiResult.ok(text);
    }

    /**
     * 找回密码第二步 （校验当前手机号码是否存在，并校验当前安全码是否正确）
     * @param login
     * @param captcha
     * @return
     */
    @PostMapping("/updatepaw/checkLogin")
    @AuthIgnore
    public void checkLogin(String login,String captcha){
        String kaptcha = redisUtils.get(Constants.KAPTCHA_SESSION_KEY+":"+captcha);
        Assert.isNull(kaptcha,"验证码不正确，请核实！");
        if(!captcha.equals(kaptcha)){
            throw new LoginFailException("验证码不正确，请核实！");
        }
        if(customerService.getPhoneIsNull(login)&&customerLoginService.getLoginIsNull(login)){
            throw new LoginFailException("手机号/帐号不存在，请核实！");
        }

        redisUtils.delete(Constants.KAPTCHA_SESSION_KEY+":"+captcha);
    }

    /**
     * 校验手机号码是否是当前帐号的手机号码
     * @param login
     * @param phone
     */
    @PostMapping("/updatepaw/checkPhone")
    @AuthIgnore
    public void checkPhone(String login,String phone){
        customerLoginService.checkPhone(login,phone);
    }

    /**
     * 找回密码
     * @param phone
     * @param paw
     */
    @PutMapping("updatepaw")
    @AuthIgnore
    public void backPassword(String login,String phone,String paw){
        customerLoginService.backPassword(login,phone,paw);
    }

    /**
     * 密码修改
     * @param loginVM
     * @return
     */
    @PutMapping("password")
    public void updatePass(@RequestBody @Valid LoginVM loginVM){
        //校验旧密码是否正确
        if(!CurrentUserUtils.getLogin().getPassword().equals(DigestUtils.md5Hex(loginVM.getOldPassword()))){
            throw new LoginFailException("原密码输入不正确，请重新输入！");
        }
        //校验密码是否一致
        if(!loginVM.getPassword().equals(loginVM.getConfirmPassword())){
            throw new LoginFailException("密码输入不一致，请重新输入！");
        }
        customerLoginService.updatePassword(CurrentUserUtils.getLogin().getId(),loginVM.getPassword());
    }

    /**
     * 退出登录
     */
    @PostMapping("logout")
    public void  loginOut(){
        loginTokenService.expireToken(CurrentUserUtils.getLogin().getId());
        CurrentUserUtils.removeLogin();
    }
}
