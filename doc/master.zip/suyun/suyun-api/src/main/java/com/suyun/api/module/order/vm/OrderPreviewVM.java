package com.suyun.api.module.order.vm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.module.product.entity.Sku;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * @author caosg
 * @Description: 下单前订单预览信息
 * @date 2017/12/6 下午3:05
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderPreviewVM implements Serializable{

    private CustomerDTO customerInfo;
    private List<Sku> items;
}
