package com.suyun.api.module.order.vm;

import lombok.Data;

/**
 * @author caosg
 * @Description: Web 订单数据值对象
 * @date 2017/12/7 下午1:50
 */
@Data
public class OrderVM {

    //收货地址ID
    private Long addressId;
    //商品ID
    private Long productId;
    //skuID
    private Long skuId;
    //数量
    private Integer quantity;
    //支付方式
    private String paymentMethod;
    //配送方式
    private String shippingMethod;
    //运费结算方式
    private String shippingPaymentMethod;
    //优惠券代码
    private String offerCode;
    //备注
    private String remark;
}
