package com.suyun.api.module.word.controller;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.core.module.word.entity.KeyWord;
import com.suyun.core.module.word.service.KeyWordService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import com.suyun.common.mvc.controller.AbstractApiResultController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jos
 * @since 2018-01-16
 */
@RestController
@RequestMapping("/api/word")
@AllArgsConstructor
public class KeyWordController extends AbstractApiResultController {


    final KeyWordService keyWordService;
    @GetMapping("{keyWordType}")
    @AuthIgnore
    public List<KeyWord> findKeyWordByType(@PathVariable Integer keyWordType){
       return  keyWordService.findByType(keyWordType);
    }
}

