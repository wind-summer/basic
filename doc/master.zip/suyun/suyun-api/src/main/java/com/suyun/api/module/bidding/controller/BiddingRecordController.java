package com.suyun.api.module.bidding.controller;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.suyun.core.module.bidding.service.BiddingRecordService;
import com.suyun.core.module.bidding.service.dto.BiddingRecordDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * <p>
 * 竞价记录表 前端控制器
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@RestController
@RequestMapping("/api/bidding/record")
@AllArgsConstructor
@Slf4j
public class BiddingRecordController extends AbstractApiResultController {

    private final BiddingRecordService biddingRecordService;

    /**
     *
     * @param biddingRecord
     */
    @PostMapping("/add")
    public void add(@RequestBody @Valid BiddingRecord biddingRecord){
        biddingRecordService.insert(biddingRecord);
    }

    /**
     * 根据竞价产品ID分页查询竞猜记录
     * @param biddingProductId
     */
    @GetMapping("/list")
    @AuthIgnore
    public Page<BiddingRecord> queryBiddingRecordByProductId(@RequestParam(value = "biddingProductId",required = true,defaultValue = "0") Long biddingProductId, Page<BiddingRecord> page){
        return biddingRecordService.queryBiddingRecordByProductId(biddingProductId, page);
    }

    /**
     * 分页查询
     * @param page
     * @return
     */
    @GetMapping("/my/list")
    public Page<BiddingRecordDTO> queryBiddingRuleProduct(@RequestParam Map<String, Object> params, Page<BiddingRecordDTO> page) {
        return biddingRecordService.queryMyBiddingRecord(params,page);
    }

    /**
     * 根据id查询详细记录
     * @param id
     * @return
     */
    @GetMapping("/info")
    public BiddingRecord getBiddingRecordById(@RequestParam(value = "id",required = true,defaultValue = "0") Long id) {
        return biddingRecordService.getMyBiddingRecord(id);
    }
}

