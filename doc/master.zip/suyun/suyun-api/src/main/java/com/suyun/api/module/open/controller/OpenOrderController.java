package com.suyun.api.module.open.controller;

import com.suyun.api.module.open.vm.FinishVM;
import com.suyun.api.module.open.vm.ShippingVM;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.utils.DateUtils;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.module.open.service.ApiClientService;
import com.suyun.core.module.order.entity.OrderShipping;
import com.suyun.core.module.order.service.OrderService;
import com.suyun.core.module.order.service.dto.OrderFinishDTO;
import jdk.nashorn.internal.objects.annotations.Getter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: 开放给浪潮系统调用
 * @date 2018/3/1 上午11:12
 */
@RestController
@RequestMapping("/open-api/order")
@AllArgsConstructor
@Slf4j
public class OpenOrderController extends AbstractApiResultController {

    private final OrderService orderService;

    private final ApiClientService apiClientService;

    @PostMapping("shipping")
    public void shippingOrder(@RequestBody @Valid ShippingVM shippingVM){
       log.info("***** shippingOrder parameters:{} ********",shippingVM);
       List<OrderShipping> orderShippings = new ArrayList<>();
       shippingVM.getShippings().forEach(shipping -> {
           ValidatorUtils.validateEntity(shipping);
           OrderShipping orderShipping = new OrderShipping();
           orderShipping.setOrderCode(shippingVM.getOrderCode())
                   .setQuantiy(shipping.getQuantity())
                   .setShippingCode(shipping.getShippingCode())
                   .setShippingTime(DateUtils.parse(shipping.getShippingDate()));
           orderShippings.add(orderShipping);

       } );
       orderService.deliver(shippingVM.getOrderCode(),orderShippings);
    }

    @PostMapping("finish")
    public void finishOrder(@RequestBody @Valid FinishVM finishVM){
        log.info("***** finishOrder parameters:{} ********",finishVM);
        OrderFinishDTO orderFinishDTO = new OrderFinishDTO();
        orderFinishDTO.setOrderCode(finishVM.getOrderCode())
                .setShippedQuantity(finishVM.getShippedQuantity())
                .setNoQuantity(finishVM.getNoQuantity()).setFlag(finishVM.getFlag());
        orderService.finish(orderFinishDTO);
    }

    @GetMapping("clear-cache")
    public void clearApiClientCache(){
       apiClientService.clearCache();
    }

}
