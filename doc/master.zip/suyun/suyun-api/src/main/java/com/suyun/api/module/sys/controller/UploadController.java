package com.suyun.api.module.sys.controller;

import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.oss.cloud.OSSFactory;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;

/**
 * @author jos
 * @version V1.0
 * @Description: TODO
 * @date 9:02 2017/12/21
 */
@AllArgsConstructor
@Slf4j
@RestController
@RequestMapping("/api/upload")
public class UploadController extends AbstractApiResultController {

    /**
     * 上传文件
     */
    @PostMapping
    @AuthIgnore
    public HashMap<String, Object> uploadFile(@RequestParam("file") MultipartFile file) throws Exception {
        log.debug("user login:{}", CurrentUserUtils.getLogin());
        if (file.isEmpty()) {
            throw new BizException("上传文件不能为空");
        }
        //上传文件
        String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        String url = OSSFactory.build().uploadSuffix(file.getBytes(), suffix);
        HashMap result = new HashMap<>(1);
        result.put("url", url);
        return result;
    }

}
