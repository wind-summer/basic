package com.suyun.api.module.open.vm;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.List;

/**
 * @author caosg
 * @version V1.0
 * @Description: 发货记录
 * @date 2018/3/1 上午11:21
 */
@Data
public class ShippingVM {
    @NotEmpty(message = "订单编号不允许为空")
    private String orderCode;

    @NotEmpty(message = "发货记录不允许为空")
    private List<Shipping> shippings;


}
