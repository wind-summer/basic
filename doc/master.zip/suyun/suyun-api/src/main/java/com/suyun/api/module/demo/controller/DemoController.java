package com.suyun.api.module.demo.controller;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.api.annotation.LoginUser;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.mvc.vm.PageVM;
import com.suyun.common.utils.RedisUtils;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.demo.entity.Demo;
import com.suyun.core.module.demo.service.DemoService;
import com.suyun.core.module.order.service.OrderPushService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 示例 Demo 前端控制器，基于Restfull规范
 * </p>
 * <p>查询操作：@GetMapping</p>
 * <p>新增操作：@PostMapping</p>
 * <p>编辑操作：@PutMapping</p>
 * <p>删除操作：@DeleteMapping</p>
 * @author caosg
 * @since 2017-11-23
 */
@RestController
@RequestMapping("/api/demo")
@AllArgsConstructor
@Slf4j
public class DemoController extends AbstractApiResultController {
   private final DemoService demoService;

   private final RedisUtils redisUtils;

   private final OrderPushService orderPushService;

    /**
     * 查询所有demos
     * @return
     */
   @GetMapping("all")
   @AuthIgnore
   public List<Demo> findAll(){
       log.info("查询所有记录");
       return demoService.selectList(new EntityWrapper<>());
   }

    @GetMapping("/page")
    @AuthIgnore
    public PageVM find(Page page) {
        Page<Demo> pageDemo = demoService.selectPage(page);
        return toPageVM(pageDemo);
    }

    /**
     * <p>
     *   新增一条demo，获取当前用户两种方式</br>
     *     1: 在Controller的方法后增加 @LoginUser CustomerLogin login
     *     2: 在任意位置调用 CurrentUserUtils.getLogin()
     * </p>
     *
     * @param demo
     */
   @PostMapping("/add")
   public void add(@RequestBody @Valid Demo demo, @LoginUser CustomerLogin login){
       log.debug("current login:{}\n o:{}",login, CurrentUserUtils.getLogin());
       log.debug("插入一条demo:{}",demo);
       demo.setCreateTime(new Date());
       demoService.insert(demo);
   }

    /**
     * 根据 id 删除demo
     * @param id 主键ID
     */
   @DeleteMapping("delete/{id}")
   public void delete(@PathVariable Integer id){
       log.debug("删除一条记录，ID：{}",id  );
       demoService.deleteById(id);
   }

    /**
     * 全量编辑
     * @param demo
     */
   @PutMapping("/edit")
   public void edit(@RequestBody Demo demo){
      log.debug("根据id：{}，修改demo：{}",demo.getId(),demo);
      demoService.updateById(demo);
   }

    /**
     * 删除Redis
     * @param key
     */
    @GetMapping("/deleteRedis/{key}")
   public void deleteRedisByKey(@PathVariable String key){
        if(StringUtils.isNotBlank(key)){
            redisUtils.delete(key);
        }
   }

    /**
     * 手动推送订单到浪潮ERP
     * @param orderId
     */
   @GetMapping("/orderPush/{orderId}")
    public void orderPush(@PathVariable Long orderId){
       orderPushService.pushOrderByOrderId(orderId);
   }
}

