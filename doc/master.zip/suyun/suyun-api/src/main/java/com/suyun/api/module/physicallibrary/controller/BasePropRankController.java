package com.suyun.api.module.physicallibrary.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 物性表-级别分类 前端控制器
 * </p>
 *
 * @author zhangjiaqi
 * @since 2017-12-20
 */
@RestController
@RequestMapping("/physicallibrary/baseproprank")
public class BasePropRankController extends AbstractApiResultController {

}

