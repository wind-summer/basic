package com.suyun.api.mvc.interceptor;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.core.module.customer.entity.LoginToken;
import com.suyun.core.module.customer.service.LoginTokenService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 权限(Token)验证
 * @author csg
 *
 * @date 2017-03-23 15:38
 */
@Component
@AllArgsConstructor
@Slf4j
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

    private final LoginTokenService tokenService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        AuthIgnore annotation;
        if(handler instanceof HandlerMethod) {
            annotation = ((HandlerMethod) handler).getMethodAnnotation(AuthIgnore.class);
        }else{
            return true;
        }

        //如果有@AuthIgnore注解，则不验证token
        if(annotation != null){
            return true;
        }

        //从header中获取token
        String token = request.getHeader(CurrentUserUtils.HEADER_TOKEN_KEY);
        //如果header中不存在token，则从参数中获取token
        if(StringUtils.isEmpty(token)){
            token = request.getParameter(CurrentUserUtils.HEADER_TOKEN_KEY);
        }

        //token为空
        if(StringUtils.isEmpty(token)){
            throw new BizException("token不能为空",HttpStatus.UNAUTHORIZED.value());
        }
        if(request.getAttribute(CurrentUserUtils.LOGIN_ID)==null) {
            //查询token信息
//            LoginToken loginToken = tokenService.queryByToken(token);
//            if (loginToken == null || loginToken.getExpireTime().getTime() < System.currentTimeMillis()) {
//                response.setStatus(HttpStatus.UNAUTHORIZED.value());
//                throw new BizException("token失效，请重新登录", HttpStatus.UNAUTHORIZED.value());
//            }

            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            throw new BizException("token失效，请重新登录", HttpStatus.UNAUTHORIZED.value());
        }

        return true;
    }
}
