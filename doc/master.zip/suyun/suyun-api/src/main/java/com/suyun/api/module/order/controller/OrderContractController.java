package com.suyun.api.module.order.controller;

import com.google.gson.Gson;
import com.junziqian.api.util.HttpSignUtils;
import com.junziqian.api.util.ResultInfoException;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.core.junziqian.JunziQianProperties;
import com.suyun.core.module.order.service.OrderContractService;
import com.suyun.core.module.order.service.dto.ContractDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * @author caosg
 * @version V1.0
 * @Description: 订单电子合同
 * @date 2018/2/27 下午4:54
 */
@RestController
@RequestMapping("api/contract")
@AllArgsConstructor
@Slf4j
public class OrderContractController {

    private final OrderContractService orderContractService;

    private final JunziQianProperties junziQianProperties;

    @PostMapping("callback")
    @AuthIgnore
    public String callBack(HttpServletRequest request){
        Map<String,Object> result = new HashMap<>(8);
        result.put("success",true);
        Enumeration<?> enums  = request.getParameterNames();
        log.info(" ****** JunZiQian callback info ***************\n");
        while (enums.hasMoreElements()) {
            Object obj = enums.nextElement();
            log.info("======key:{},value:{} ====== \n" ,obj , request.getParameter(obj + ""));
        }
        if (StringUtils.isNotEmpty(request.getParameter("fullName"))&& request.getParameter("fullName").equals(junziQianProperties.getCompany().getName())) {
          return  new Gson().toJson(result);
        }
        try{
            Long timestamp = Long.valueOf(request.getParameter("timestamp"));
            String sign = request.getParameter("sign");
            Map<String,Object> bodyParams=new HashMap<>();
            bodyParams.put("applyNo", request.getParameter("applyNo"));
            bodyParams.put("identityType",request.getParameter("identityType"));
            bodyParams.put("fullName", request.getParameter("fullName"));
            bodyParams.put("identityCard", request.getParameter("identityCard"));
            bodyParams.put("optTime",Long.parseLong(request.getParameter("optTime")));
            bodyParams.put("signStatus", request.getParameter("signStatus"));
            HttpSignUtils.checkHttpSign(bodyParams, timestamp, junziQianProperties.getAppKey(), junziQianProperties.getAppSecret(), sign,1000*60*60*24);

            orderContractService.callback(request.getParameter("applyNo"),Integer.valueOf(request.getParameter("signStatus")));
        }catch(ResultInfoException e){
            log.error(e.getMessage());
            result.put("success",false);
            result.put("msg",e.getMessage());
        }catch (BizException be){
            log.error(be.getMsg());
            result.put("success",false);
            result.put("msg",be.getMsg());
        }
        return  new Gson().toJson(result);
    }

    @GetMapping("{orderId}")
    @AuthIgnore
    public ContractDTO getOrderById(@PathVariable Long orderId){
        ContractDTO contractDTO = new ContractDTO();
        contractDTO.setDetailUrl(orderContractService.signDetailLink(orderId));
        contractDTO.setDownloadUrl(orderContractService.signDownloadLink(orderId));
        return contractDTO;
    }
}
