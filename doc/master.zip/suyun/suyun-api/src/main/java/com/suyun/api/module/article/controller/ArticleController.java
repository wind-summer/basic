package com.suyun.api.module.article.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.article.entity.Article;
import com.suyun.core.module.article.service.ArticleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @author jos
 * @version V1.0
 * @Description: 文章
 * @date 14:32 2017/12/12
 */
@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/api/article")
public class ArticleController extends AbstractApiResultController {
    private final ArticleService articleService;

    /**
     * 查询文章详情
     *
     * @param articleId
     * @return
     */
    @GetMapping("/info")
    @AuthIgnore
    public Article findArticleByid(@RequestParam(value = "id", defaultValue = "0") Long articleId) {
        return articleService.findArticleByid(articleId);
    }

    /**
     * 文章列表
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/list")
    @AuthIgnore
    public Page<Article> queryArticle(@RequestParam Map<String, Object> params,Page<Article> page) {
        //查询状态为1的
        params.put("status",1);
        params.put("show",1);
        return articleService.queryArticle(params,page);
    }
}
