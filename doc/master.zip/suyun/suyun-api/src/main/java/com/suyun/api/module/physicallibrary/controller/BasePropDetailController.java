package com.suyun.api.module.physicallibrary.controller;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.physicallibrary.service.BasePropDetailService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * <p>
 * 物性明细表 前端控制器
 * </p>
 *
 * @author zjq
 * @since 2018-01-12
 */
@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping("/api/baseproductdetail")
public class BasePropDetailController extends AbstractApiResultController {

    private final BasePropDetailService basePropDetailService;

    /**
     * 物性库对比查询
     *
     * @param arry
     * @return
     */
    @GetMapping("productcompareto")
    @AuthIgnore
    public Map<String, Object> productCompareTo(@RequestParam String[] arry) {
        return basePropDetailService.compareToProduct(arry);
    }
}

