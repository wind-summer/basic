package com.suyun.api.module.order.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.module.order.vm.OrderPreviewVM;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.utils.ApiResult;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.ContractStatus;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.enums.YesOrNo;
import com.suyun.core.module.order.service.OrderContractService;
import com.suyun.core.module.order.service.OrderService;
import com.suyun.core.module.order.service.dto.ContractDTO;
import com.suyun.core.module.order.service.dto.CustomerOrderDashboardDTO;
import com.suyun.core.module.order.service.dto.OrderDTO;
import com.suyun.core.module.order.service.dto.PayVoucherDTO;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.module.product.service.ProductService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

/**
 * <p>
 * 订单前端Rest API
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@RestController
@RequestMapping("/api/order")
@AllArgsConstructor
@Slf4j
public class OrderController extends AbstractApiResultController {

    private final OrderService orderService;

    private final CustomerService customerService;

    private final OrderContractService orderContractService;

    private final ProductService productService;

    /**
     * 订单确认,由客户操作
     *
     * @param orderId
     */
    @PostMapping("{orderId}/confirm")
    public ApiResult confirm(@PathVariable Long orderId) {
//        boolean result;
//        result = orderService.handleEvent(orderId, OrderEvent.CONFIRM, true);
//        if (!result) {
//            throw new BizException("订单状态不符合流程");
//        }
        Order order = orderService.selectById(orderId);
        if(order.getOrderStatus()!= OrderStatus.AWAITING_CONFIRM){
            throw new BizException("订单状态不是待确认");
        }
        String signLink = orderContractService.signLink(orderId);
        log.debug("signLink :{}",signLink);

        return ApiResult.ok().put("data",signLink);

    }

    /**
     * 订单签收,由客户操作
     *
     * @param orderId
     */
    @PostMapping("{orderId}/receive")
    public void receive(@PathVariable Long orderId) {
        boolean result;
        result = orderService.handleEvent(orderId, OrderEvent.RECEIVE, true);
        if (!result) {
            throw new BizException("订单状态不符合流程");
        }
    }

    /**
     * 校验是否发货完成
     * @param orderId
     */
    @PostMapping("check/{orderId}")
    public boolean checkShippingStatus(@PathVariable Long orderId){
        Order order = this.getOrder(orderId);
        if(order.getShippingStatus() == YesOrNo.NO){
           return false;
        }else{
            return true;
        }
    }

    /**
     * 下单
     *
     * @param skuId
     * @return
     */
    @GetMapping("purchase/{skuId}")
    public OrderPreviewVM enterOrder(@PathVariable Long skuId) {
        CustomerDTO customerDTO = customerService.getCustomer(CurrentUserUtils.getLogin().getCustomerId());
        if(customerDTO.getCustomer().getStatus()!= CustomerStatusEnum.SUCCESS){
            throw new BizException("用户您没有经过认证，暂不允许下单。");
        }
        Sku sku = productService.getSku(skuId);
        if(sku==null|| !sku.getSale()){
            throw new BizException("商品已下架，暂不允许下单。");
        }
        return new OrderPreviewVM(customerDTO, Arrays.asList(sku));
    }

    /**
     * 提交订单
     *
     * @param order
     * @return
     */
    @PostMapping
    public Order createOrder(@RequestBody Order order) {
        Order result = orderService.createOrder(order);
        return result;
    }

    /**
     * 查询我的订单
     *
     * @param page
     * @return
     */
    @GetMapping("my")
    public Page<Order> myOrder(Page<Order> page,@RequestParam(required = false) String orderCode) {
        return orderService.queryMyOrder(page,orderCode);
    }

    /**
     * 我的支付
     *
     * @param markCode;
     * @param imageUrl
     * @param orderId
     */
    @PostMapping("mypay/{orderId}")
    public void uploadPaymentoucher(@RequestParam String markCode, @RequestParam(required = false) String imageUrl , @PathVariable Long orderId) {
        PayVoucherDTO payVoucherDTO = new PayVoucherDTO();
        orderService.addPayment(orderId, payVoucherDTO.setMarkCode(markCode).setVoucherImage(imageUrl));

    }

    /**
     * 本月我的订单统计
     *
     * @return
     */
    @GetMapping("my/order-dashboard")
    public List<CustomerOrderDashboardDTO> getMyOrderDashboard() {
        return orderService.getMyOrderDashboard();
    }

    /**
     * 根据订单ID查询订单明细
     *
     * @param orderId
     * @return
     */
    @GetMapping("{orderId}")
    public OrderDTO getOrderById(@PathVariable Long orderId) {
        OrderDTO orderDTO = orderService.getOrderById(orderId);
        if(orderDTO.getOrder().getSignStatus()== ContractStatus.SUCCESS||orderDTO.getOrder().getSignStatus()==ContractStatus.PERSIST){
            ContractDTO contractDTO = new ContractDTO();
            contractDTO.setDetailUrl(orderContractService.signDetailLink(orderId));
            contractDTO.setDownloadUrl(orderContractService.signDownloadLink(orderId));
            orderDTO.setContract(contractDTO);
        }
        return orderDTO;
    }


    /**
     * 用户取消订单
     *
     * @param orderId
     */
    @PostMapping("{orderId}/cancel")
    public void cancelOrder(@PathVariable Long orderId) {
        boolean result;
        result = orderService.handleEvent(orderId, OrderEvent.CANCEL, true);
        if (!result) {
            throw new BizException("订单状态不符合流程");

        }
    }

    private Order getOrder(Long orderId){
        Order order = orderService.selectById(orderId);
        if(order == null){
            new BizException("订单:"+orderId+"不存在");
        }
        return order;
    }
}