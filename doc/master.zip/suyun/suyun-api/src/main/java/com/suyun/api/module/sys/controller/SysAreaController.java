package com.suyun.api.module.sys.controller;


import com.baomidou.mybatisplus.mapper.Wrapper;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.utils.RedisUtils;
import com.suyun.core.module.product.entity.Category;
import com.suyun.core.module.product.service.CategoryService;
import com.suyun.core.sys.entity.SysArea;
import com.suyun.core.sys.service.SysAreaService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 中国行政地区表 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-12-20
 */
@Slf4j
@RestController
@RequestMapping("/api/area")
@AllArgsConstructor
public class SysAreaController extends AbstractApiResultController {
    private CategoryService categoryService;
    private final SysAreaService sysAreaService;
    private final RedisUtils redisUtils;

    /**
     * 根据父级id,查询该级下的所有子集
     *
     * @param parentId
     * @return
     */
    @GetMapping("list")
    @AuthIgnore
    public List<SysArea> findByParentId(@RequestParam(value = "parent", required = false, defaultValue = "0") Long parentId) {
        log.debug("parentId is param:{}", parentId);
        return sysAreaService.selectList(parentId);
    }

    /**
     * 初始化数据
     */
    @GetMapping("init")
    @AuthIgnore
    public void initData() {
        List<Category> categories = categoryService.selectList(null);
        categories.forEach(category -> {
            redisUtils.set("categoryName:" + category.getId(), category.getName());
        });
        List<SysArea> sysAreas = sysAreaService.selectList((Wrapper<SysArea>) null);
        sysAreas.forEach(sysArea -> {
            redisUtils.set("areaName:" + sysArea.getId(), sysArea.getName());
        });
    }
}

