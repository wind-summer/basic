package com.suyun.api.module.customer.controller.vm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.service.dto.CustomerAttributeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * 查询最新企业
 *
 * @author luyang
 * @date 2018年1月4日 19:54:21
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerVM implements Serializable {
    //客户信息
    private Customer customer;
    //详细信息
    private List<CustomerAttributeDTO> attributes;

}
