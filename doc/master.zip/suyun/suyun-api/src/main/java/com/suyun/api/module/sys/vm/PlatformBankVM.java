package com.suyun.api.module.sys.vm;

import com.suyun.core.sys.service.dto.PlatformBankDTO;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author caosg
 * @version V1.0
 * @Description: 平台收款信息
 * @date 2017/12/28 下午4:37
 */
@Data
@AllArgsConstructor
public class PlatformBankVM {
    PlatformBankDTO platformBank;
    String markCode;
}
