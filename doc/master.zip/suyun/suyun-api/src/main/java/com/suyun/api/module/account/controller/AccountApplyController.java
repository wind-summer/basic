package com.suyun.api.module.account.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.account.service.dto.ApplyDTO;
import com.suyun.core.module.account.service.dto.RechargeDTO;
import com.suyun.core.module.account.service.dto.WithDrawApplyDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 账户充值提现申请 前端控制器
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@RestController
@RequestMapping("/api/accountapply")
@AllArgsConstructor
@Slf4j
public class AccountApplyController extends AbstractApiResultController {

    private final AccountApplyService accountApplyService;

    /**
     * 充值申请
     *
     * @param apply
     * @return
     */
    @PostMapping("apply")
    public void createApply(@RequestBody @Valid ApplyDTO apply) {
        accountApplyService.createApply(apply);
    }

    /**
     * 提现申请
     *
     * @param withDrawApply
     * @return
     */
    @PostMapping("withdraw")
    public void withDraw(@RequestBody @Valid WithDrawApplyDTO withDrawApply) {
        accountApplyService.withDraw(withDrawApply);
    }

    /**
     * 客户充值查看
     *
     * @return
     */
    @GetMapping("recharge")
    public RechargeDTO findRecharge() {
        return accountApplyService.findRecharge();
    }

}

