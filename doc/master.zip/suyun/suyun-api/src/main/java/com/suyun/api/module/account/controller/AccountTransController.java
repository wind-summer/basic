package com.suyun.api.module.account.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.account.entity.AccountTrans;
import com.suyun.core.module.account.service.AccountTransService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * <p>
 * 账户收支明细 前端控制器
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/api/accounttrans")
public class AccountTransController extends AbstractApiResultController {

    private final AccountTransService accountTransService;

    @GetMapping("page")
    private Page<AccountTrans> findAccountTransPage(@RequestParam Map<String, Object> map, Page<AccountTrans> page) {
        return accountTransService.findAccountTrans(map, page);
    }

}

