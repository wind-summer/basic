package com.suyun.api.mvc.interceptor;

import com.suyun.common.exception.BizException;
import com.suyun.core.module.open.entity.ApiClient;
import com.suyun.core.module.open.service.ApiClientService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

/**
 * @author caosg
 * @version V1.0
 * @Description: 开放API认证
 * @date 2018/3/5 下午1:30
 */
@Component
@AllArgsConstructor
@Slf4j
public class OpenAuthInterceptor extends HandlerInterceptorAdapter {
    private final static String CLIENT_ID = "clientId";
    private final static String CLIENT_SECRET = "clientSecret";
    private final ApiClientService apiClientService;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String clientId = getParam(request,CLIENT_ID);
        String clientSecret = getParam(request,CLIENT_SECRET);
        if(StringUtils.isEmpty(clientId)||StringUtils.isEmpty(clientSecret)){
            throw new BizException("clientId和clientSecret不允许为空", HttpStatus.UNAUTHORIZED.value());
        }
        log.info("==== OpenAuthInterceptor is working .===\n CLIENT_ID:{} ,CLIENT_SECRET:{} ############ ",clientId,clientSecret);
        ApiClient apiClient = apiClientService.getClientByClientId(clientId);
        if(apiClient==null|| !clientSecret.equals(apiClient.getClientSecret())){
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            throw new BizException("账号或秘钥不正确",HttpStatus.UNAUTHORIZED.value());
        }
        if(apiClient.getStatus()!= 1){
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            throw new BizException("账号还未激活",HttpStatus.UNAUTHORIZED.value());
        }
        return super.preHandle(request, response, handler);
    }

    private String getParam(HttpServletRequest request,String paramKey){
        String paramValue = request.getHeader(paramKey);
        if (StringUtils.isEmpty(paramValue)) {
            paramValue = request.getParameter(paramKey);
        }
        return paramValue;
    }
}
