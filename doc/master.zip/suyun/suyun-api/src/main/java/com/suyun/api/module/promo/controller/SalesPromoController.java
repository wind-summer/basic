package com.suyun.api.module.promo.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 促销活动 前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-12-06
 */
@RestController
@RequestMapping("/api/salesPromo")
public class SalesPromoController extends AbstractApiResultController {

}

