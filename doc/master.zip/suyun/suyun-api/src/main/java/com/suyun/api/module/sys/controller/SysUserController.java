package com.suyun.api.module.sys.controller;

import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.validator.Assert;
import com.suyun.core.sys.entity.SysUser;
import com.suyun.core.sys.service.SysUserService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 业务人员
 * @author luyang
 */
@RestController
@RequestMapping("/api/sys/user")
@AllArgsConstructor
@Slf4j
public class SysUserController extends AbstractApiResultController {

	private SysUserService sysUserService;

	@GetMapping("/{id}")
	@AuthIgnore
	public SysUser getSysUser(@PathVariable Long id){
		Assert.isNull(id,"业务员id不能为空");
		return sysUserService.queryObject(id);
	}
}
