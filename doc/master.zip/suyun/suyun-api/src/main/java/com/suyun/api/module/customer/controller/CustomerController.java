package com.suyun.api.module.customer.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.api.module.customer.controller.vm.CustomerVM;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.service.CustomerLoginService;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.CustomerBrowseDTO;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.module.customer.service.dto.CustomerDetailDTO;
import com.suyun.core.module.customer.service.dto.RegisterDTO;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *  客户信息 前端Rest API
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@RestController
@RequestMapping("/api/customer")
@AllArgsConstructor
@Slf4j
public class CustomerController extends AbstractApiResultController {

    private final CustomerService customerService;

    private final CustomerLoginService customerLoginService;

    /**
     * 注册
     * @param registerDTO
     */
    @PostMapping("register")
    @AuthIgnore
    public void register(@RequestBody @Valid RegisterDTO registerDTO){
        customerService.register(registerDTO);
    }

    /**
     * 校验当前手机号码是否存在
     * @param phoneNo
     * @return false
     */
    @GetMapping("checkPhone/{phoneNo}")
    @AuthIgnore
    public boolean checkPhone(@PathVariable String phoneNo){
        return customerLoginService.getPhoneIsNull(phoneNo);
    }

    /**
     * 校验公司名称是否重复
     * @param name
     * @return
     */
    @GetMapping("checkName/{name}")
    @AuthIgnore
    public boolean checkName(@PathVariable String name){
        return customerService.getNameIsNull(name);
    }

    /**
     * 校验邮箱是否重复
     * @param email
     * @return
     */
    @PostMapping("checkEmail")
    public boolean checkEmail(@RequestParam  String email,@RequestParam Long id){
        return customerService.getEmailIsNull(email,id);
    }

    /**
     * 校验营业执照是否重复
     * @param organizationRegNo
     * @return
     */
    @PostMapping("checkOrganizationRegNo")
    public boolean checkOrganizationRegNo(@RequestParam  String organizationRegNo,@RequestParam Long id){
        return customerService.getOrganizationRegNoIsNull(id,organizationRegNo);
    }

    /**
     * 编辑客户信息时校验公司名称是否重复
     * @param name
     * @param id
     * @return
     */
    @GetMapping("editCheckName")
    public boolean editCheckName(@RequestParam String name,@RequestParam Long id){
        return  customerService.getNameIsNullByBackstage(name,id);
    }

    /**
     * 初始化完善企业信息
     * @param customerId
     * @return
     */
    @GetMapping("{customerId}")
    //@RequiresPermissions("sys:customer:get")
    public CustomerDetailDTO getCustomer(@PathVariable Long customerId){
        if(null==customerId){
            customerId = CurrentUserUtils.getLogin().getCustomerId();
        }
        CustomerDTO customerDTO =  customerService.getCustomer(customerId);;
        CustomerDetailDTO customerDetailDTO = new CustomerDetailDTO();
        BeanUtils.copyProperties(customerDTO.getCustomer(),customerDetailDTO);
        if(null != customerDTO.getAttributes() && customerDTO.getAttributes().size()>0){
            customerService.getCustomerDetailDTO(customerDetailDTO,customerDTO.getAttributes());
        }
        return customerDetailDTO;
    }

    /**
     * 查看客户详情
     * @param customerId
     * @return
     */
    @GetMapping("detail/{customerId}")
    @AuthIgnore
    public CustomerDetailDTO getCustomerDetail(@PathVariable Long customerId){
        CustomerDTO customerDTO =  customerService.getCustomer(customerId);;
        CustomerDetailDTO customerDetailDTO = new CustomerDetailDTO();
        BeanUtils.copyProperties(customerDTO.getCustomer(),customerDetailDTO);
        if(null != customerDTO.getAttributes() && customerDTO.getAttributes().size()>0){
            customerService.getCustomerDetailDTO(customerDetailDTO,customerDTO.getAttributes());
        }
        return customerDetailDTO;
    }

    /**
     * 完善企业信息
     * @param customerDetailDTO
     */
    @PutMapping("updateCustomer")
    //@RequiresPermissions("sys:customer:add")
    public void updateCustomer(@RequestBody @Valid CustomerDetailDTO customerDetailDTO){
        customerService.updateCustomer(new CustomerDTO(this.getCustomer(customerDetailDTO),null,customerService.getAttribute(customerDetailDTO),null,customerDetailDTO.getToken()));
    }

    /**
     * 个人信息修改
     * @param customerLogin
     */
    @PutMapping("updateLoginUser")
    public void updateLoginUser(@RequestBody @Valid CustomerLogin customerLogin){
        customerService.updateLoginUser(customerLogin);
    }

    /**
     * 获取最新企业
     * @param num
     * @return 返回客戶信息、詳細信息
     */
    @GetMapping("newcomer/{num}")
    @AuthIgnore
    public List<CustomerVM> getNewCustomer(@PathVariable Long num){
        return  customerService.getNewCustomer(num).stream().map(customer ->{
            CustomerVM customerVM = new CustomerVM(customer,customerService.getCustomerAttributes(customer.getId()));
                    return customerVM;
                }).collect(Collectors.toList());
    }

    /**
     * 名称条件查询
     * @param name
     * @param page
     * @return
     */
    @GetMapping("list")
    @AuthIgnore
    public Page<CustomerVM> getCustomerByName(String name, Page<Customer> page){
        Page<CustomerVM> vmPage = new Page<>();
        page = customerService.getCustomerByName(name,page);
        BeanUtils.copyProperties(page,vmPage);
        vmPage.setRecords(page.getRecords().stream().map(customer -> {
            CustomerVM customerVM = new CustomerVM(customer,customerService.getCustomerAttributes(customer.getId()));
            return customerVM;
        }).collect(Collectors.toList()));
        return vmPage;
    }

    /**
     * 增加浏览量
     * @param customerId
     */
    @PostMapping("browse/{customerId}")
    @AuthIgnore
    public void addBrowse(@PathVariable  Long customerId){
        customerService.addBrowse(customerId);
    }

    /**
     * 获取最热企业
     * @param num
     * @return
     */
    @GetMapping("hotcustomer/{num}")
    @AuthIgnore
    public List<CustomerBrowseDTO> getHotCustomer(@PathVariable int num){
       return customerService.getHotCustomer(num);
    }


    /**
     * 修改手机号码
     */
    @PutMapping("phone")
    public void updatePhoneById(String phone,String verificationCode){
        customerService.updatePhoneById(phone,verificationCode);
    }

    /**
     * 获取Customer对象
     * @param customerDetailDTO
     * @return
     */
    private Customer getCustomer(CustomerDetailDTO customerDetailDTO){
        Customer customer = new Customer();
        BeanUtils.copyProperties(customerDetailDTO,customer);
        if(null == customer.getOrganizationTegNo()){
            customer.setOrganizationTegNo(customerDetailDTO.getBizCreditCode());
        }
        return customer;
    }

}