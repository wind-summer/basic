package com.suyun.api.module.open.vm;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * @author caosg
 * @version V1.0
 * @Description: TODO
 * @date 2018/3/5 下午2:21
 */
@Data
public class Shipping {
    /**
     * 发货数量
     */
    @Min(value = 0, message = "发货数量要大于0")
    private BigDecimal quantity ;
    /**
     * 发货单号
     */
    @Size(min = 1,max = 32,message = "发货单号为空或长度不符")
    private String shippingCode;

    /**
     * 发货日期 格式：2017-07-21 17:32:28
     */
    @NotEmpty(message = "发货日期不能为空")
    private String shippingDate;
}
