package com.suyun.api.module.customer.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.validator.Assert;
import com.suyun.core.module.customer.entity.Address;
import com.suyun.core.module.customer.service.AddressService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 地址信息 前端Rest API
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@RestController
@RequestMapping("/api/address")
@AllArgsConstructor
@Slf4j
public class AddressController extends AbstractApiResultController {

    private final AddressService addressService;

    /**
     * 根据客户id获取客户所有收获地址
     * @return
     */
    @GetMapping("addressList")
    public List<Address> getAddressList(){
        return addressService.getAddressList();
    }

    /**
     * 保存收货地址
     * @param address
     * @return
     */
    @PostMapping("addAddress")
    public Address addAddress(@RequestBody @Valid Address address){
        return addressService.addAddress(address);
    }

    /**
     * 初始化编辑
     * @param addressId
     * @return
     */
    @GetMapping("init/{addressId}")
    public Address getAddressById(@PathVariable Long addressId)
    {
        return addressService.getAddressById(addressId);
    }

    /**
     * 修改地址
     * @param address
     * @return
     */
    @PutMapping("edit")
    public Address updateAddress(@RequestBody @Valid Address address){
        Assert.isNull(address.getId(),"地址id不能为空");
        return addressService.updateAddress(address);
    }

    /**
     * 修改地址为默认地址
     * @param id
     */
    @PostMapping("isdefault/{id}")
    public void updateIsDefault(@PathVariable Long id){
        Assert.isNull(id,"地址id不能为空");
        addressService.updateIsDefault(id);
    }

    /**
     * 获取默认地址
     * @return
     */
    @GetMapping("defaultaddress")
    public Address getdefaultaddress(){
        return addressService.getdefaultaddress();
    }
}