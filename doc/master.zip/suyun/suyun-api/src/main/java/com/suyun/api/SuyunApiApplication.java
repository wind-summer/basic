package com.suyun.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication(scanBasePackages = {"com.suyun.common","com.suyun.core","com.suyun.api"})
public class SuyunApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuyunApiApplication.class, args);
	}
}
