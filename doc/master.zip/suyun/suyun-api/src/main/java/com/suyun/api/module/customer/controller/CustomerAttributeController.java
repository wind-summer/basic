package com.suyun.api.module.customer.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@RestController
@RequestMapping("/customer/customerAttribute")
public class CustomerAttributeController extends AbstractApiResultController {

}

