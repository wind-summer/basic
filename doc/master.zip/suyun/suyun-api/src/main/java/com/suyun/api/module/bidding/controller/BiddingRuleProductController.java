package com.suyun.api.module.bidding.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.validator.Assert;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.suyun.core.module.bidding.service.BiddingRuleProductService;
import com.suyun.core.module.bidding.service.dto.BiddingOrderDTO;
import com.suyun.core.module.bidding.service.dto.BiddingProductDTO;
import com.suyun.core.module.bidding.service.dto.CustomerDepositDTO;
import com.suyun.core.module.bidding.service.dto.HotBiddingProductDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@RestController
@RequestMapping("/api/bidding/product")
@AllArgsConstructor
@Slf4j
public class BiddingRuleProductController extends AbstractApiResultController {

    private final BiddingRuleProductService biddingRuleProductService;

    /**
     * 获取检查是否交保证金
     * @return
     */
    @GetMapping("check")
    public CustomerDepositDTO checkCustomerDeposit(@RequestParam(value = "id",required = true) Long id){
        return biddingRuleProductService.checkCustomerDeposit(id);
    }

    /**
     * 出价购买
     * @return
     */
    @PostMapping ("bid")
    public void bidBiddingProduct(@RequestBody @Valid BiddingRecord biddingRecord){
        biddingRuleProductService.checkBiddingProductStatus(biddingRecord.getBiddingProductId());
        biddingRuleProductService.bidBiddingProduct(biddingRecord);
    }

    /**
     * 分页查询
     * @param page
     * @return
     */
    @GetMapping("/list")
    @AuthIgnore
    public Page<BiddingProductDTO> queryBiddingRuleProduct(@RequestParam Map<String, Object> params, Page<BiddingProductDTO> page) {
        return biddingRuleProductService.queryBiddingRuleProductApi(params,page);
    }

    /**
     * 获取竞价产品详情
     * @return
     */
    @GetMapping("info")
    @AuthIgnore
    public BiddingProductDTO getBiddingProductById(@RequestParam(value = "id",required = true,defaultValue = "0") Long id){
        biddingRuleProductService.checkBiddingProductStatus(id);
        return biddingRuleProductService.getBiddingProductInfoById(id);
    }

    /**
     * 下单
     * @param biddingOrderDTO
     * @return
     */
    @PostMapping("/order")
    public void getBiddingRecordById(@RequestBody BiddingOrderDTO biddingOrderDTO) {
        biddingRuleProductService.createBiddingOrder(biddingOrderDTO);
    }

    /**
     * 热门竞拍list
     * @return
     */
    @GetMapping("/hot")
    @AuthIgnore
    public List<HotBiddingProductDTO> queryHotBiddingProduct(Page page) {
        return biddingRuleProductService.queryHotBiddingProduct(page);
    }

    /**
     * 统计围观次数
     * @return
     */
    @GetMapping("/onlooker")
    @AuthIgnore
    public void onlookers(Long id) {
        Assert.isNull(id,"ID 不能为空");
        biddingRuleProductService.addOnlookers(id);
    }
}

