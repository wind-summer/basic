package com.suyun.api.module.product.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.product.entity.Category;
import com.suyun.core.module.product.entity.CollectionProduct;
import com.suyun.core.module.product.entity.PriceRecord;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.module.product.service.CategoryService;
import com.suyun.core.module.product.service.CollectionProductService;
import com.suyun.core.module.product.service.ProductService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @author jos
 * @version V1.0
 * @Description: TODO
 * @date 17:57 2017/12/7
 */
@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/api/product")
public class ProductController extends AbstractApiResultController {
    private final ProductService productService;
    private final CategoryService categoryService;
    /**
     * 自营产品分页查询
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/list")
    @AuthIgnore
    public Page<Sku> selectSkuList(@RequestParam Map<String,Object> params, Page<Sku> page, ServletRequest request){
        //获取请求token，如果token不存在，直接返回401
        String token = getRequestToken((HttpServletRequest) request);
        params.put("token",token);
        params.put("is_show",1);
        params.put("is_sale",1);
        return productService.selectSkuList(params,page);
    }

    /**
     * 添加自选产品
     * @param collectionProduct
     */
    @PostMapping("/collection")
    public void addCollectionProduct(@RequestBody @Valid CollectionProduct collectionProduct){
        if(log.isDebugEnabled()){
            log.debug("添加自选产品数据：{}",collectionProduct);
        }
        productService.addCollectionProduct(collectionProduct);
    }

    /**
     * 自选产品分页查询
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/collection")
    public Page<Sku> queryCollectionProduct(@RequestParam Map<String,Object> params,Page<Sku> page){
        if(log.isDebugEnabled()){
            log.debug("参数params，skuId：{}",params );
        }
        return productService.queryCollectionProduct(params,page);
    }

    /**
     * 删除自选产品
     * @param skuId 必须有skuId
     */
    @DeleteMapping("/collection/{skuId}")
    public void deleteCollectionProduct(@PathVariable Long skuId){
        if(log.isDebugEnabled()){
            log.debug("删除一条记录，skuId：{}",skuId  );
        }
        productService.deleteCollectionProduct(skuId);
    }

    /**
     * 根据父级id查询分类
     * @param parentId
     * @return
     */
    @GetMapping("/category")
    @AuthIgnore
    public List<Category> selectCategoryList(@RequestParam(value = "parent",required = false,defaultValue = "0") Long parentId){
        return productService.selectCategoryList(parentId);
    }

    /**
     *根据skuId查询价格波动记录
     * @param SkuId
     * @return
     */
    @GetMapping("/record")
    @AuthIgnore
    public List<PriceRecord> findRecordBySkuId(@RequestParam(value = "id",required = true,defaultValue = "0") Long SkuId){
        return productService.selectRecordBySkuId(SkuId);
    }

    /**
     * 获取分类名称
     * @param id
     * @return
     */
    @GetMapping("categoryname")
    @AuthIgnore
    public Category findCategory(@RequestParam Long id){
        return categoryService.findById(id);
    }


    /**
     * 获取请求的token
     */
    private String getRequestToken(HttpServletRequest httpRequest){
        //从header中获取token
        String token = httpRequest.getHeader("token");

        //如果header中不存在token，则从参数中获取token
        if(StringUtils.isBlank(token)){
            token = httpRequest.getParameter("token");
        }

        return token;
    }
}
