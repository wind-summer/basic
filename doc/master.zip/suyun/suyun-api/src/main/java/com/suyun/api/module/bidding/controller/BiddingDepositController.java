package com.suyun.api.module.bidding.controller;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.common.sms.BizType;
import com.suyun.common.sms.MsgService;
import com.suyun.common.sms.VerificationDTO;
import com.suyun.common.validator.Assert;
import com.suyun.core.module.bidding.entity.BiddingDeposit;
import com.suyun.core.module.bidding.service.BiddingDepositService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import com.suyun.common.mvc.controller.AbstractApiResultController;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wlf
 * @since 2017-12-28
 */
@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/api/bidding/deposit")
public class BiddingDepositController extends AbstractApiResultController {

    private final BiddingDepositService biddingDepositService;

    private final MsgService msgService;
    /**
     * <p>
     *   交押金
     * </p>
     *
     * @param biddingDeposit
     */
    @PostMapping("/add")
    public void addBiddingRuleAndProduct(@RequestBody @Valid BiddingDeposit biddingDeposit){
        Assert.isNull(biddingDeposit.getVerifyCode(),"验证码不能为空");
        Assert.isNull(biddingDeposit.getMobileNumber(),"手机号码不能为空");
        if(!CurrentUserUtils.getLogin().getMobileNo().equals(biddingDeposit.getMobileNumber())){
            throw new BizException("手机号和当前登录人手机号不一致");
        }
        Boolean isPass = msgService.verifyRandomCode(new VerificationDTO()
                .setBizType(BizType.OTHER)
                .setPhone(biddingDeposit.getMobileNumber())
                .setVerificationCode(biddingDeposit.getVerifyCode()));
        if(!isPass){
            throw new BizException("验证码校验失败");
        }
        biddingDepositService.addBiddingDeposit(biddingDeposit);
    }
}

