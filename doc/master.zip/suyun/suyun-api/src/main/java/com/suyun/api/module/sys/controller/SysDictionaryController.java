package com.suyun.api.module.sys.controller;


import com.suyun.api.annotation.AuthIgnore;
import com.suyun.core.sys.service.SysDictionaryService;
import com.suyun.core.sys.service.dto.DictionaryDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.suyun.common.mvc.controller.AbstractApiResultController;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 系统数据字典 前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-11-30
 */
@RestController
@RequestMapping("/api/dictionary")
@AllArgsConstructor
@Slf4j
public class SysDictionaryController extends AbstractApiResultController {

    private final SysDictionaryService dictionaryService;

    @GetMapping("batch")
    @AuthIgnore
    public List<DictionaryDTO> findByParentCodeBatch(@RequestParam String[] parentCodes){
        log.debug(" Find dictionaries by parentCode:{}",parentCodes);
        List<DictionaryDTO> result = new ArrayList<>();
        for (String parentCode : parentCodes) {
            DictionaryDTO dictionaryDTO = dictionaryService.findDictionariesByParent(parentCode);
            if(dictionaryDTO!=null){
                result.add(dictionaryDTO);
            }
        }
        return result;
    }


    @GetMapping("single")
    @AuthIgnore
    public DictionaryDTO findByParentCode(@RequestParam String parentCode){
        return dictionaryService.findDictionariesByParent(parentCode);
    }

}

