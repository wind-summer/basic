package com.suyun.api.module.account.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.account.service.dto.AccountDetailDTO;
import com.suyun.core.module.account.service.dto.WithDrawDTO;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/api/account")
public class AccountController extends AbstractApiResultController {

    private final AccountService accountService;

    /**
     * 客户提现查看
     *
     * @return
     */
    @GetMapping("with")
    public WithDrawDTO findWithDraw() {
        return accountService.findWithDraw();
    }

    /**
     * 客户账户信息查询
     *
     * @return
     */
    @GetMapping("my")
    public AccountDetailDTO accountBalance() {
        return accountService.findBalanceByCustomerId();
    }


}

