package com.suyun.api.module.customer.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.customer.entity.CustomerLogin;
import com.suyun.core.module.customer.exception.LoginFailException;
import com.suyun.core.module.customer.service.CustomerLoginService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 客户登陆信息 前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@RestController
@RequestMapping("/api/user")
@AllArgsConstructor
@Slf4j
public class CustomerLoginController extends AbstractApiResultController {

    private final CustomerLoginService customerLoginService;


    /**
     * 获取前客户下所有员工
     * @param customerLogin
     * @return
     */
    @GetMapping("all")
    public Page<CustomerLogin> getUserList(CustomerLogin customerLogin, Page<CustomerLogin> page){
        return customerLoginService.getUserAll(customerLogin,page);
    }

    /**
     * 新增客户员工信息
     * @param customerLogin
     */
    @PostMapping("add")
    public void addUser(@RequestBody @Valid CustomerLogin customerLogin){
        if(!customerLoginService.getPhoneIsNull(customerLogin.getMobileNo())){
            throw new LoginFailException("手机号码已存在，请重新录入！");
        }
        if(!customerLoginService.getUserNameIsNull(customerLogin.getUserName())){
            throw new LoginFailException("员工姓名已存在，请重新录入！");
        }
        customerLoginService.addCustomerUser(customerLogin);
    }

    /**
     * 根据员工id获取员工信息
     * @param userId
     * @return
     */
    @GetMapping("init/{userId}")
    public CustomerLogin getCustomerLoginById(@PathVariable Long userId){
        return customerLoginService.selectById(userId);
    }

    /**
     * 修改客户员工信息
     * @param customerLogin
     */
    @PutMapping("update")
    public void updateUser(@RequestBody CustomerLogin customerLogin){
        customerLoginService.updateCustomerUser(customerLogin);
    }

    /**
     * 删除客户员工信息
     * @param id
     */
    @DeleteMapping("{id}")
    public void deleteUser(@PathVariable Long id){
        customerLoginService.deleteCustomerUser(id);
    }

    /**
     * 校验当前手机号码是否存在
     * @param phoneNo
     * @return false
     */
    @GetMapping("checkPhone/{phoneNo}")
    @AuthIgnore
    public boolean checkPhone(@PathVariable String phoneNo){
        return customerLoginService.getPhoneIsNull(phoneNo);
    }

    /**
     * 校验当前帐号是否存在
     * @param login
     * @return
     */
    @GetMapping("checkLogin/{login}")
    @AuthIgnore
    public boolean checkLogin(@PathVariable String login){
        return customerLoginService.getLoginIsNull(login);
    }

    /**
     * 校验员工姓名是否存在
     * @param userName
     * @return
     */
    @GetMapping("checkUserName/{userName}")
    public boolean checkUserName(@PathVariable String userName){
        return customerLoginService.getUserNameIsNull(userName);
    }
}

