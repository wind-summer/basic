package com.suyun.api.module.product.controller;


import afu.org.checkerframework.checker.units.qual.C;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.api.annotation.AuthIgnore;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.mvc.vm.PageVM;
import com.suyun.common.utils.ApiResult;
import com.suyun.common.utils.Query;
import com.suyun.core.module.product.entity.Category;
import com.suyun.core.module.product.entity.CustomerProduct;
import com.suyun.core.module.product.service.CategoryService;
import com.suyun.core.module.product.service.CustomerProductService;
import com.suyun.core.oss.cloud.OSSFactory;
import com.suyun.core.oss.service.SysOssService;
import com.suyun.core.utils.CurrentUserUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Delete;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 产品表 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-12-06
 */
@AllArgsConstructor
@Slf4j
@RestController
@RequestMapping("/api/customerproduct")
public class CustomerProductController extends AbstractApiResultController {
    private CustomerProductService customerProductService;
    private final CategoryService categoryService;
    /**
     * 添加产品
     * @param customerProduct
     */
    @PostMapping("/add")
    public void addCustomerProduct(@RequestBody CustomerProduct customerProduct){
        customerProductService.addCustomerProduct(customerProduct);
    }

    /**
     * 根据产品id产查询单条产品
     * @param customerProductId
     * @return
     */
    @GetMapping("/info")
    @AuthIgnore
    public CustomerProduct findCustomerProductById(@RequestParam(value = "id",required = true,defaultValue = "0") Long customerProductId){
        return customerProductService.findCustomerProductById(customerProductId);
    }

    /**
     * 编辑产品
     * @param customerProduct
     */
    @PutMapping("/edit")
    public void editCustomerProduct(@RequestBody CustomerProduct customerProduct){
        customerProductService.editCustomerProduct(customerProduct);
    }

    /**
     * 产品下架
     * @param
     */
    @PutMapping("active")
    public void editByIsShow(@RequestBody CustomerProduct customerProduct){
        if(log.isDebugEnabled()){
            log.debug("customerProduct is :{}" ,customerProduct);
        }
        customerProductService.editByIsShow(customerProduct);
    }

    /**
     * 查询分页
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/list")
    public Page<CustomerProduct> queryCustomerProductList(@RequestParam Map<String, Object> params,Page<CustomerProduct> page){
        params.put("user_id", CurrentUserUtils.getLogin().getCustomerId());
        return customerProductService.queryCustomerProductList(params,page);
    }

    /**
     * 查询所有用户的分页
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/all")
    @AuthIgnore
    public Page<CustomerProduct> queryAllCustomerProductList(@RequestParam Map<String, Object> params,Page<CustomerProduct> page){
        params.put("is_show", 1);
        return customerProductService.queryCustomerProductList(params,page);
    }

    /**
     * 分页
     * @param page
     * @return
     */
    @GetMapping("/page")
    public PageVM find(Page page) {
        EntityWrapper ew = new EntityWrapper<CustomerProduct>();
        ew.where("is_show",true).and("user_id", CurrentUserUtils.getLogin().getCustomerId());
        page.getCondition();
        log.debug("page is :{}",page);
        Page<CustomerProduct> pageDemo = customerProductService.selectMapsPage(page,ew);
        return toPageVM(pageDemo);
    }

    /**
     * 查出公司自己的分类
     * userId
     * @param userId
     * @return
     */
    @AuthIgnore
    @GetMapping("category")
    public List<Category> findByCustormId(@RequestParam(value = "id",defaultValue = "0") Long userId){
        if(userId <= 0 || !(userId instanceof Long)){
            throw new BizException("用户id不合法");
        }
        return customerProductService.findCategoryByCustormId(userId);
    }

    /**
     * 查询所有分类
     * @return
     */
    @GetMapping("categoryall")
    @AuthIgnore
    public List<Category> selectCategoryList(){
        return categoryService.selectByType(1);
    }




}

