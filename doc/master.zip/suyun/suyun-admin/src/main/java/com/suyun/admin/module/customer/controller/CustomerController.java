package com.suyun.admin.module.customer.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.validator.Assert;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.customer.entity.Customer;
import com.suyun.core.module.customer.enums.CustomerStatusEnum;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.customer.service.dto.CustomerAttributeDTO;
import com.suyun.core.module.customer.service.dto.CustomerDTO;
import com.suyun.core.module.customer.service.dto.CustomerDetailDTO;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-12-01
 */
@RestController
@RequestMapping("/sys/customer")
@AllArgsConstructor
public class CustomerController extends AbstractApiResultController {

   private final CustomerService customerService;

   private final AccountService accountService;

    /**
     * 新增客户信息
     * @param customerDetailDTO
     */
   @PostMapping("add")
   //@RequiresPermissions("sys:customer:add")
   public void addCustomer(@RequestBody @Valid CustomerDetailDTO customerDetailDTO){
       Long customerId = customerService.addCustomer(new CustomerDTO(this.getCustomer(customerDetailDTO),null,customerService.getAttribute(customerDetailDTO),null,customerDetailDTO.getToken()));
       //调用创建帐号接口
       accountService.createAccount(customerId);
   }

    /**
     * 修改初始化/查看-客户信息
     * @param customerId
     * @return
     */
   @GetMapping("/{customerId}")
   //@RequiresPermissions("sys:customer:get")
   public CustomerDetailDTO getCustomer(@PathVariable Long customerId){
       CustomerDTO customerDTO = customerService.getCustomer(customerId);
       CustomerDetailDTO customerDetailDTO = new CustomerDetailDTO();
       BeanUtils.copyProperties(customerDTO.getCustomer(),customerDetailDTO);
       if(null != customerDTO.getAttributes() && customerDTO.getAttributes().size()>0){
           customerService.getCustomerDetailDTO(customerDetailDTO,customerDTO.getAttributes());
       }
       return customerDetailDTO;
   }

    /**
     * 获取所有客户信息
     * @param params
     * @param page
     * @return
     */
    @GetMapping("all")
    //@RequiresPermissions("sys:customer:list")
    public Page<CustomerDetailDTO> getCustomerList(@RequestParam Map<String, Object> params, Page<CustomerDetailDTO> page){
        Page<CustomerDetailDTO> vmPage = new Page<CustomerDetailDTO>();
        page = customerService.getCustomerList(params,page);
        BeanUtils.copyProperties(page,vmPage);
        vmPage.setRecords(page.getRecords().stream().map(customer -> {
            List<CustomerAttributeDTO> customerAttributes =  customerService.getCustomerAttributes(customer.getId());
            if(null != customerAttributes && customerAttributes.size()>0){
                customerService.getCustomerDetailDTO(customer,customerAttributes);
            }
            return customer;
        }).collect(Collectors.toList()));
        return vmPage;
    }

    /**
     * 修改保存客户信息
     * @param customerDetailDTO
     */
    @PutMapping("update")
    //@RequiresPermissions("sys:customer:edit")
    public void updateUser(@RequestBody @Valid CustomerDetailDTO customerDetailDTO){
        Long customerId =  customerService.updateCustomerByBackstage(new CustomerDTO(this.getCustomer(customerDetailDTO),null,customerService.getAttribute(customerDetailDTO),null,customerDetailDTO.getToken()));
        accountService.createAccount(customerId);
    }

    /**
     * 校验当前手机号码是否存在
     * @param phoneNo
     * @return false
     */
    @GetMapping("checkPhone/{phoneNo}")
    //@RequiresPermissions("sys:customer:check")
    public boolean checkPhone(@PathVariable String phoneNo){
        Assert.isNull(phoneNo,"手机号码不能为空");
        return customerService.getPhoneIsNull(phoneNo);
    }

    /**
     * 校验公司是否存在
     * @param name
     * @return
     */
    @GetMapping("checkName/{name}")
    public boolean checkName(@PathVariable String name){
        return customerService.getNameIsNull(name);
    }

    /**
     * 校验邮箱是否重复
     * @param email
     * @return
     */
    @PostMapping("checkEmail")
    public boolean checkEmail(@RequestParam  String email,@RequestParam Long id){
        return customerService.getEmailIsNull(email,id);
    }

    /**
     * 校验营业执照是否重复
     * @param organizationRegNo
     * @return
     */
    @PostMapping("checkOrganizationRegNo")
    public boolean checkOrganizationRegNo(@RequestParam  String organizationRegNo,@RequestParam Long id){
        return customerService.getOrganizationRegNoIsNull(id,organizationRegNo);
    }

    /**
     * 编辑客户信息时校验公司名称是否重复
     * @param name
     * @param id
     * @return
     */
    @GetMapping("editCheckName")
    public boolean editCheckName(@RequestParam String name,@RequestParam Long id){
        return  customerService.getNameIsNullByBackstage(name,id);
    }

    /**
     * 审核通过
     * @param customerId
     */
    @PutMapping("success/{customerId}")
    //@RequiresPermissions("sys:customer:audit")
    public void updateAuditSuccess(@PathVariable Long customerId)
    {
        Assert.isNull(customerId,"客户id不能为空");
        customerService.updateAuditStatus(customerId, CustomerStatusEnum.SUCCESS,null);

        //调用创建帐号接口
        accountService.createAccount(customerId);
    }

    /**
     * 审核未通过
     * @param customerId
     */
    @PutMapping("fail/{customerId}")
    //@RequiresPermissions("sys:customer:reject")
    public void updateAuditFail(@PathVariable Long customerId,@RequestParam String failReasonl)
    {
        Assert.isNull(customerId,"客户id不能为空");
        Assert.isNull(failReasonl,"审核不通过原因不能为空");
        customerService.updateAuditStatus(customerId, CustomerStatusEnum.FAIL,failReasonl);
    }

    /**
     * 审核-冻结
     * @param customerId
     */
    @PutMapping("frozen/{customerId}")
    //@RequiresPermissions("sys:customer:frozen")
    public void updateAuditFrozen(@PathVariable Long customerId)
    {
        Assert.isNull(customerId,"客户id不能为空");
        customerService.updateAuditStatus(customerId, CustomerStatusEnum.FROZEN,null);
    }

    /**
     * 解冻
     * @param customerId
     */
    @PutMapping("thaw/{customerId}")
    public void updateAuditThaw(@PathVariable Long customerId){
        customerService.updateAudisStatusByThaw(customerId);
    }

    /**
     * 获取Customer对象
     * @param customerDetailDTO
     * @return
     */
    private Customer getCustomer( CustomerDetailDTO customerDetailDTO){
        Customer customer = new Customer();
        BeanUtils.copyProperties(customerDetailDTO,customer);
        if(null == customer.getOrganizationTegNo()){
            customer.setOrganizationTegNo(customerDetailDTO.getBizCreditCode());
        }
        return customer;
    }

}

