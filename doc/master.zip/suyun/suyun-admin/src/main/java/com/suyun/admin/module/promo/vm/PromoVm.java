package com.suyun.admin.module.promo.vm;

import com.suyun.core.module.promo.entity.SalesPromo;
import lombok.Data;

/**
 * @author caosg
 * @version V1.0
 * @Description: web 数据封装类
 * @date 2017/12/7 上午9:23
 */
@Data
public class PromoVm extends SalesPromo{

    Long[] productIds;

    Long[] userIds;
}
