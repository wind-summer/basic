package com.suyun.admin.module.order.task;

import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.OrderStatus;
import com.suyun.core.module.order.enums.YesOrNo;
import com.suyun.core.module.order.service.OrderConstant;
import com.suyun.core.module.order.service.OrderService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * @author caosg
 * @version V1.0
 * @Description: 定时任务，处理超时订单作废
 * @date 2017/12/14 下午7:16
 */
@Component("orderTimeoutTask")
@Slf4j
@AllArgsConstructor
public class OrderTimeoutTask {

    private final OrderService orderService;

    private final ZSetOperations<String,Object> zSetOperations;

    /**
     * 查询超时未确认订单，并取消
     */
    public void cancelTimeoutOrder(){

        long currentTime = System.currentTimeMillis();
        log.debug("OrderTimeoutTask is running ...........current time:{} ",currentTime);

        Set<Object> orderIds = zSetOperations.rangeByScore(OrderConstant.AWAITING_CONFIRM_ORDER_KEY,0,currentTime);
        orderIds.stream().forEach(o -> {
            log.info(" Time out order:{}  ",o);
            Long orderId = Long.valueOf(String.valueOf(o));
            Order order = orderService.selectById(orderId);
            if(order.getOrderStatus()== OrderStatus.AWAITING_CONFIRM && orderService.handleEvent(orderId, OrderEvent.CANCEL,false ,"autoCancel")){
                zSetOperations.remove(OrderConstant.AWAITING_CONFIRM_ORDER_KEY,orderId);

            }else {
                zSetOperations.remove(OrderConstant.AWAITING_CONFIRM_ORDER_KEY,orderId);
            }
        });

    }

    /**
     * 查询超时未支付订单，并取消
     */
    public void cancelTimeoutNoPayOrder(){

        long currentTime = System.currentTimeMillis();
        log.debug("OrderTimeoutTask is running ...........current time:{} ",currentTime);

        Set<Object> orderIds = zSetOperations.rangeByScore(OrderConstant.AWAITING_PAY_ORDER_KEY,0,currentTime);
        orderIds.stream().forEach(o -> {
            log.info(" Time out order of no pay :{}  ",o);
            Long orderId = Long.valueOf(String.valueOf(o));
            Order order = orderService.selectById(orderId);
            if(order.getOrderStatus() == OrderStatus.AWAITING_PAYMENT && order.getPaymentStatus()== YesOrNo.NO) {

                if(orderService.handleEvent(orderId, OrderEvent.CANCEL,false ,"autoCancel")) {
                    zSetOperations.remove(OrderConstant.AWAITING_PAY_ORDER_KEY, orderId);
                }
            }else {
                zSetOperations.remove(OrderConstant.AWAITING_PAY_ORDER_KEY, orderId);
            }
        });

    }

}
