package com.suyun.admin.module.promo.controller;


import com.suyun.admin.module.promo.vm.PromoVm;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.promo.service.SalesPromoService;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 促销活动 前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-12-06
 */
@RestController
@RequestMapping("/sys/promo")
@AllArgsConstructor
public class SalesPromoController extends AbstractApiResultController {

    private final SalesPromoService salesPromoService;

    @PostMapping
    //@RequiresPermissions("sys:promo:create")
    public void createPromo(@RequestBody @Valid PromoVm promoVm){
        salesPromoService.addSalesPromo(promoVm,promoVm.getProductIds(),promoVm.getUserIds());
    }

}

