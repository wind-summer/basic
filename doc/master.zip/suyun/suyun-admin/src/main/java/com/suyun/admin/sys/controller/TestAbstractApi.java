package com.suyun.admin.sys.controller;

import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.exception.BizException;
import com.suyun.core.sys.entity.SysUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.LongStream;
import static java.util.stream.Collectors.*;
/**
 * @author caosg
 * @version V1.0
 * @Description: demo
 * @date 2017/11/23 上午10:07
 */
@RestController
@RequestMapping("/api")
public class TestAbstractApi extends AbstractApiResultController {
    @GetMapping("/test/{userId}")
    public SysUser getString(@PathVariable Long userId){
        if(userId==4L) {
            throw new BizException("业务错误", 400);
        }
        SysUser user = new SysUser();
        user.setUserId(userId);
        user.setMobile("1111111111");
        user.setSalt("abdddea");
        return user;
    }

    @GetMapping("/null")
    public void nullResturn(){

    }

    @GetMapping("/list")
    public List<SysUser> findUsers(){
       return LongStream.of(1L,2L,3L).mapToObj(id ->{
            SysUser user = new SysUser();
            user.setUserId(id);
            user.setMobile("1111111111");
            user.setSalt("abdddea");
            return user;
        }).collect(toList());
    }



}
