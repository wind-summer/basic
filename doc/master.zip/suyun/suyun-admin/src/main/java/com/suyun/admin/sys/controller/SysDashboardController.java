package com.suyun.admin.sys.controller;

import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.utils.ApiResult;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.bidding.service.BiddingRecordService;
import com.suyun.core.module.customer.service.CustomerService;
import com.suyun.core.module.order.service.OrderService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @author caosg
 * @version V1.0
 * @Description: 系统后台仪表盘
 * @date 2018/1/18 上午10:17
 */
@RestController
@RequestMapping("/sys/dashboard")
@AllArgsConstructor
public class SysDashboardController extends AbstractApiResultController{

    private final OrderService orderService;
    private final CustomerService customerService;
    private final AccountApplyService accountApplyService;
    private final BiddingRecordService biddingRecordService;

    /**
     * 代办事项数量
     * @return
     */
    @GetMapping("/count")
    public ApiResult stats(){
                accountApplyService.rechargeCount();
                accountApplyService.withDrawCount();
                biddingRecordService.countAwaitBiddingRecord();
        Map<String,Integer> map = orderService.countOrderStatus();
        map.put("awaitAuditCustomers",customerService.getCustomerByStatus());
        map.put("rechargeAccounts",accountApplyService.rechargeCount());
        map.put("withDrawAccounts",accountApplyService.withDrawCount());
        map.put("biddingOrders",biddingRecordService.countAwaitBiddingRecord());
        return ApiResult.ok(map);
    }
}
