package com.suyun.admin.module.bidding.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.bidding.entity.BiddingRule;
import com.suyun.core.module.bidding.service.BiddingRuleProductService;
import com.suyun.core.module.bidding.service.dto.BiddingProductDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@RestController
@RequestMapping("/bidding/product")
@AllArgsConstructor
@Slf4j
public class BiddingRuleProductController extends AbstractApiResultController {

    private final BiddingRuleProductService biddingRuleProductService;

    /**
     * <p>
     *   新增一条biddingRule（包括竞价规则和产品关联数据）
     * </p>
     *
     * @param biddingRule
     */
    @PostMapping("/add")
    //@RequiresPermissions("bidding:product:add")
    public void add(@RequestBody @Valid BiddingRule biddingRule){
        //设置开始时间和结束时间秒数为0
        biddingRule
                .setStartDate(DateUtils.setSeconds(biddingRule.getStartDate(),0))
                .setEndDate(DateUtils.setSeconds(biddingRule.getEndDate(),0));
        biddingRuleProductService.addBiddingRuleAndProduct(biddingRule);
    }

    /**
     * 分页查询
     * @param page
     * @return
     */
    @GetMapping("/list")
    //@RequiresPermissions("bidding:product:list")
    public Page<BiddingProductDTO> queryBiddingRuleProduct(@RequestParam Map<String, Object> params, Page<BiddingProductDTO> page) {
        return biddingRuleProductService.queryBiddingRuleProduct(params,page);
    }

    /**
     * 获取竞价详情
     * @return
     */
    @GetMapping("info")
    //@RequiresPermissions("bidding:product:info")
    public BiddingProductDTO getBiddingProductById(@RequestParam(value = "id",required = true,defaultValue = "0") Long id){
        return biddingRuleProductService.getBiddingProductInfoById(id);
    }

}

