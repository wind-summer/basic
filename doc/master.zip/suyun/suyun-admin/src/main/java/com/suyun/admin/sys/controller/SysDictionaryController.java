package com.suyun.admin.sys.controller;


import com.alibaba.druid.util.StringUtils;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.mvc.vm.PageVM;
import com.suyun.core.sys.entity.SysDictionary;
import com.suyun.core.sys.service.SysDictionaryService;
import com.suyun.core.sys.service.dto.DictionaryDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * 系统数据字典 前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-11-30
 */
@RestController
@RequestMapping("/sys/dictionary")
@AllArgsConstructor
@Slf4j
public class SysDictionaryController extends AbstractApiResultController {

    private final SysDictionaryService dictionaryService;

    @GetMapping("list")
    public PageVM find(Page page){
        Page<SysDictionary> dictionaryPage = dictionaryService.selectPage(page);
       return toPageVM(dictionaryPage);
    }

    @PostMapping("add")
    public void add(@RequestBody SysDictionary sysDictionary){
        if(log.isDebugEnabled()){
            log.debug(" Add dictionary :{}",sysDictionary);
        }
        Optional.ofNullable(dictionaryService.selectOne(new EntityWrapper<SysDictionary>().eq("dict_name",sysDictionary.getDictName()))).map(dictionary->{
            throw new BizException("名称已经存在，请重新填写");
        });
        Optional.ofNullable(dictionaryService.selectOne(new EntityWrapper<SysDictionary>().eq("dict_code",sysDictionary.getDictCode()))).map(dictionary->{
            throw new BizException("编号已经存在，请重新填写");
        });
        dictionaryService.addDictionary(sysDictionary);
    }

    @PutMapping("edit")
    public void edit(@RequestBody SysDictionary sysDictionary){
        if(log.isDebugEnabled()) {
            log.debug(" Edit dictionary :{}", sysDictionary);
        }
        Optional.ofNullable(dictionaryService.selectOne(new EntityWrapper<SysDictionary>().eq("dict_name",sysDictionary.getDictName()))).map(dictionary->{
            if(!dictionary.getId().equals(sysDictionary.getId())){
                throw new BizException("名称已经存在，请重新填写");
            }
            return true;
        });
        Optional.ofNullable(dictionaryService.selectOne(new EntityWrapper<SysDictionary>().eq("dict_code",sysDictionary.getDictCode()))).map(dictionary->{
            if(!dictionary.getId().equals(sysDictionary.getId())){
                throw new BizException("编号已经存在，请重新填写");
            }
            return true;
        });
        dictionaryService.editDictionary(sysDictionary);
    }

    @GetMapping("parents")
    public List<DictionaryDTO> findByParentCode(@RequestParam String[] parentCodes){
        if(log.isDebugEnabled()){
            log.debug(" Find dictionaries by parentCode:{}",parentCodes);
        }
        return dictionaryService.findDictionariesByParentBatch(parentCodes);
    }

    /**
     * 删除数据字典
     * @param id
     */
    @DeleteMapping("del")
    public void editActive(@RequestParam Long id){
        dictionaryService.editActive(id);
    }
}

