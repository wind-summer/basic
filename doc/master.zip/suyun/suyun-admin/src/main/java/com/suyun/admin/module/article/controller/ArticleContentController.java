package com.suyun.admin.module.article.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 文章详细内容 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
@RestController
@RequestMapping("/article/articleContent")
public class ArticleContentController extends AbstractApiResultController {

}

