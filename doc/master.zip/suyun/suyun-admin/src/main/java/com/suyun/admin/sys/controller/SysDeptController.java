package com.suyun.admin.sys.controller;

import com.suyun.common.utils.ApiResult;
import com.suyun.common.utils.Constant;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.sys.entity.SysDept;
import com.suyun.core.sys.service.SysDeptService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;


/**
 * 部门管理
 * 
 * @author csg
 *
 * @date 2017-06-20 15:23:47
 */
@RestController
@RequestMapping("/sys/dept")
public class SysDeptController extends AbstractController {
	@Autowired
	private SysDeptService sysDeptService;
	@Autowired
	private ApplicationProperties applicationProperties;
	
	/**
	 * 列表
	 */
	@RequestMapping("/list")
	@RequiresPermissions("sys:dept:list")
	public List<SysDept> list(){
		List<SysDept> deptList = sysDeptService.queryList(new HashMap<>());

		return deptList;
	}

	/**
	 * 选择部门(添加、修改菜单)
	 */
	@RequestMapping("/select")
	@RequiresPermissions("sys:dept:select")
	public ApiResult select(){
		List<SysDept> deptList = sysDeptService.queryList(new HashMap<>());
		//添加一级部门
		if( applicationProperties.getSecurity().getAdminIds().indexOf(getUserId()) != -1){
			SysDept root = new SysDept();
			root.setDeptId(0L);
			root.setName("一级部门");
			root.setParentId(-1L);
			root.setOpen(true);
			deptList.add(root);
		}

		return ApiResult.ok().put("deptList", deptList);
	}

	/**
	 * 上级部门Id(管理员则为0)
	 */
	@RequestMapping("/info")
	@RequiresPermissions("sys:dept:list")
	public ApiResult info(){
		long deptId = 0;
		if(applicationProperties.getSecurity().getAdminIds().indexOf(getUserId()) == -1){
			SysDept dept = sysDeptService.queryObject(getDeptId());
			deptId = dept.getParentId();
		}

		return ApiResult.ok().put("deptId", deptId);
	}
	
	/**
	 * 信息
	 */
	@RequestMapping("/info/{deptId}")
	@RequiresPermissions("sys:dept:info")
	public ApiResult info(@PathVariable("deptId") Long deptId){
		SysDept dept = sysDeptService.queryObject(deptId);
		
		return ApiResult.ok().put("dept", dept);
	}
	
	/**
	 * 保存
	 */
	@RequestMapping("/save")
	@RequiresPermissions("sys:dept:save")
	public ApiResult save(@RequestBody SysDept dept){
		sysDeptService.save(dept);
		
		return ApiResult.ok();
	}
	
	/**
	 * 修改
	 */
	@RequestMapping("/update")
	@RequiresPermissions("sys:dept:update")
	public ApiResult update(@RequestBody SysDept dept){
		sysDeptService.update(dept);
		
		return ApiResult.ok();
	}
	
	/**
	 * 删除
	 */
	@RequestMapping("/delete")
	@RequiresPermissions("sys:dept:delete")
	public ApiResult delete(long deptId){
		//判断是否有子部门
		List<Long> deptList = sysDeptService.queryDetpIdList(deptId);
		if(deptList.size() > 0){
			return ApiResult.error("请先删除子部门");
		}

		sysDeptService.delete(deptId);
		
		return ApiResult.ok();
	}
	
}
