package com.suyun.admin.module.demo.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.junziqian.customer.service.JzqCustomerService;
import com.suyun.core.module.demo.service.DemoService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 示例Demo 前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-11-23
 */
@RestController
@RequestMapping("/sys/demo")
@AllArgsConstructor
public class DemoController extends AbstractApiResultController {

    private DemoService demoService;

    private JzqCustomerService jzqCustomerService;

    @GetMapping("test")
    public void testOracle(){
        demoService.testOracle();
    }

    @GetMapping("junziqian")
    public void queryOrganizationStatus(@RequestParam String email){
        jzqCustomerService.queryOrganizationStatus(email);
    }
}

