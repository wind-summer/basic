package com.suyun.admin.module.order.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.order.entity.Order;
import com.suyun.core.module.order.entity.OrderPush;
import com.suyun.core.module.order.entity.OrderShipping;
import com.suyun.core.module.order.enums.ContractStatus;
import com.suyun.core.module.order.enums.OrderEvent;
import com.suyun.core.module.order.enums.YesOrNo;
import com.suyun.core.module.order.service.OrderContractService;
import com.suyun.core.module.order.service.OrderPushService;
import com.suyun.core.module.order.service.OrderService;
import com.suyun.core.module.order.service.OrderShippingService;
import com.suyun.core.module.order.service.dto.AdjustParamDTO;
import com.suyun.core.module.order.service.dto.ContractDTO;
import com.suyun.core.module.order.service.dto.OrderDTO;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  后台订单处理
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@RestController
@RequestMapping("/sys/order")
@AllArgsConstructor
public class OrderController extends AbstractApiResultController {

    private final OrderService orderService;

    private final OrderContractService orderContractService;

    private final OrderPushService orderPushService;

    private final OrderShippingService orderShippingService;

    @GetMapping("list")
    //@RequiresPermissions("order:order:list")
    public Page<Order> queryOrder(@RequestParam Map<String,Object> params,Page<Order> orderPage){
        return orderService.queryOrder(params,orderPage);
    }

    /**
     * 根据订单ID查询订单明细
     * @param orderId
     * @return
     */
    @GetMapping("{orderId}")
    //@RequiresPermissions("order:order:info")
    public OrderDTO getOrderById(@PathVariable Long orderId){
        OrderDTO orderDTO = orderService.getOrderById(orderId);
        orderDTO.getOrder().setOrderPush(this.orderPushService.findNewOrderPushById(orderId));
        if(orderDTO.getOrder().getSignStatus()== ContractStatus.SUCCESS||orderDTO.getOrder().getSignStatus()==ContractStatus.PERSIST){
            ContractDTO contractDTO = new ContractDTO();
            contractDTO.setDetailUrl(orderContractService.signDetailLink(orderId));
            contractDTO.setDownloadUrl(orderContractService.signDownloadLink(orderId));
            orderDTO.setContract(contractDTO);
        }
        return orderDTO;
    }

    /**
     * 后台编辑订单
     * @param adjustParamDTO
     */
    @PostMapping
    //@RequiresPermissions("order:order:edit")
    public void editOrder(@RequestBody @Validated AdjustParamDTO adjustParamDTO){
        orderService.editOrder(adjustParamDTO);
    }

    /**
     * 通用订单事件处理
     * @param orderId
     * @param event
     */
    @PostMapping("{orderId}/event")
    //@RequiresPermissions("order:order:event")
    public void handleOrderEvent(@PathVariable Long orderId, @RequestParam("event") OrderEvent event) {
        boolean result ;
        result = orderService.handleEvent(orderId,event,false);
        if(!result){
            throw new BizException("订单状态不符合流程");
        }
    }

    /**
     * 审核通过
     * @param orderId
     */
    @PostMapping("{orderId}/audit")
    //@RequiresPermissions("order:order:audit")
    public void auditOrder(@PathVariable Long orderId){
        boolean result ;
        Order order = orderService.selectById(orderId);
        if(order==null ){
            throw new BizException("订单："+orderId+"不存在");
        }
        if (StringUtils.isEmpty(order.getReserveAttribute1())) {
            throw new BizException("请先保存浪潮客户编码");
        }
        result = orderService.handleEvent(orderId,OrderEvent.AUDIT,false);
        if(!result){
            throw new BizException("订单状态不符合流程");
        }else {
            //上传电子合同
            orderContractService.sign(orderId);
        }
    }


    /**
     * 审核不通过，取消
     * @param orderId
     */
    @PostMapping("{orderId}/cancel")
    //@RequiresPermissions("order:order:cancel")
    public void cancelOrder(@PathVariable Long orderId){
        boolean result ;
        result = orderService.handleEvent(orderId,OrderEvent.CANCEL,false,"manulCancel");
        if(!result){
            throw new BizException("订单状态不符合流程");
        }
    }

    /**
     * 确认支付
     * @param orderId
     */
    @PostMapping("{orderId}/payment")
    //@RequiresPermissions("order:order:pay")
    public void paymentOrder(@PathVariable Long orderId){
        boolean result ;
//        Order order = this.getOrder(orderId);
//        if(order.getPaymentStatus() == YesOrNo.NO){
//            throw new BizException("还没上传支付凭证");
//        }
        result = orderService.handleEvent(orderId,OrderEvent.PAYMENT,false);
        if(!result){
            throw new BizException("订单状态不符合流程");
        }
    }

    /**
     * 发货
     * @param orderId
     */
    @PostMapping("{orderId}/deliver")
    //@RequiresPermissions("order:order:deliver")
    public void deliverOrder(@PathVariable Long orderId){
        List<OrderShipping> orderShippings = orderShippingService.getShippingsByOrderId(orderId);
        if(orderShippings.size() == 0){
            throw   new BizException("暂无发货信息");
        }
        boolean result ;
        result = orderService.handleEvent(orderId,OrderEvent.DELIVER,false);
        if(!result){
            throw new BizException("订单状态不符合流程");
        }
    }

    /**
     * 订单签收,由客户操作
     *
     * @param orderId
     */
    @PostMapping("{orderId}/receive")
    //@RequiresPermissions("order:order:receive")
    public void receive(@PathVariable Long orderId) {
        Order order = this.getOrder(orderId);
        if(order.getShippingStatus() == YesOrNo.NO){
            throw new BizException("订单发货未完成");
        }
        boolean result;
        result = orderService.handleEvent(orderId, OrderEvent.RECEIVE, false);
        if (!result) {
            throw new BizException("订单状态不符合流程");
        }
    }


    /**
     * 查询订单处理日志
     * @param orderId 订单id
     * @return
     */
    @GetMapping("{orderId}/logs")
    //@RequiresPermissions("order:order:log")
    public List<com.suyun.core.module.order.entity.OrderEvent> orderLogs(@PathVariable Long orderId){
        return orderService.queryOrderLog(orderId);
    }

    private Order getOrder(Long orderId){
        Order order = orderService.selectById(orderId);
        if(order == null){
            new BizException("订单:"+orderId+"不存在");
        }
        return order;
    }

    /**
     * 手动推送订单到浪潮ERP
     * @param orderId
     */
    @GetMapping("/orderPush/{orderId}")
    public OrderPush orderPush(@PathVariable Long orderId){
        orderPushService.pushOrderByOrderId(orderId);
        return this.orderPushService.findNewOrderPushById(orderId);
    }

    /**
     * 后台编辑订单后手动同步erp
     * @param adjustParamDTO
     * @author wanggf
     */
    @PostMapping("/orderPush")
    //@RequiresPermissions("order:order:edit")
    public OrderPush editOrderAndErp(@RequestBody @Validated AdjustParamDTO adjustParamDTO){
        orderService.editOrder(adjustParamDTO);
        orderPushService.pushOrderByOrderId(adjustParamDTO.getOrderId());
        return this.orderPushService.findNewOrderPushById(adjustParamDTO.getOrderId());
    }
}

