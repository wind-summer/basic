package com.suyun.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.suyun.common","com.suyun.core","com.suyun.admin"})
public class SuyunAdminApplication  {

	public static void main(String[] args) {
		SpringApplication.run(SuyunAdminApplication.class, args);
	}

}
