package com.suyun.admin.module.financing.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.financing.entity.FinancingApply;
import com.suyun.core.module.financing.entity.FinancingContactLog;
import com.suyun.core.module.financing.service.FinancingApplyService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * <p>
 * 融资申请表 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-12-14
 */
@Slf4j
@RestController
@RequestMapping("/sys/financing")
@AllArgsConstructor
public class FinancingApplyController extends AbstractApiResultController {
    private final FinancingApplyService financingApplyService;

    /**
     * 添加沟通日志
     * @param financingContactLog
     */
    @PostMapping("/addlog")
    //@RequiresPermissions("sys:financing:addlog")
    public void addFinancingContactLog(@RequestBody @Valid FinancingContactLog financingContactLog){
        log.debug("添加沟通日志:{}",financingContactLog);
        financingApplyService.addFinancingcontactLog(financingContactLog);
    }

    /**
     * 编辑融资申请
     * @param financingApply
     */
    @PutMapping("/edit")
    //@RequiresPermissions("sys:financing:edit")
    public void editFinancingApply(@RequestBody @Valid FinancingApply financingApply){
        financingApplyService.editFinancingApply(financingApply);
    }

    /**
     * 查询融资申请列表
     * @param map
     * @param page
     * @return
     */
    @GetMapping("/list")
    //@RequiresPermissions("sys:financing:list")
    public Page<FinancingApply> queryFinancingApplyList(@RequestParam Map<String,Object> map,Page<FinancingApply> page){
        log.debug("查询融资申请列表:{}",page);
        return financingApplyService.queryFinancingApplyList(map,page);
    }

    /**
     *
     * @param id 融资申请表主键id
     * @return
     */
    @GetMapping("info")
    //@RequiresPermissions("sys:financing:info")
    public FinancingApply findById(@RequestParam Long id){
        log.debug("where id : {}",id);
        return financingApplyService.queryById(id);
    }

}

