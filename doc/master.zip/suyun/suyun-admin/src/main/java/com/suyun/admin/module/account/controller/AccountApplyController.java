package com.suyun.admin.module.account.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.account.entity.AccountApply;
import com.suyun.core.module.account.service.AccountApplyService;
import com.suyun.core.module.account.service.dto.RechargeAndDrawDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

/**
 * <p>
 * 账户充值提现申请 后台
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@RestController
@RequestMapping("/sys/apply")
@AllArgsConstructor
@Slf4j
public class AccountApplyController extends AbstractApiResultController {

    private final AccountApplyService accountApplyService;

    /**
     * 充值或者提现查询
     *
     * @param applyId
     * @return
     */
    @GetMapping("find/{applyId}")
    //@RequiresPermissions("sys:apply:info")
    public RechargeAndDrawDTO apply(@PathVariable(required = true) Long applyId) {
        RechargeAndDrawDTO rechargeAndDrawDTO = accountApplyService.findAccountApplyById(applyId);
        if (rechargeAndDrawDTO == null) {
            throw new BizException("查询条件无效");
        }
        return rechargeAndDrawDTO;
    }

    /**
     * 充值成功确认
     *
     * @param applyId
     */
    @PostMapping("success/{applyId}")
    //@RequiresPermissions("sys:apply:audit")
    public void success(@PathVariable(required = true) Long applyId) {
        boolean result = accountApplyService.success(applyId);
        if (!result) {
            throw new BizException("系统异常");
        }
    }

    /**
     * 充值失败确认
     *
     * @param applyId
     */
    @PostMapping("failure/{applyId}")
    //@RequiresPermissions("sys:apply:edit")
    public void failure(@PathVariable(required = true) Long applyId) {
        boolean result = accountApplyService.failure(applyId);
        if (!result) {
            throw new BizException("系统异常");
        }
    }

    /**
     * 后台提现审核
     *
     * @param applyId
     * @return
     */
    @PostMapping("withdraw/{applyId}")
    //@RequiresPermissions("sys:apply:draw")
    public void withdraw(@PathVariable(required = true) Long applyId) {
        boolean result = accountApplyService.withDrawApply(applyId);
        if (!result) {
            throw new BizException("系统异常");
        }
    }


    /**
     * 冻结账户金额
     *
     * @param accountId
     * @return
     */
    @PostMapping("frost/{accountId}")
    //@RequiresPermissions("sys:apply:frost")
    public void frost(@PathVariable(required = true) Long accountId) throws Exception {
        accountApplyService.frost(accountId);
    }

    /**
     * 解冻结账户金额
     *
     * @param accountId
     * @return
     */
    @PostMapping("unfrost/{accountId}")
    //@RequiresPermissions("sys:apply:unfrost")
    public void unfrost(@PathVariable(required = true) Long accountId, Integer reason) throws Exception {
        accountApplyService.unfrost(accountId);
    }

    /**
     * 调整客户账户额度
     *
     * @param accountId
     * @param amount
     * @return
     */
    @PostMapping("adjust/{accountId}")
    //@RequiresPermissions("sys:apply:adjust")
    public void adjust(@PathVariable(required = true) Long accountId, @RequestParam(required = true) BigDecimal amount) {
        boolean result = accountApplyService.adjust(accountId, amount);
        ;
        if (!result) {
            throw new BizException("系统异常");
        }
    }

    /**
     * 根据条件获取收支申请明细分页列表
     *
     * @param map
     * @param page
     * @return
     */
    @GetMapping("applypage")
    //@RequiresPermissions("sys:apply:list")
    public Page<AccountApply> findApplyByCondition(@RequestParam Map<String, Object> map, Page<AccountApply> page) {
        return accountApplyService.findAccountPageByCondition(map, page);
    }

}

