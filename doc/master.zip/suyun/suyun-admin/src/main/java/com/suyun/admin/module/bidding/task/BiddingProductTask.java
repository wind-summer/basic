package com.suyun.admin.module.bidding.task;

import com.suyun.core.module.bidding.entity.BiddingRuleProduct;
import com.suyun.core.module.bidding.enums.BiddingStatus;
import com.suyun.core.module.bidding.service.BiddingConstant;
import com.suyun.core.module.bidding.service.BiddingRuleProductService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * @author wlf
 * @version V1.0
 * @Description: 定时任务，处理超时订单作废
 * @date 2017/12/14 下午7:16
 */
@Component("biddingProductTask")
@Slf4j
@AllArgsConstructor
public class BiddingProductTask {

    private final ZSetOperations<String,Object> zSetOperations;

    private final BiddingRuleProductService biddingRuleProductService;

    public void  changeBiddingProductStatus(){
        long currentTime = System.currentTimeMillis();
        log.debug("BiddingTimeoutTask is running ...........current time:{} ",currentTime);
        //判断待竞价的产品时间是否已开始
        Set<Object> startProductIds = zSetOperations.rangeByScore(BiddingConstant.AWAITING_START_BIDDING_PRODUCT_KEY,0,currentTime);
        startProductIds.forEach(id -> {
            BiddingRuleProduct b = biddingRuleProductService.selectById(Long.valueOf(String.valueOf(id)));
            if(b!=null && b.getBiddingStatus().equals(BiddingStatus.AWAITING_BIDDING)) {
                b.setBiddingStatus(BiddingStatus.BIDDING).updateById();
                zSetOperations.remove(BiddingConstant.AWAITING_START_BIDDING_PRODUCT_KEY, id);
            }
            if(b==null){
                //没有该产品了就移除掉
                zSetOperations.remove(BiddingConstant.AWAITING_START_BIDDING_PRODUCT_KEY, id);
            }
        });
        //判断待竞价的产品时间是否已结束
        Set<Object> endProductIds = zSetOperations.rangeByScore(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY,0,currentTime);
        endProductIds.forEach(id -> {
            //结束竞价产品
            //移除已经结束的产品ID
            BiddingRuleProduct b = biddingRuleProductService.selectById(Long.valueOf(String.valueOf(id)));
            /*if(b!=null && b.getBiddingStatus().equals(BiddingStatus.BIDDING)) {
                b.setBiddingStatus(BiddingStatus.FINISHED).updateById();
                zSetOperations.remove(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY, id);
            }*/
            if(b!=null){
                biddingRuleProductService.endBiddingProduct(Long.valueOf(String.valueOf(id)));
            }else{
                //没有该产品了就移除掉
                zSetOperations.remove(BiddingConstant.AWAITING_END_BIDDING_PRODUCT_KEY, id);
            }
        });
    }
}
