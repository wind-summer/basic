package com.suyun.admin.module.bidding.controller;

import com.suyun.common.mvc.controller.AbstractApiResultController;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 示例 biddingRule 前端控制器，基于Restfull规范
 * </p>
 * <p>查询操作：@GetMapping</p>
 * <p>新增操作：@PostMapping</p>
 * <p>编辑操作：@PutMapping</p>
 * <p>删除操作：@DeleteMapping</p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@RestController
@RequestMapping("/bidding/rule")
@AllArgsConstructor
@Slf4j
public class BiddingRuleController extends AbstractApiResultController {

}

