package com.suyun.admin.module.order.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author caosg
 * @since 2017-12-05
 */
@RestController
@RequestMapping("/order/orderAttribute")
public class OrderAttributeController extends AbstractApiResultController {

}

