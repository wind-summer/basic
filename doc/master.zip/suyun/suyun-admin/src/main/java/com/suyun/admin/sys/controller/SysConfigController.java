package com.suyun.admin.sys.controller;

import com.google.gson.Gson;
import com.suyun.common.annotation.SysLog;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.common.mvc.vm.PageVM;
import com.suyun.common.utils.ApiResult;
import com.suyun.common.utils.ConfigConstant;
import com.suyun.common.utils.Query;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.core.sys.entity.SysConfig;
import com.suyun.core.sys.service.SysConfigService;
import com.suyun.core.sys.service.dto.PlatformBankDTO;
import com.suyun.core.sys.service.dto.SysConfigDTO;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * 系统配置信息
 * 
 * @author csg
 *
 * @date 2016年12月4日 下午6:55:53
 */
@RestController
@RequestMapping("/sys/config")
public class SysConfigController extends AbstractApiResultController {
	@Autowired
	private SysConfigService sysConfigService;
	
	/**
	 * 所有配置列表
	 */
	@RequestMapping("/list")
//	@RequiresPermissions("sys:config:list")
	public ApiResult list(@RequestParam Map<String, Object> params){
		//查询列表数据
		Query query = new Query(params);
		List<SysConfig> configList = sysConfigService.queryList(query);
		int total = sysConfigService.queryTotal(query);
		
		PageVM pageUtil = new PageVM(configList, total, query.getLimit(), query.getPage());
		
		return ApiResult.ok().put("page", pageUtil);
	}
	
	
	/**
	 * 配置信息
	 */
	@RequestMapping("/info/{id}")
//	@RequiresPermissions("sys:config:info")
	public ApiResult info(@PathVariable("id") Long id){
		SysConfig config = sysConfigService.queryObject(id);
		
		return ApiResult.ok().put("config", config);
	}
	
	/**
	 * 保存配置
	 */
	@SysLog("保存配置")
	@RequestMapping("/save")
//	@RequiresPermissions("sys:config:save")
	public ApiResult save(@RequestBody SysConfig config){
		ValidatorUtils.validateEntity(config);

		sysConfigService.save(config);
		
		return ApiResult.ok();
	}
	
	/**
	 * 修改配置
	 */
	@SysLog("修改配置")
	@RequestMapping("/update")
//	@RequiresPermissions("sys:config:update")
	public ApiResult update(@RequestBody SysConfig config){
		ValidatorUtils.validateEntity(config);
		
		sysConfigService.update(config);
		
		return ApiResult.ok();
	}
	
	/**
	 * 删除配置
	 */
	@SysLog("删除配置")
	@RequestMapping("/delete")
//	@RequiresPermissions("sys:config:delete")
	public ApiResult delete(@RequestBody Long[] ids){
		sysConfigService.deleteBatch(ids);
		return ApiResult.ok();
	}

	/**
	 * 系统全局配置信息
	 */
	@GetMapping("global/get")
//	@RequiresPermissions("sys:global:info")
	public SysConfigDTO config(){
		SysConfigDTO config = sysConfigService.getConfigObject(ConfigConstant.SYS_GLOBAL_CONFIG_KEY, SysConfigDTO.class);
		return config;
	}


	/**
	 * 保存系统全局配置信息
	 */
	@PutMapping("global/edit")
//	@RequiresPermissions("sys:global:edit")
	public void saveConfig(@RequestBody SysConfigDTO config){
		//校验类型
		ValidatorUtils.validateEntity(config);
		sysConfigService.updateValueByKey(ConfigConstant.SYS_GLOBAL_CONFIG_KEY, new Gson().toJson(config));

	}

	/**
	 * 查询平台银行信息
	 */
	@GetMapping("bank/get")
//	@RequiresPermissions("sys:bank:info")
	public PlatformBankDTO platformBank(){
		return sysConfigService.getConfigObject(ConfigConstant.PLATFORM_BANK_KEY, PlatformBankDTO.class);
	}

	@PutMapping("bank/edit")
//	@RequiresPermissions("sys:bank:edit")
	public void saveBank(@RequestBody @Valid PlatformBankDTO platformBank){
		sysConfigService.updateValueByKey(ConfigConstant.PLATFORM_BANK_KEY, new Gson().toJson(platformBank));
	}

}
