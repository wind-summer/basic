package com.suyun.admin.module.article.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.article.entity.Article;
import com.suyun.core.module.article.service.ArticleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-12-11
 */
@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/sys/article")
public class ArticleController extends AbstractApiResultController {
    private final ArticleService articleService;
    /**
     * 添加文章
     * @param article
     */
    @PostMapping("/add")
    //@RequiresPermissions("sys:article:add")
    public void addArticle(@RequestBody Article article){
        articleService.addArticle(article);
    }

    /**
     * 修改文章
     * @param article
     */
    @PutMapping("/edit")
    //@RequiresPermissions("sys:article:edit")
    public void editArticle(@RequestBody @Valid Article article){
        articleService.editArticle(article);
    }

    /**
     * 查询文章详情
     * @param articleId
     * @return
     */
    @GetMapping("/info")
    //@RequiresPermissions("sys:article:info")
    public Article findArticleByd(@RequestParam(value = "id",defaultValue = "0") Long articleId){
        return articleService.findArticleByid(articleId);
    }

    /**
     * 文章列表
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/list")
    //@RequiresPermissions("sys:article:list")
    public Page<Article> queryArticle(@RequestParam Map<String, Object> params, Page<Article> page) {
        log.debug("params is :{}",params);
        return articleService.queryArticle(params,page);
    }

    /**
     * 删除文章
     * @param articleId
     */
    @DeleteMapping("/del")
    //@RequiresPermissions("sys:article:delete")
    public void deleteArticle(@RequestParam(value = "id")Long articleId){
        articleService.deleteById(articleId);
    }

    /**
     * 上线文章
     * @param articleId
     */
    @PutMapping("down")
    //@RequiresPermissions("sys:article:down")
    public void  downLine(@RequestParam(value = "id")Long articleId){
        articleService.downLineById(articleId);
    }

    /**
     * 下线文章
     * @param articleId
     */
    @PutMapping("up")
    //@RequiresPermissions("sys:article:up")
    public void  upLine(@RequestParam(value = "id")Long articleId){
        articleService.upLineById(articleId);
    }
}

