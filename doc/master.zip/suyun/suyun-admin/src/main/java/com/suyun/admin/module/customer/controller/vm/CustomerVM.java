package com.suyun.admin.module.customer.controller.vm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.LuhnCheck;
import org.hibernate.validator.constraints.NotBlank;

/**
 * 客戶信息
 *
 * @date 2018年1月13日 09:47:46
 * @author luy
 */
@Data
@Accessors(chain = true)
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerVM extends Customer{

    /**
     * 公司行业
     */
    @NotBlank(message = "主营产品不能为空")
    private String industry;
    /**
     * 公司规模
     */
    @NotBlank(message = "公司规模不能为空")
    private String scale;
    /**
     * 公司地址
     */
    @NotBlank(message = "公司地址不能为空")
    private String address;
    /**
     * 注册资本
     */
    @NotBlank(message = "注册资金不能为空")
    private String registeredCapital;

    /**
     * 银行账户类型
     */
    private String accountType;
    /**
     * 开户名
     */
    @NotBlank(message = "开户名不能为空")
    private String accountName;
    /**
     * 开户行
     */
    @NotBlank(message = "开户行不能为空")
    private String bank;
    /**
     * 银行账号
     */
    @NotBlank(message = "银行账号不能为空")
    @LuhnCheck(message="银行卡格式不正确")
    private String accountNo;

    /**
     * 工商营业执照
     */
    @NotBlank(message = "工商营业执照不能为空")
    private String bizLogoUrl;
    /**
     * 工商注册号
     */
    private String bizRegistryNo;
    /**
     * 组织机构代码
     */
    private String bizOrgCode;
    /**
     * 社会信用代码
     */
    private String bizCreditCode;
    /**
     * 公司类型
     */
    @NotBlank(message = "公司类型不能为空")
    private String bizType;
    /**
     * 纳税人类型
     */
    private String taxType;
    /**
     * 纳税人识别号
     */
    private String taxCode;

    private String token;

    public CustomerVM() {

    }
}
