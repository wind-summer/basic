package com.suyun.admin.sys.controller.vm;

import com.suyun.common.validator.group.AddGroup;
import com.suyun.common.validator.group.UpdateGroup;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;
import com.baomidou.mybatisplus.annotations.TableField;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.suyun.core.module.customer.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.LuhnCheck;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * 用户信息
 *
 * @author luy
 * @date 2018年1月16日 15:01:16
 */
@Data
public class SysUserVM {
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 登录名
     */
    @NotBlank(message="登录名不能为空", groups = {AddGroup.class, UpdateGroup.class})
    private String username;

    /**
     * 昵称
     */
    @NotBlank(message = "昵称不能为空",groups =  {AddGroup.class, UpdateGroup.class})
    private String nick;

    /**
     * 邮箱
     */
    @NotBlank(message="邮箱不能为空", groups = {AddGroup.class, UpdateGroup.class})
    @Email(message="邮箱格式不正确", groups = {AddGroup.class, UpdateGroup.class})
    private String email;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 状态  0：禁用   1：正常
     */
    private Integer status;

    /**
     * 角色ID列表
     */
    private List<Long> roleIdList;

    /**
     * 部门ID
     */
    @NotNull(message="部门不能为空", groups = {AddGroup.class, UpdateGroup.class})
    private Long deptId;

    /**
     * 部门名称
     */
    private String deptName;

    /**
     * 职位
     */
    private String position;

    /**
     * QQ
     */
    private String qq;

    /**
     * 微信
     */
    private String weixin;

    /**
     * 微信二维码地址
     */
    private String weixinUrl;


}
