package com.suyun.admin.module.account.controller;


import com.suyun.common.mvc.controller.AbstractApiResultController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 账户收支明细 前端控制器
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@RestController
@RequestMapping("/sys/accounttrans")
public class AccountTransController extends AbstractApiResultController {

}

