package com.suyun.admin.sys.controller;

import com.suyun.common.utils.ApiResult;
import com.suyun.common.mvc.vm.PageVM;
import com.suyun.common.utils.Query;
import com.suyun.core.sys.entity.SysLog;
import com.suyun.core.sys.service.SysLogService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;


/**
 * 系统日志
 * 
 * @author csg
 *
 * @date 2017-03-08 10:40:56
 */
@Controller
@RequestMapping("/sys/log")
public class SysLogController {
	@Autowired
	private SysLogService sysLogService;
	
	/**
	 * 列表
	 */
	@ResponseBody
	@RequestMapping("/list")
	@RequiresPermissions("sys:log:list")
	public ApiResult list(@RequestParam Map<String, Object> params){
		//查询列表数据
		Query query = new Query(params);
		List<SysLog> sysLogList = sysLogService.queryList(query);
		int total = sysLogService.queryTotal(query);
		
		PageVM pageUtil = new PageVM(sysLogList, total, query.getLimit(), query.getPage());
		return ApiResult.ok().put("page", pageUtil);
	}
	
}
