package com.suyun.admin.sys.controller;

import com.suyun.admin.sys.controller.vm.SysUserVM;
import com.suyun.common.annotation.SysLog;
import com.suyun.common.sms.SmsProperties;
import com.suyun.common.utils.ApiResult;
import com.suyun.common.mvc.vm.PageVM;
import com.suyun.common.utils.Query;
import com.suyun.common.validator.Assert;
import com.suyun.common.validator.ValidatorUtils;
import com.suyun.common.validator.group.AddGroup;
import com.suyun.common.validator.group.UpdateGroup;
import com.suyun.core.config.ApplicationProperties;
import com.suyun.core.module.customer.exception.LoginFailException;
import com.suyun.core.sys.entity.SysUser;
import com.suyun.core.sys.entity.SysUserDTO;
import com.suyun.core.sys.service.SysUserRoleService;
import com.suyun.core.sys.service.SysUserService;
import org.apache.commons.lang.ArrayUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 系统用户
 * 
 * @author csg
 *
 * @date 2016年10月31日 上午10:40:10
 */
@RestController
@RequestMapping("/sys/user")
public class SysUserController extends AbstractController {
	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private SysUserRoleService sysUserRoleService;

	/**
	 * 所有用户列表
	 */
	@RequestMapping("/list")
	@RequiresPermissions("sys:user:list")
	public ApiResult list(@RequestParam Map<String, Object> params){
		//查询列表数据
		Query query = new Query(params);
		List<SysUserVM> userList = sysUserService.queryList(query).stream().map(sysUser -> {
			SysUserVM sysUserVM = new SysUserVM();
			BeanUtils.copyProperties(sysUser,sysUserVM);
			return sysUserVM;
		}).collect(Collectors.toList());

		int total = sysUserService.queryTotal(query);

		PageVM pageUtil = new PageVM(userList, total, query.getLimit(), query.getPage());
		
		return ApiResult.ok().put("page", pageUtil);
	}
	
	/**
	 * 获取登录的用户信息
	 */
	@RequestMapping("/info")
	public ApiResult info(){
		return ApiResult.ok().put("user", getUser());
	}
	
	/**
	 * 修改登录用户密码
	 */
	@SysLog("修改密码")
	@RequestMapping("/password")
	public ApiResult password(String password, String newPassword){
		Assert.isBlank(newPassword, "新密码不为能空");

		//sha256加密
		password = new Sha256Hash(password, getUser().getSalt()).toHex();
		//sha256加密
		newPassword = new Sha256Hash(newPassword, getUser().getSalt()).toHex();
				
		//更新密码
		int count = sysUserService.updatePassword(getUserId(), password, newPassword);
		if(count == 0){
			return ApiResult.error("原密码不正确");
		}
		
		return ApiResult.ok();
	}

	/**
	 * 重置密码
	 */
	@SysLog("重置密码")
	@PutMapping("/resetPassword/{userId}")
	public ApiResult initPassword(@PathVariable("userId") Long userId){
		//初始化密码
		sysUserService.initPassword(userId);
		return ApiResult.ok();
	}
	
	/**
	 * 用户信息
	 */
	@RequestMapping("/info/{userId}")
	@RequiresPermissions("sys:user:info")
	public ApiResult info(@PathVariable("userId") Long userId){
		SysUser user = sysUserService.queryObject(userId);
		SysUserVM userVM = new SysUserVM();
		if(null!=user){
			BeanUtils.copyProperties(user,userVM);
		}
		//获取用户所属的角色列表
		List<Long> roleIdList = sysUserRoleService.queryRoleIdList(userId);
		userVM.setRoleIdList(roleIdList);
		
		return ApiResult.ok().put("user", userVM);
	}
	
	/**
	 * 保存用户
	 */
	@SysLog("保存用户")
	@RequestMapping("/save")
	@RequiresPermissions("sys:user:save")
	public ApiResult save(@RequestBody SysUser user){
		ValidatorUtils.validateEntity(user, AddGroup.class);
		if(!sysUserService.getUserNameIsNull(user.getUsername())){
			return ApiResult.error("登录名已存在,请重新录入！");
		}
		user.setCreateUserId(getUserId());
		sysUserService.save(user);
		
		return ApiResult.ok();
	}
	
	/**
	 * 修改用户
	 */
	@SysLog("修改用户")
	@RequestMapping("/update")
	@RequiresPermissions("sys:user:update")
	public ApiResult update(@RequestBody SysUser user){
		ValidatorUtils.validateEntity(user, UpdateGroup.class);

		user.setCreateUserId(getUserId());
		sysUserService.update(user);
		
		return ApiResult.ok();
	}
	
	/**
	 * 删除用户
	 */
	@SysLog("删除用户")
	@RequestMapping("/delete")
	@RequiresPermissions("sys:user:delete")
	public ApiResult delete(@RequestBody Long[] userIds){
		if(ArrayUtils.contains(userIds, 1L)){
			return ApiResult.error("系统管理员不能删除");
		}
		
		if(ArrayUtils.contains(userIds, getUserId())){
			return ApiResult.error("当前用户不能删除");
		}
		
		sysUserService.deleteBatch(userIds);
		
		return ApiResult.ok();
	}

	/**
	 * 查询所有业务员
	 * @return
	 */
	@SysLog("查询业务员信息")
	@GetMapping("/businessuser")
	public List<SysUserDTO> getBusinessUser(){
		return sysUserService.getBusinessUser();
	}

	/**
	 * 根据部门id查询业务员信息
	 * @param deptId
	 * @return
	 */
	@SysLog("根据部门查询业务员信息")
	@GetMapping("/businessuser/{deptId}")
	public List<SysUserDTO> getBusinessuerByDeptId(@PathVariable Long deptId){
		return sysUserService.getBusinessUserByDeptId(deptId);
	}

}
