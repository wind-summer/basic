package com.suyun.admin.module.account.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.account.entity.Account;
import com.suyun.core.module.account.service.AccountService;
import com.suyun.core.module.account.service.dto.AccountDetailDTO;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * <p>
 * 后台控制器
 * </p>
 *
 * @author zhangjq
 * @since 2017-12-28
 */
@RestController
@RequestMapping("/sys/account")
@AllArgsConstructor
public class AccountController extends AbstractApiResultController {

    private final AccountService accountService;

    /**
     * 账户分页条件查询
     *
     * @param map
     * @param page
     * @return
     */
    @GetMapping("page")
    //@RequiresPermissions("sys:account:list")
    public Page<Account> find(@RequestParam Map<String, Object> map, Page<Account> page) {
        return accountService.findpage(map, page);
    }

    /**
     * 获取账户详细信息
     *
     * @param accountId
     * @return
     */
    @GetMapping("accountdet/{accountId}")
    //@RequiresPermissions("sys:account:info")
    public AccountDetailDTO getAccountDetail(@PathVariable(required = true) Long accountId) {
        return accountService.findAccount(accountId);
    }

}

