package com.suyun.admin.module.bidding.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.bidding.entity.BiddingRecord;
import com.suyun.core.module.bidding.service.BiddingRecordService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 竞价记录表 前端控制器
 * </p>
 *
 * @author wlf
 * @since 2017-12-22
 */
@RestController
@RequestMapping("/bidding/record")
@AllArgsConstructor
@Slf4j
public class BiddingRecordController extends AbstractApiResultController {

    private final BiddingRecordService biddingRecordService;

    /**
     *
     * @param biddingRecord
     */
    @PostMapping("/add")
    //@RequiresPermissions("bidding:record:add")
    public void add(@RequestBody @Valid BiddingRecord biddingRecord){
        biddingRecordService.insert(biddingRecord);
    }

    /**
     * 根据竞价产品ID分页查询竞猜记录
     * @param biddingProductId
     * @param page
     */
    @GetMapping("/list")
    //@RequiresPermissions("bidding:record:list")
    public Page<BiddingRecord> queryBiddingRecordByProductId(@RequestParam(value = "biddingProductId",required = true,defaultValue = "0") Long biddingProductId, Page<BiddingRecord> page){
        return biddingRecordService.queryBiddingRecordByProductId(biddingProductId, page);
    }

    /**
     * 根据id 竞拍记录改为竞价失败，并且把押金解冻
     * @param id
     */
    @PutMapping("/fail")
    //@RequiresPermissions("bidding:record:fail")
    public void cancelBiddingRecord(@RequestParam(value = "id",required = true) Long id){
        biddingRecordService.cancelBiddingRecord(id);
    }

    /**
     * 根据id 竞拍记录改为竞价成功
     * @param id
     */
    @PutMapping("/deal")
    //@RequiresPermissions("bidding:record:deal")
    public void dealBiddingRecord(@RequestParam(value = "id",required = true) Long id){
        biddingRecordService.dealBiddingRecord(id);
    }
}

