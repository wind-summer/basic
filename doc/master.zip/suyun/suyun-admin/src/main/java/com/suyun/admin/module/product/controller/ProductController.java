package com.suyun.admin.module.product.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.exception.BizException;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.bidding.service.BiddingRuleProductService;
import com.suyun.core.module.product.entity.Product;
import com.suyun.core.module.product.entity.Sku;
import com.suyun.core.module.product.service.ProductService;
import com.suyun.core.module.product.service.dto.ProductDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 产品表 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-11-29
 */
@AllArgsConstructor
@Slf4j
@RestController
@RequestMapping("/sys/product")
public class ProductController extends AbstractApiResultController {
    private final ProductService productService;
    private final BiddingRuleProductService biddingRuleProductService;
    /**
     * 产品分页
     *
     * @param params
     * @param page
     * @return
     */
    @GetMapping("/list")
    //@RequiresPermissions("sys:product:list")
    public Page<Sku> selectProductList(@RequestParam Map<String,Object> params,Page<Sku> page) {
        return productService.selectSkuList(params,page);
    }

    /**
     * 添加产品
     *
     * @param productDTO
     * @returnlog.debug(ew.getSqlSegment());
     */
    @PostMapping("/add")
    //@RequiresPermissions("sys:product:add")
    public void insertGetId(@RequestBody @Valid ProductDTO productDTO) {
        if(log.isDebugEnabled()){
            log.info("RequestBody:{}", productDTO);
        }
        productService.addProduct(productDTO);
    }

    /**
     * 修改产品
     *
     * @param skus
     */
    @PutMapping("/edit")
    //@RequiresPermissions("sys:product:edit")
    public void editSku(@RequestBody List<Sku> skus) {

        productService.editSku(skus);
    }

    /**
     * 根据skuId 查询sku 及product
     *
     * @param id
     * @return
     */
    @GetMapping("/skuinfo")
    //@RequiresPermissions("sys:product:skuinfo")
    public Sku getSku(@RequestParam(value = "id", defaultValue = "0") Long id) {
        return productService.getSku(id);
    }


    /**
     * 根据productId 查询产品及所有sku信息
     *
     * @param producctId
     * @return
     */
    @GetMapping("/info")
    //@RequiresPermissions("sys:product:info")
    public Product getProductByProductId(@RequestParam(value = "id", required = true, defaultValue = "0") Long producctId) {
        return productService.findByProductId(producctId);
    }


    /**
     * 批量上下架产品
     *
     * @param sale
     * @param skuIds
     */
    @PutMapping("/off")
    //@RequiresPermissions("sys:product:off")
    public void offSku(@RequestParam(value = "sale", required = true) boolean sale, @RequestParam(value = "ids", required = true) String skuIds) {
        if (StringUtils.isEmpty(skuIds)) {
            throw new BizException("skuId不能为空");
        }
        //正在拍卖中的商品不能下架
        String[] ids = StringUtils.split(skuIds, ",");
        if(log.isDebugEnabled()){
            log.debug("ids is :{}", (Object) ids);
        }
        for (int i = 0; i < ids.length; i++) {
            if (!StringUtils.isNumeric(ids[i])) {
                throw new BizException("id必须是数字");
            }
            Long id = Long.parseLong(ids[i]);
            if(!biddingRuleProductService.isOffShelfSku(id)){
                throw new BizException("商品正在拍卖中，不能下架");
            }
        }
        productService.offSku(sale, skuIds);
    }
}