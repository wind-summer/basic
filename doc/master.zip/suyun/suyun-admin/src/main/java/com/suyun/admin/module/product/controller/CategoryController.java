package com.suyun.admin.module.product.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.suyun.common.mvc.controller.AbstractApiResultController;
import com.suyun.core.module.product.entity.Category;
import com.suyun.core.module.product.service.CategoryService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author jos
 * @since 2017-11-29
 */
@Slf4j
@AllArgsConstructor
@RestController
@RequestMapping("/sys/category")
public class CategoryController extends AbstractApiResultController {

    private final CategoryService categoryService;

    /**
     * 添加产品分类
     *
     * @param category
     */
    @PostMapping("/add")
    //@RequiresPermissions("sys:category:add")
    public void addCateGory(@RequestBody @Valid Category category) {
        categoryService.addCateGory(category);
    }

    /**
     * 修改分类
     *
     * @param category
     */
    @PutMapping("/edit")
    //@RequiresPermissions("sys:category:edit")
    public void updataCateGory(@RequestBody @Valid Category category) {
        categoryService.updateCateGory(category);
    }

    /**
     * 分类列表
     *
     * @return
     */
    @GetMapping("/list")
    //@RequiresPermissions("sys:category:list")
    public Page<Category> queryList(@RequestParam Map<String, Object> param, Page<Category> page) {
        return categoryService.selectList(param, page);
    }

    @DeleteMapping("/del/{id}")
//    @RequiresPermissions("sys:category:del")
    public void deleteCateGory(@PathVariable Long id) {
        categoryService.deleteCategory(id);
    }

    /**
     * 根据categoryId查找商品
     *
     * @param productId
     * @return
     */
    @GetMapping("/info")
    //@RequiresPermissions("sys:category:info")
    public Category findById(@RequestParam(value = "id", required = true) Long productId) {
        return categoryService.findById(productId);
    }
}

